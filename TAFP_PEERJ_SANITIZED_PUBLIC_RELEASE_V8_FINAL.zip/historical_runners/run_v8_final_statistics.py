from pathlib import Path
import hashlib
import numpy as np
import pandas as pd
from scipy import stats

INPUT = "outputs/v8_final/v8_multidataset_15seed_all.csv"
OUTDIR = Path("outputs/v8_final/statistics")
OUTDIR.mkdir(parents=True, exist_ok=True)

METRIC_TYPES = {
    "recall_at_k": "utility",
    "ndcg_at_k": "utility",
    "mia_auc": "privacy",
    "link_inference_auc": "privacy",
    "topology_leakage_score": "privacy",
    "reconstruction_similarity": "privacy",
}

COMPARISONS = {
    "H1_full_vs_baseline": {
        "a": "full",
        "b": "baseline",
        "primary_metrics": [
            "mia_auc",
            "link_inference_auc",
            "topology_leakage_score",
            "reconstruction_similarity",
        ],
    },
    "H2_entity_vs_random_entity": {
        "a": "entity_only",
        "b": "random_entity_budget",
        "primary_metrics": [
            "recall_at_k",
            "ndcg_at_k",
            "mia_auc",
        ],
    },
    "H3_relation_vs_random_relation": {
        "a": "relation_only",
        "b": "random_relation_budget",
        "primary_metrics": [
            "recall_at_k",
            "ndcg_at_k",
            "link_inference_auc",
        ],
    },
    "H4_topology_vs_dropout": {
        "a": "topology_only",
        "b": "random_edge_dropout",
        "primary_metrics": [
            "recall_at_k",
            "ndcg_at_k",
            "topology_leakage_score",
            "reconstruction_similarity",
        ],
    },
    "H5_full_vs_random_full": {
        "a": "full",
        "b": "random_full_budget",
        "primary_metrics": list(METRIC_TYPES),
    },
}


def holm_adjust(values):
    p = np.asarray(values, dtype=float)
    p = np.where(np.isnan(p), 1.0, p)

    n = len(p)
    order = np.argsort(p)
    adjusted = np.empty(n)
    running = 0.0

    for rank, index in enumerate(order):
        candidate = (n - rank) * p[index]
        running = max(running, candidate)
        adjusted[index] = min(running, 1.0)

    return adjusted


_sign_cache = {}


def exact_sign_flip_p(differences):
    d = np.asarray(differences, dtype=float)

    if len(d) == 0 or np.allclose(d, 0):
        return 1.0

    n = len(d)

    if n not in _sign_cache:
        integers = np.arange(2 ** n, dtype=np.uint32)[:, None]
        bits = (integers >> np.arange(n, dtype=np.uint32)) & 1
        _sign_cache[n] = np.where(bits == 0, 1.0, -1.0)

    observed = abs(d.mean())
    permuted = np.abs(
        (_sign_cache[n] * d[None, :]).mean(axis=1)
    )

    return float(
        np.mean(permuted >= observed - 1e-15)
    )


def bootstrap_ci(values, key, samples=20000):
    values = np.asarray(values, dtype=float)

    if np.allclose(values, values[0]):
        return float(values[0]), float(values[0])

    digest = hashlib.md5(key.encode()).hexdigest()[:8]
    seed = int(digest, 16)

    rng = np.random.default_rng(seed)
    indices = rng.integers(
        0,
        len(values),
        size=(samples, len(values))
    )

    means = values[indices].mean(axis=1)
    low, high = np.percentile(means, [2.5, 97.5])

    return float(low), float(high)


def rank_biserial(values):
    values = np.asarray(values, dtype=float)
    values = values[~np.isclose(values, 0)]

    if len(values) == 0:
        return 0.0

    ranks = stats.rankdata(np.abs(values))
    positive = ranks[values > 0].sum()
    negative = ranks[values < 0].sum()

    return float(
        (positive - negative) / (positive + negative)
    )


def safe_wilcoxon(values):
    values = np.asarray(values, dtype=float)

    if np.allclose(values, 0):
        return 1.0

    try:
        return float(
            stats.wilcoxon(
                values,
                alternative="two-sided",
                zero_method="wilcox",
                method="auto",
            ).pvalue
        )
    except Exception:
        return np.nan


df = pd.read_csv(INPUT)

rows = []

for comparison, setup in COMPARISONS.items():
    variant_a = setup["a"]
    variant_b = setup["b"]

    for dataset in sorted(df["dataset_name"].unique()):
        dataset_df = df[df["dataset_name"] == dataset]

        a_df = (
            dataset_df[dataset_df["variant"] == variant_a]
            .sort_values("seed")
        )
        b_df = (
            dataset_df[dataset_df["variant"] == variant_b]
            .sort_values("seed")
        )

        common_seeds = sorted(
            set(a_df["seed"]).intersection(b_df["seed"])
        )

        if len(common_seeds) != 15:
            raise RuntimeError(
                f"{comparison} {dataset}: "
                f"expected 15 paired seeds"
            )

        for metric, metric_type in METRIC_TYPES.items():
            a = (
                a_df[a_df["seed"].isin(common_seeds)]
                .sort_values("seed")[metric]
                .to_numpy()
            )

            b = (
                b_df[b_df["seed"].isin(common_seeds)]
                .sort_values("seed")[metric]
                .to_numpy()
            )

            raw_difference = a - b

            # Positive advantage always means variant A is better.
            if metric_type == "utility":
                advantage = a - b
            else:
                advantage = b - a

            ci_low, ci_high = bootstrap_ci(
                advantage,
                f"{comparison}-{dataset}-{metric}"
            )

            std_advantage = float(
                np.std(advantage, ddof=1)
            )

            cohens_dz = (
                float(np.mean(advantage) / std_advantage)
                if std_advantage > 0
                else 0.0
            )

            rows.append({
                "comparison": comparison,
                "variant_a": variant_a,
                "variant_b": variant_b,
                "dataset": dataset,
                "metric": metric,
                "metric_type": metric_type,
                "primary_metric":
                    metric in setup["primary_metrics"],
                "n_seeds": len(common_seeds),

                "variant_a_mean": float(np.mean(a)),
                "variant_a_std": float(np.std(a, ddof=1)),
                "variant_b_mean": float(np.mean(b)),
                "variant_b_std": float(np.std(b, ddof=1)),

                "raw_difference_a_minus_b":
                    float(np.mean(raw_difference)),

                "mean_advantage_a":
                    float(np.mean(advantage)),
                "median_advantage_a":
                    float(np.median(advantage)),

                "bootstrap_ci95_low": ci_low,
                "bootstrap_ci95_high": ci_high,

                "exact_permutation_p":
                    exact_sign_flip_p(advantage),
                "wilcoxon_p":
                    safe_wilcoxon(advantage),

                "cohens_dz_advantage": cohens_dz,
                "rank_biserial_advantage":
                    rank_biserial(advantage),

                "a_better_mean":
                    int(np.mean(advantage) > 0),
            })

results = pd.DataFrame(rows)

results["permutation_p_holm_all_metrics"] = np.nan
results["permutation_p_holm_primary"] = np.nan
results["wilcoxon_p_holm_primary"] = np.nan

for comparison in results["comparison"].unique():
    comparison_mask = (
        results["comparison"] == comparison
    )

    results.loc[
        comparison_mask,
        "permutation_p_holm_all_metrics"
    ] = holm_adjust(
        results.loc[
            comparison_mask,
            "exact_permutation_p"
        ]
    )

    primary_mask = (
        comparison_mask
        & results["primary_metric"]
    )

    results.loc[
        primary_mask,
        "permutation_p_holm_primary"
    ] = holm_adjust(
        results.loc[
            primary_mask,
            "exact_permutation_p"
        ]
    )

    results.loc[
        primary_mask,
        "wilcoxon_p_holm_primary"
    ] = holm_adjust(
        results.loc[
            primary_mask,
            "wilcoxon_p"
        ]
    )


results.to_csv(
    OUTDIR / "v8_all_pairwise_statistical_tests.csv",
    index=False
)

primary = results[results["primary_metric"]].copy()

primary.to_csv(
    OUTDIR / "v8_primary_hypothesis_tests.csv",
    index=False
)


summary_rows = []

for comparison in COMPARISONS:
    subset = primary[
        primary["comparison"] == comparison
    ]

    significant = (
        subset["permutation_p_holm_primary"] < 0.05
    )

    significant_positive = (
        significant
        & (subset["mean_advantage_a"] > 0)
    )

    summary_rows.append({
        "comparison": comparison,
        "primary_tests": len(subset),
        "positive_mean_advantage":
            int((subset["mean_advantage_a"] > 0).sum()),
        "holm_significant":
            int(significant.sum()),
        "holm_significant_and_a_better":
            int(significant_positive.sum()),
        "maximum_holm_permutation_p":
            float(
                subset[
                    "permutation_p_holm_primary"
                ].max()
            ),
    })

summary = pd.DataFrame(summary_rows)

summary.to_csv(
    OUTDIR / "v8_hypothesis_summary.csv",
    index=False
)


non_significant = primary[
    primary["permutation_p_holm_primary"] >= 0.05
][
    [
        "comparison",
        "dataset",
        "metric",
        "mean_advantage_a",
        "exact_permutation_p",
        "permutation_p_holm_primary",
    ]
]

negative = primary[
    primary["mean_advantage_a"] <= 0
][
    [
        "comparison",
        "dataset",
        "metric",
        "variant_a_mean",
        "variant_b_mean",
        "mean_advantage_a",
        "permutation_p_holm_primary",
    ]
]


print("V8 FINAL STATISTICS: DONE")

print("\nHYPOTHESIS SUMMARY:")
print(summary.to_string(index=False))

print("\nNON-SIGNIFICANT PRIMARY TESTS:")
if non_significant.empty:
    print("None")
else:
    print(non_significant.to_string(index=False))

print("\nPRIMARY RESULTS WHERE VARIANT A WAS NOT BETTER:")
if negative.empty:
    print("None")
else:
    print(negative.to_string(index=False))

print("\nSaved:")
for path in sorted(OUTDIR.glob("*.csv")):
    print(path)
