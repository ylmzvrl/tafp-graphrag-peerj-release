#!/usr/bin/env python3
"""
TAFP-GraphRAG locked end-to-end retrieval-grounded multi-hop relation-QA runner.

Modes
-----
dry-run
    Fixed 20-query determinism subset, protection seed 0, four conditions,
    two generation repeats. Expected rows/generations: 160.

pilot
    Full locked pilot manifest, protection seeds 0/1/2, four conditions,
    one generation repeat. Expected rows/generations: 1,152.

full
    Full locked manifest, protection seeds 0 through 14, four conditions,
    one generation repeat. Expected rows/generations: 43,080.

Scientific design
-----------------
Conditions:
    baseline
    full
    random_full_budget
    2K (implemented as dk2_full_budget)

Tasks:
    non_sensitive_utility
    sensitive_disclosure

Primary measurements:
    exact_sequence_match
    relation_token_f1
    retrieved_evidence_recall
    faithfulness_to_retrieved_evidence
    original_sensitive_relation_disclosure_rate
    sensitive_token_recall
    protected_marker_rate
    retrieved_sensitive_evidence_exposure

Safety
------
- Does not modify repository source files.
- Does not modify the manuscript.
- Writes only to a new timestamped run directory under the safe revision
  workspace, unless --run-dir is explicitly supplied for resume.
- Raw result checkpoints are append-only JSONL.
- The existing generation_relation_qa_seed42_full.py is not modified.
- Large dataset CSVs are resolved from Google Drive in memory; they are not
  copied into or linked inside the Git repository.
- Prompt contract 1.2 clarifies the locked relation-label-only output; it
  does not change datasets, queries, variants, model, decoding, or metrics.
"""

from __future__ import annotations

import argparse
import copy
import csv
import datetime as dt
import hashlib
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import time
from collections import Counter, deque
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np
import pandas as pd
import torch


EXPECTED_BRANCH_PREFIX = "revision/applied-sciences-pre-submission-"
EXPECTED_HEAD = "d961d965fa449fff2826a9f6c640b892121cb0b1"

MODEL_ID = "Qwen/Qwen2.5-3B-Instruct"
MAX_INPUT_TOKENS = 3072
MAX_NEW_TOKENS = 32
GENERATION_SEED = 42
PROMPT_CONTRACT_VERSION = "1.2-relation-label-only"

DATASET_ORDER = [
    "AGNews",
    "CNN_DM",
    "IMDB",
    "PubMed",
    "SynthPII",
]

CONFIG_FILES = {
    "AGNews": "config_agnews_v8_seed_42.json",
    "CNN_DM": "config_cnn_dm_v8_seed_42.json",
    "IMDB": "config_imdb_v8_seed_42.json",
    "PubMed": "config_pubmed_v8_seed_42.json",
    "SynthPII": "config_synthpii_v8_seed_42.json",
}

DATA_PATH_KEYS = (
    "node_csv_path",
    "edge_csv_path",
)

DISPLAY_VARIANTS = [
    "baseline",
    "full",
    "random_full_budget",
    "2K",
]

INTERNAL_VARIANT = {
    "baseline": "baseline",
    "full": "full",
    "random_full_budget": "random_full_budget",
    "2K": "dk2_full_budget",
}

PILOT_SEEDS = [0, 1, 2]
FULL_SEEDS = list(range(15))
DRY_RUN_SEEDS = [0]

SPECIAL_RELATIONS = {
    "PRIVATE_RELATION",
    "NOT_CONNECTED",
    "UNKNOWN",
}

REQUIRED_MANIFEST_COLUMNS = {
    "phase",
    "dataset_name",
    "task",
    "selection_index",
    "available_pool_size",
    "stable_rank",
    "path_id",
    "source",
    "target",
    "hop",
    "path_nodes_json",
    "path_edge_count",
    "sensitive_edge_count",
    "non_sensitive_edge_count",
    "path_scope",
}

CHUNK = 8 * 1024 * 1024


def run_command(
    args: Sequence[str],
    cwd: Path,
    check: bool = False,
) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(
        list(args),
        cwd=str(cwd),
        text=True,
        capture_output=True,
        check=False,
    )
    if check and proc.returncode != 0:
        raise RuntimeError(
            f"Command failed: {' '.join(args)}\n"
            f"STDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
        )
    return proc


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(CHUNK)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def read_pointer(path: Path) -> Dict[str, str]:
    values: Dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    return values


def atomic_write_text(path: Path, text: str) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    atomic_write_text(
        path,
        json.dumps(
            payload,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
        )
        + "\n",
    )


def append_jsonl(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
    )
    with path.open("a", encoding="utf-8") as handle:
        handle.write(encoded + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.is_file():
        return []

    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                rows.append(json.loads(stripped))
            except json.JSONDecodeError as exc:
                raise RuntimeError(
                    f"Invalid JSONL at {path}:{line_number}: {exc}"
                ) from exc
    return rows


def set_all_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def normalize_relation(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value)).strip()


def edge_relation(graph: Any, source: str, target: str) -> str:
    if not graph.has_edge(source, target):
        return "NOT_CONNECTED"
    data = graph.edges[source, target]
    return normalize_relation(
        data.get(
            "protected_relation_type",
            data.get("relation_type", "UNKNOWN"),
        )
    )


def node_label(graph: Any, node: str) -> str:
    if node not in graph:
        return str(node)
    data = graph.nodes[node]
    return normalize_relation(
        data.get(
            "protected_label",
            data.get("original_label", node),
        )
    )


def node_type(graph: Any, node: str) -> str:
    if node not in graph:
        return "MISSING_NODE"
    return normalize_relation(
        graph.nodes[node].get("entity_type", "ENTITY")
    )


def edge_sensitive(
    graph: Any,
    source: str,
    target: str,
    protection_core: Any,
) -> bool:
    if not graph.has_edge(source, target):
        raise RuntimeError(
            f"Expected base edge missing: {source} -- {target}"
        )
    return bool(
        protection_core._v7_edge_sensitive(
            graph.edges[source, target]
        )
    )


def deterministic_shortest_path(
    graph: Any,
    source: str,
    target: str,
    cutoff: int,
) -> List[str] | None:
    if source not in graph or target not in graph:
        return None
    if source == target:
        return [source]
    if cutoff < 1:
        return None

    parent: Dict[str, str | None] = {source: None}
    depth: Dict[str, int] = {source: 0}
    queue: deque[str] = deque([source])

    while queue:
        current = queue.popleft()
        current_depth = depth[current]

        if current_depth >= cutoff:
            continue

        neighbors = sorted(
            graph.neighbors(current),
            key=lambda item: str(item),
        )

        for neighbor in neighbors:
            if neighbor in parent:
                continue

            parent[neighbor] = current
            depth[neighbor] = current_depth + 1

            if neighbor == target:
                path = [target]
                cursor = target
                while parent[cursor] is not None:
                    cursor = parent[cursor]  # type: ignore[index]
                    path.append(cursor)
                path.reverse()
                return path

            queue.append(neighbor)

    return None


def relation_sequence_for_nodes(
    graph: Any,
    nodes: Sequence[str],
) -> List[str]:
    if len(nodes) < 2:
        return []
    sequence: List[str] = []
    for source, target in zip(nodes[:-1], nodes[1:]):
        sequence.append(edge_relation(graph, source, target))
    return sequence


def original_sequence_and_sensitivity(
    base_graph: Any,
    path_nodes: Sequence[str],
    protection_core: Any,
) -> Tuple[List[str], List[int]]:
    if len(path_nodes) < 2:
        raise RuntimeError("Locked path contains fewer than two nodes.")

    relations: List[str] = []
    sensitive_flags: List[int] = []

    for source, target in zip(
        path_nodes[:-1],
        path_nodes[1:],
    ):
        if not base_graph.has_edge(source, target):
            raise RuntimeError(
                "Locked path edge missing in base graph: "
                f"{source} -- {target}"
            )

        relation = normalize_relation(
            base_graph.edges[source, target].get(
                "relation_type",
                "UNKNOWN",
            )
        )

        relations.append(relation)
        sensitive_flags.append(
            int(
                edge_sensitive(
                    base_graph,
                    source,
                    target,
                    protection_core,
                )
            )
        )

    return relations, sensitive_flags


def deterministic_side_edges(
    graph: Any,
    path_nodes: Sequence[str],
    per_node_limit: int = 1,
) -> List[Tuple[str, str, str]]:
    if per_node_limit <= 0:
        return []

    path_edge_keys = {
        frozenset((source, target))
        for source, target in zip(
            path_nodes[:-1],
            path_nodes[1:],
        )
    }

    rows: List[Tuple[str, str, str]] = []
    seen: set[frozenset[str]] = set()

    for node in path_nodes:
        if node not in graph:
            continue

        candidates: List[
            Tuple[str, frozenset[str], str, str, str]
        ] = []

        for neighbor in graph.neighbors(node):
            key = frozenset((node, neighbor))
            if key in path_edge_keys or key in seen:
                continue

            candidates.append(
                (
                    str(neighbor),
                    key,
                    node_label(graph, node),
                    edge_relation(graph, node, neighbor),
                    node_label(graph, neighbor),
                )
            )

        candidates.sort(key=lambda item: item[0])

        for (
            _,
            edge_key,
            source_label,
            relation,
            target_label,
        ) in candidates[:per_node_limit]:
            rows.append(
                (source_label, relation, target_label)
            )
            seen.add(edge_key)

    return rows


def build_retrieved_context(
    graph: Any,
    source: str,
    target: str,
    hop_budget: int,
    side_edges_per_node: int,
) -> Dict[str, Any]:
    retrieved_nodes = deterministic_shortest_path(
        graph,
        source,
        target,
        cutoff=hop_budget,
    )

    if retrieved_nodes is None:
        exposed_sequence = ["NOT_CONNECTED"]
        path_lines = [
            "NO PATH FOUND WITHIN THE LOCKED HOP BUDGET."
        ]
        local_nodes = [
            node
            for node in [source, target]
            if node in graph
        ]
    else:
        exposed_sequence = relation_sequence_for_nodes(
            graph,
            retrieved_nodes,
        )
        path_lines = []
        for index, (
            path_source,
            path_target,
        ) in enumerate(
            zip(
                retrieved_nodes[:-1],
                retrieved_nodes[1:],
            ),
            start=1,
        ):
            path_lines.append(
                f"{index}. "
                f"{node_label(graph, path_source)} "
                f"-- {edge_relation(graph, path_source, path_target)} -- "
                f"{node_label(graph, path_target)}"
            )
        local_nodes = retrieved_nodes

    side_edges = deterministic_side_edges(
        graph,
        local_nodes,
        per_node_limit=side_edges_per_node,
    )

    lines = [
        "QUERY NODES",
        f"source={node_label(graph, source)}",
        f"source_type={node_type(graph, source)}",
        f"target={node_label(graph, target)}",
        f"target_type={node_type(graph, target)}",
        f"locked_hop_budget={hop_budget}",
        "",
        "RETRIEVED ORDERED PATH EVIDENCE",
        *path_lines,
        "",
        "ADDITIONAL LOCAL GRAPH EVIDENCE",
    ]

    if side_edges:
        for source_label, relation, target_label in side_edges:
            lines.append(
                f"{source_label} -- {relation} -- {target_label}"
            )
    else:
        lines.append("NONE")

    return {
        "context": "\n".join(lines),
        "retrieved_path_nodes": (
            retrieved_nodes if retrieved_nodes is not None else []
        ),
        "exposed_relation_sequence": exposed_sequence,
        "retrieved_path_found": int(retrieved_nodes is not None),
        "retrieved_hops": (
            len(retrieved_nodes) - 1
            if retrieved_nodes is not None
            else None
        ),
        "side_edge_count": len(side_edges),
    }


def build_prompt(
    tokenizer: Any,
    context: str,
) -> str:
    system_message = (
        "You are a deterministic graph relation-sequence extractor. "
        "Use only the numbered lines under RETRIEVED ORDERED PATH EVIDENCE. "
        "For each numbered path line, copy only the relation label appearing "
        "between the two '--' separators. Preserve the numbered-line order. "
        "Join the copied relation labels with ' > '. "
        "Never output node names, node identifiers, entity names, article "
        "identifiers, document identifiers, explanations, prefixes, bullets, "
        "JSON, or code fences. "
        "The number of output relation labels must equal the number of "
        "numbered path lines. "
        "If the ordered path section says that no path was found, output "
        "exactly NOT_CONNECTED. "
        "Return exactly one line."
    )

    user_message = (
        f"{context}\n\n"
        "OUTPUT CONTRACT\n"
        "Correct example:\n"
        "1. NODE_A -- rel_x -- NODE_B\n"
        "2. NODE_B -- rel_y -- NODE_C\n"
        "Output: rel_x > rel_y\n\n"
        "Incorrect output: NODE_A > NODE_B > NODE_C\n"
        "Incorrect output: The relations are rel_x and rel_y.\n\n"
        "Now return only the ordered relation labels from the numbered "
        "RETRIEVED ORDERED PATH EVIDENCE."
    )

    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message},
    ]

    return tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )


def clean_generation_text(value: str) -> str:
    cleaned = str(value).strip()
    cleaned = re.sub(
        r"^```(?:json|text)?\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"\s*```$", "", cleaned)
    cleaned = re.sub(
        r"^(?:answer|output|relation sequence)\s*:\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    cleaned = cleaned.strip().strip("`'\"")
    return cleaned


def parse_relation_sequence(
    raw_answer: str,
    allowed_relations: Sequence[str],
) -> List[str]:
    cleaned = clean_generation_text(raw_answer)

    lookup = {
        normalize_relation(label).lower():
            normalize_relation(label)
        for label in allowed_relations
    }

    if cleaned.lower() in lookup:
        return [lookup[cleaned.lower()]]

    normalized_delimiters = re.sub(
        r"\s*(?:→|->|=>|\|)\s*",
        " > ",
        cleaned,
    )

    pieces = [
        part.strip().strip("[](){}'\"`.,;:")
        for part in re.split(
            r"\s*>\s*|\s*,\s*",
            normalized_delimiters,
        )
        if part.strip()
    ]

    mapped: List[str] = []
    mapping_failed = False

    for piece in pieces:
        key = normalize_relation(piece).lower()
        if key in lookup:
            mapped.append(lookup[key])
        else:
            mapping_failed = True
            break

    if mapped and not mapping_failed:
        return mapped

    answer_lower = cleaned.lower()
    matches: List[Tuple[int, int, str]] = []

    for canonical in sorted(
        set(lookup.values()),
        key=len,
        reverse=True,
    ):
        pattern = re.compile(
            re.escape(canonical.lower())
        )
        for match in pattern.finditer(answer_lower):
            matches.append(
                (
                    match.start(),
                    -len(canonical),
                    canonical,
                )
            )

    if not matches:
        return ["PARSE_ERROR"]

    matches.sort()
    sequence: List[str] = []
    occupied_until = -1

    for start, negative_length, canonical in matches:
        length = -negative_length
        if start < occupied_until:
            continue
        sequence.append(canonical)
        occupied_until = start + length

    return sequence if sequence else ["PARSE_ERROR"]


def multiset_metrics(
    prediction: Sequence[str],
    reference: Sequence[str],
) -> Dict[str, float]:
    pred_counter = Counter(prediction)
    ref_counter = Counter(reference)

    overlap = sum(
        min(pred_counter[token], ref_counter[token])
        for token in pred_counter.keys() | ref_counter.keys()
    )

    precision = (
        overlap / len(prediction)
        if prediction
        else (1.0 if not reference else 0.0)
    )

    recall = (
        overlap / len(reference)
        if reference
        else (1.0 if not prediction else 0.0)
    )

    f1 = (
        2.0 * precision * recall / (precision + recall)
        if precision + recall > 0
        else 0.0
    )

    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
    }


def sensitive_token_recall(
    prediction: Sequence[str],
    sensitive_reference: Sequence[str],
) -> float:
    if not sensitive_reference:
        return 0.0

    pred_counter = Counter(prediction)
    ref_counter = Counter(sensitive_reference)

    overlap = sum(
        min(pred_counter[token], ref_counter[token])
        for token in ref_counter
    )

    return float(overlap / len(sensitive_reference))


def task_key(
    dataset_name: str,
    protection_seed: int,
    variant: str,
    path_id: str,
    repeat_index: int,
) -> str:
    return "|".join([
        dataset_name,
        str(protection_seed),
        variant,
        path_id,
        str(repeat_index),
    ])


def resolve_protocol_directory(
    drive_root: Path,
) -> Tuple[Path, Path]:
    workspace_pointer = (
        drive_root
        / "safe_revision_workspaces"
        / "LATEST_SAFE_REVISION_WORKSPACE.txt"
    )
    if not workspace_pointer.is_file():
        raise FileNotFoundError(
            f"Workspace pointer not found: {workspace_pointer}"
        )

    workspace_info = read_pointer(workspace_pointer)
    workspace = Path(workspace_info["workspace"])

    protocol_pointer = (
        workspace
        / "experiment_planning"
        / "LATEST_E2E_RELATION_QA_PROTOCOL_LOCK.txt"
    )
    if not protocol_pointer.is_file():
        raise FileNotFoundError(
            f"Protocol pointer not found: {protocol_pointer}"
        )

    protocol_info = read_pointer(protocol_pointer)
    protocol_dir = Path(protocol_info["output_directory"])

    if not protocol_dir.is_dir():
        raise FileNotFoundError(
            f"Protocol directory not found: {protocol_dir}"
        )

    return workspace, protocol_dir


def select_manifest_rows(
    manifest: pd.DataFrame,
    mode: str,
) -> pd.DataFrame:
    if mode in {"pilot", "full"}:
        return (
            manifest
            .sort_values(
                [
                    "dataset_name",
                    "task",
                    "selection_index",
                    "path_id",
                ]
            )
            .reset_index(drop=True)
        )

    if mode == "dry-run":
        selected = (
            manifest
            .sort_values(
                [
                    "dataset_name",
                    "task",
                    "selection_index",
                    "path_id",
                ]
            )
            .groupby(
                ["dataset_name", "task"],
                sort=False,
                observed=True,
            )
            .head(2)
            .reset_index(drop=True)
        )

        if len(selected) != 20:
            raise RuntimeError(
                f"Expected 20 dry-run queries, observed {len(selected)}."
            )

        return selected

    raise ValueError(f"Unsupported mode: {mode}")


def validate_manifest_structure(
    manifest: pd.DataFrame,
    mode: str,
) -> None:
    missing = sorted(
        REQUIRED_MANIFEST_COLUMNS - set(manifest.columns)
    )
    if missing:
        raise RuntimeError(
            f"Manifest missing columns: {missing}"
        )

    if manifest["path_id"].duplicated().any():
        duplicates = manifest.loc[
            manifest["path_id"].duplicated(),
            "path_id",
        ].tolist()
        raise RuntimeError(
            f"Duplicate locked path IDs: {duplicates[:10]}"
        )

    observed_datasets = set(
        manifest["dataset_name"].astype(str)
    )
    if observed_datasets != set(DATASET_ORDER):
        raise RuntimeError(
            "Dataset mismatch. "
            f"Expected={DATASET_ORDER}, "
            f"Observed={sorted(observed_datasets)}"
        )

    observed_tasks = set(manifest["task"].astype(str))
    expected_tasks = {
        "non_sensitive_utility",
        "sensitive_disclosure",
    }
    if observed_tasks != expected_tasks:
        raise RuntimeError(
            f"Task mismatch: {sorted(observed_tasks)}"
        )

    expected_rows_by_mode = {
        "dry-run": 20,
        "pilot": 96,
        "full": 718,
    }
    expected_rows = expected_rows_by_mode[mode]
    if len(manifest) != expected_rows:
        raise RuntimeError(
            f"Expected {expected_rows} {mode} queries, "
            f"observed {len(manifest)}."
        )


def resolve_drive_data_file(
    drive_root: Path,
    configured_path: str,
) -> Path:
    configured = Path(str(configured_path))
    basename = configured.name

    preferred_candidates = [
        drive_root / configured,
        drive_root / "data" / basename,
        drive_root / "datasets" / basename,
    ]

    candidates: List[Path] = []

    for candidate in preferred_candidates:
        if candidate.is_file():
            candidates.append(candidate.resolve())

    if not candidates:
        candidates = sorted({
            candidate.resolve()
            for candidate in drive_root.rglob(basename)
            if candidate.is_file()
        })

    if not candidates:
        raise FileNotFoundError(
            "Dataset CSV could not be located in Google Drive.\n"
            f"Configured path: {configured_path}\n"
            f"Expected basename: {basename}\n"
            f"Drive root: {drive_root}"
        )

    if len(candidates) == 1:
        return candidates[0]

    hash_groups: Dict[str, List[Path]] = {}

    for candidate in candidates:
        digest = sha256_file(candidate)
        hash_groups.setdefault(digest, []).append(candidate)

    if len(hash_groups) != 1:
        details = []
        for digest, paths in sorted(hash_groups.items()):
            details.append(f"SHA256 {digest}")
            details.extend(f"  {path}" for path in paths)

        raise RuntimeError(
            "Multiple non-identical dataset CSV copies were found. "
            "Automatic selection is unsafe.\n"
            f"File: {basename}\n"
            + "\n".join(details)
        )

    # All copies are byte-identical. Prefer the shortest stable Drive path.
    return sorted(
        candidates,
        key=lambda candidate: (
            len(candidate.parts),
            len(str(candidate)),
            str(candidate),
        ),
    )[0]


def load_base_configs(
    repo_root: Path,
    drive_root: Path,
) -> Dict[str, Dict[str, Any]]:
    configs: Dict[str, Dict[str, Any]] = {}

    for dataset_name, filename in CONFIG_FILES.items():
        path = repo_root / filename
        if not path.is_file():
            raise FileNotFoundError(
                f"Dataset config missing: {path}"
            )

        with path.open("r", encoding="utf-8") as handle:
            config = json.load(handle)

        config["dataset_name"] = dataset_name

        for key in DATA_PATH_KEYS:
            if key not in config:
                raise RuntimeError(
                    f"Config {path.name} is missing {key}."
                )

            configured_value = str(config[key])
            configured_candidate = (
                repo_root / configured_value
            )

            if configured_candidate.is_file():
                resolved = configured_candidate.resolve()
            else:
                resolved = resolve_drive_data_file(
                    drive_root,
                    configured_value,
                )

            config[key] = str(resolved)

        configs[dataset_name] = config

        print(
            "RESOLVED_DATASET_PATHS:",
            dataset_name,
            "nodes=",
            config["node_csv_path"],
            "edges=",
            config["edge_csv_path"],
        )

    return configs


def validate_locked_queries(
    manifest: pd.DataFrame,
    base_graphs: Mapping[str, Any],
    protection_core: Any,
) -> List[Dict[str, Any]]:
    validated: List[Dict[str, Any]] = []

    for record in manifest.itertuples(index=False):
        dataset_name = str(record.dataset_name)
        graph = base_graphs[dataset_name]

        try:
            path_nodes = json.loads(record.path_nodes_json)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"Invalid path_nodes_json for {record.path_id}"
            ) from exc

        path_nodes = [str(node) for node in path_nodes]

        if not path_nodes:
            raise RuntimeError(
                f"Empty path for {record.path_id}"
            )

        if path_nodes[0] != str(record.source):
            raise RuntimeError(
                f"Source mismatch for {record.path_id}"
            )

        if path_nodes[-1] != str(record.target):
            raise RuntimeError(
                f"Target mismatch for {record.path_id}"
            )

        expected_hop = len(path_nodes) - 1
        if expected_hop != int(record.hop):
            raise RuntimeError(
                f"Hop mismatch for {record.path_id}: "
                f"manifest={record.hop}, path={expected_hop}"
            )

        if expected_hop != int(record.path_edge_count):
            raise RuntimeError(
                f"Edge-count mismatch for {record.path_id}"
            )

        relations, sensitivity = (
            original_sequence_and_sensitivity(
                graph,
                path_nodes,
                protection_core,
            )
        )

        sensitive_count = sum(sensitivity)
        non_sensitive_count = len(sensitivity) - sensitive_count

        if sensitive_count != int(record.sensitive_edge_count):
            raise RuntimeError(
                f"Sensitive-edge mismatch for {record.path_id}: "
                f"manifest={record.sensitive_edge_count}, "
                f"computed={sensitive_count}"
            )

        if non_sensitive_count != int(
            record.non_sensitive_edge_count
        ):
            raise RuntimeError(
                f"Non-sensitive-edge mismatch for {record.path_id}"
            )

        expected_task = (
            "sensitive_disclosure"
            if sensitive_count > 0
            else "non_sensitive_utility"
        )

        if expected_task != str(record.task):
            raise RuntimeError(
                f"Task mismatch for {record.path_id}: "
                f"manifest={record.task}, computed={expected_task}"
            )

        validated.append({
            "path_id": str(record.path_id),
            "dataset_name": dataset_name,
            "path_nodes": path_nodes,
            "gold_relation_sequence": relations,
            "gold_sensitive_flags": sensitivity,
        })

    return validated


def validate_protected_graph(
    display_variant: str,
    base_graph: Any,
    protected_graph: Any,
) -> Dict[str, Any]:
    base_degrees = dict(base_graph.degree())
    protected_degrees = dict(protected_graph.degree())

    changed_degree_nodes = sum(
        base_degrees[node] != protected_degrees.get(node)
        for node in base_graph.nodes()
    )

    audit = copy.deepcopy(
        protected_graph.graph.get(
            "protection_audit",
            {},
        )
    )

    exact_degree = int(changed_degree_nodes == 0)

    if display_variant in {"full", "random_full_budget", "2K"}:
        if exact_degree != 1:
            raise RuntimeError(
                f"{display_variant} failed exact degree preservation: "
                f"{changed_degree_nodes} nodes changed."
            )

    if display_variant == "2K":
        jdd_exact = int(
            audit.get(
                "joint_degree_distribution_preserved_exactly",
                0,
            )
        )
        if jdd_exact != 1:
            raise RuntimeError(
                "2K failed exact joint-degree preservation."
            )

    return {
        "changed_degree_nodes": int(changed_degree_nodes),
        "degree_preserved_exactly": exact_degree,
        "joint_degree_distribution_preserved_exactly": int(
            audit.get(
                "joint_degree_distribution_preserved_exactly",
                display_variant != "2K",
            )
        ),
        "protection_audit": audit,
    }


def load_model(
    allow_model_download: bool,
    allow_cpu: bool,
) -> Tuple[Any, Any, str]:
    try:
        from transformers import (
            AutoModelForCausalLM,
            AutoTokenizer,
        )
    except ImportError as exc:
        raise RuntimeError(
            "The 'transformers' package is required. "
            "Install it in Colab before running this script."
        ) from exc

    if not torch.cuda.is_available() and not allow_cpu:
        raise RuntimeError(
            "CUDA GPU is required. Reconnect Colab with a GPU runtime, "
            "or use --allow-cpu only for debugging."
        )

    set_all_seeds(GENERATION_SEED)

    local_only = not allow_model_download

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID,
        local_files_only=local_only,
    )

    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    tokenizer.padding_side = "left"

    if torch.cuda.is_available():
        dtype = (
            torch.bfloat16
            if torch.cuda.is_bf16_supported()
            else torch.float16
        )

        model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID,
            torch_dtype=dtype,
            device_map="auto",
            local_files_only=local_only,
        )
        device_label = str(model.device)
    else:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID,
            torch_dtype=torch.float32,
            local_files_only=local_only,
        )
        model.to("cpu")
        device_label = "cpu"

    model.eval()

    return tokenizer, model, device_label


def generate_batch(
    tokenizer: Any,
    model: Any,
    prompts: Sequence[str],
) -> Tuple[List[str], float]:
    inputs = tokenizer(
        list(prompts),
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=MAX_INPUT_TOKENS,
    )

    target_device = model.device
    inputs = {
        key: value.to(target_device)
        for key, value in inputs.items()
    }

    input_width = inputs["input_ids"].shape[1]

    if torch.cuda.is_available():
        torch.cuda.synchronize()

    start = time.perf_counter()

    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
            use_cache=True,
        )

    if torch.cuda.is_available():
        torch.cuda.synchronize()

    runtime = time.perf_counter() - start

    answers: List[str] = []

    for output in outputs:
        generated = output[input_width:]
        answers.append(
            tokenizer.decode(
                generated,
                skip_special_tokens=True,
            ).strip()
        )

    return answers, float(runtime)


def create_run_directory(
    workspace: Path,
    mode: str,
    requested: str | None,
) -> Path:
    if requested:
        run_dir = Path(requested).resolve()
        run_dir.mkdir(parents=True, exist_ok=True)
        return run_dir

    timestamp = dt.datetime.now(
        dt.timezone.utc
    ).strftime("%Y%m%dT%H%M%SZ")

    run_dir = (
        workspace
        / "experiments"
        / f"TAFP_E2E_RELATION_QA_{mode.upper()}_{timestamp}"
    )
    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir


def prepare_metadata(
    run_dir: Path,
    mode: str,
    repo_root: Path,
    protocol_dir: Path,
    manifest_path: Path,
    branch: str,
    head: str,
    script_path: Path,
    batch_size: int,
    side_edges_per_node: int,
    allow_model_download: bool,
) -> Dict[str, Any]:
    metadata_path = run_dir / "RUN_METADATA.json"

    payload = {
        "status": "INITIALIZED",
        "runner_version": "1.3-full-locked-manifest-support",
        "mode": mode,
        "created_utc": dt.datetime.now(
            dt.timezone.utc
        ).isoformat(),
        "repo_root": str(repo_root),
        "protocol_dir": str(protocol_dir),
        "manifest_path": str(manifest_path),
        "manifest_sha256": sha256_file(manifest_path),
        "protocol_lock_sha256": sha256_file(
            protocol_dir / "PROTOCOL_LOCK.json"
        ),
        "branch": branch,
        "head": head,
        "runner_path": str(script_path),
        "runner_sha256": sha256_file(script_path),
        "model_id": MODEL_ID,
        "max_input_tokens": MAX_INPUT_TOKENS,
        "max_new_tokens": MAX_NEW_TOKENS,
        "generation_seed": GENERATION_SEED,
        "prompt_contract_version": PROMPT_CONTRACT_VERSION,
        "batch_size": batch_size,
        "side_edges_per_node": side_edges_per_node,
        "allow_model_download": allow_model_download,
        "variants": DISPLAY_VARIANTS,
        "protection_seeds": (
            DRY_RUN_SEEDS
            if mode == "dry-run"
            else PILOT_SEEDS
            if mode == "pilot"
            else FULL_SEEDS
        ),
        "generation_repeats": (
            2 if mode == "dry-run" else 1
        ),
        "repository_files_modified": False,
        "manuscript_modified": False,
    }

    if metadata_path.is_file():
        existing = json.loads(
            metadata_path.read_text(encoding="utf-8")
        )

        locked_keys = [
            "mode",
            "manifest_sha256",
            "protocol_lock_sha256",
            "head",
            "model_id",
            "max_new_tokens",
            "variants",
            "protection_seeds",
            "generation_repeats",
        ]

        mismatches = {
            key: {
                "existing": existing.get(key),
                "current": payload.get(key),
            }
            for key in locked_keys
            if existing.get(key) != payload.get(key)
        }

        if mismatches:
            raise RuntimeError(
                "Resume metadata mismatch:\n"
                + json.dumps(
                    mismatches,
                    indent=2,
                    ensure_ascii=False,
                )
            )

        return existing

    atomic_write_json(metadata_path, payload)

    shutil.copy2(
        manifest_path,
        run_dir / manifest_path.name,
    )
    shutil.copy2(
        protocol_dir / "PROTOCOL_LOCK.json",
        run_dir / "PROTOCOL_LOCK.json",
    )
    shutil.copy2(
        protocol_dir / "PROTOCOL_LOCK.md",
        run_dir / "PROTOCOL_LOCK.md",
    )

    return payload


def dataframe_json_safe(
    rows: Sequence[Mapping[str, Any]],
) -> pd.DataFrame:
    converted: List[Dict[str, Any]] = []

    for row in rows:
        item: Dict[str, Any] = {}
        for key, value in row.items():
            if isinstance(value, (list, dict, tuple)):
                item[key] = json.dumps(
                    value,
                    ensure_ascii=False,
                    sort_keys=True,
                )
            else:
                item[key] = value
        converted.append(item)

    return pd.DataFrame(converted)


def summarize_results(
    rows: Sequence[Mapping[str, Any]],
    run_dir: Path,
    mode: str,
    expected_rows: int,
) -> Dict[str, Any]:
    if not rows:
        raise RuntimeError("No result rows were produced.")

    details = dataframe_json_safe(rows)

    unique_columns = [
        "dataset_name",
        "protection_seed",
        "variant",
        "path_id",
        "repeat_index",
    ]

    duplicates = int(
        details.duplicated(unique_columns).sum()
    )

    metric_columns = [
        "parse_success",
        "exact_sequence_match",
        "relation_token_precision",
        "relation_token_recall",
        "relation_token_f1",
        "retrieved_evidence_recall",
        "faithfulness_to_retrieved_evidence",
        "faithfulness_token_f1",
        "original_sensitive_relation_disclosed",
        "sensitive_token_recall",
        "protected_marker_response",
        "retrieved_sensitive_evidence_exposure",
        "retrieved_path_found",
        "matches_exposed_sequence",
    ]

    for column in metric_columns:
        details[column] = pd.to_numeric(
            details[column],
            errors="raise",
        )

    seed_summary = (
        details.groupby(
            [
                "dataset_name",
                "protection_seed",
                "variant",
                "task",
            ],
            observed=True,
        )[metric_columns]
        .mean()
        .reset_index()
    )

    overall_summary = (
        details.groupby(
            ["variant", "task"],
            observed=True,
        )[metric_columns]
        .agg(["mean", "std", "count"])
    )
    overall_summary.columns = [
        "_".join(column).strip("_")
        for column in overall_summary.columns
    ]
    overall_summary = overall_summary.reset_index()

    parse_failure_rate = float(
        1.0 - details["parse_success"].mean()
    )

    expected_datasets = set(DATASET_ORDER)
    observed_datasets = set(details["dataset_name"])
    observed_variants = set(details["variant"])

    query_drift = 0
    reference_queries = set(
        details[
            details["variant"] == "baseline"
        ]["path_id"]
    )

    for variant in DISPLAY_VARIANTS:
        variant_queries = set(
            details[
                details["variant"] == variant
            ]["path_id"]
        )
        if variant_queries != reference_queries:
            query_drift += len(
                reference_queries.symmetric_difference(
                    variant_queries
                )
            )

    determinism_mismatches = 0

    if mode == "dry-run":
        pivot_keys = [
            "dataset_name",
            "protection_seed",
            "variant",
            "path_id",
        ]

        for _, group in details.groupby(
            pivot_keys,
            observed=True,
        ):
            if group["repeat_index"].nunique() != 2:
                determinism_mismatches += 1
                continue

            raw_values = group["raw_answer"].astype(str).tolist()
            parsed_values = group[
                "parsed_relation_sequence_json"
            ].astype(str).tolist()

            if (
                len(set(raw_values)) != 1
                or len(set(parsed_values)) != 1
            ):
                determinism_mismatches += 1

    expected_seed_count = (
        len(DRY_RUN_SEEDS)
        if mode == "dry-run"
        else len(PILOT_SEEDS)
        if mode == "pilot"
        else len(FULL_SEEDS)
    )

    audit_pass = (
        len(details) == expected_rows
        and duplicates == 0
        and observed_datasets == expected_datasets
        and observed_variants == set(DISPLAY_VARIANTS)
        and details["protection_seed"].nunique()
        == expected_seed_count
        and query_drift == 0
        and parse_failure_rate <= 0.02
        and (
            determinism_mismatches == 0
            if mode == "dry-run"
            else True
        )
    )

    details_path = run_dir / "relation_qa_details.csv"
    seed_path = run_dir / "relation_qa_seed_summary.csv"
    overall_path = run_dir / "relation_qa_overall_summary.csv"

    details.to_csv(details_path, index=False)
    seed_summary.to_csv(seed_path, index=False)
    overall_summary.to_csv(overall_path, index=False)

    audit = {
        "status": "PASS" if audit_pass else "FAIL",
        "audit_pass": int(audit_pass),
        "mode": mode,
        "expected_rows": expected_rows,
        "actual_rows": len(details),
        "duplicate_rows": duplicates,
        "dataset_count": details["dataset_name"].nunique(),
        "variant_count": details["variant"].nunique(),
        "protection_seed_count":
            details["protection_seed"].nunique(),
        "query_count": details["path_id"].nunique(),
        "query_set_drift_count": int(query_drift),
        "parse_failure_rate": parse_failure_rate,
        "determinism_mismatches":
            int(determinism_mismatches),
        "all_degree_preservation_checks_pass": int(
            (
                details[
                    details["variant"].isin(
                        [
                            "full",
                            "random_full_budget",
                            "2K",
                        ]
                    )
                ]["degree_preserved_exactly"]
                == 1
            ).all()
        ),
        "all_2k_joint_degree_checks_pass": int(
            (
                details[
                    details["variant"] == "2K"
                ][
                    "joint_degree_distribution_preserved_exactly"
                ]
                == 1
            ).all()
        ),
        "details_csv": str(details_path),
        "seed_summary_csv": str(seed_path),
        "overall_summary_csv": str(overall_path),
    }

    atomic_write_json(
        run_dir / "RUN_AUDIT.json",
        audit,
    )

    return audit


def write_sha256s(run_dir: Path) -> Path:
    checksum_path = run_dir / "SHA256SUMS.txt"
    candidates = sorted(
        path
        for path in run_dir.iterdir()
        if path.is_file()
        and path.name != checksum_path.name
    )

    lines = [
        f"{sha256_file(path)}  {path.name}"
        for path in candidates
    ]

    atomic_write_text(
        checksum_path,
        "\n".join(lines) + "\n",
    )

    return checksum_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        choices=["dry-run", "pilot", "full"],
        default="dry-run",
    )
    parser.add_argument(
        "--repo-root",
        default="/content/tafp-graphrag",
    )
    parser.add_argument(
        "--drive-root",
        default="/content/drive/MyDrive/TAFP_GraphRAG",
    )
    parser.add_argument(
        "--run-dir",
        default=None,
        help=(
            "Existing run directory for resume. "
            "Omit to create a new timestamped run."
        ),
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=2,
    )
    parser.add_argument(
        "--side-edges-per-node",
        type=int,
        default=1,
    )
    parser.add_argument(
        "--allow-model-download",
        action="store_true",
    )
    parser.add_argument(
        "--allow-cpu",
        action="store_true",
    )
    args = parser.parse_args()

    if args.batch_size < 1:
        raise ValueError("--batch-size must be at least 1.")
    if args.side_edges_per_node < 0:
        raise ValueError(
            "--side-edges-per-node cannot be negative."
        )

    repo_root = Path(args.repo_root).resolve()
    drive_root = Path(args.drive_root).resolve()
    script_path = Path(__file__).resolve()

    if not (repo_root / ".git").is_dir():
        raise FileNotFoundError(
            f"Repository not found: {repo_root}"
        )
    if not drive_root.is_dir():
        raise FileNotFoundError(
            f"Drive root not found: {drive_root}"
        )

    branch = run_command(
        ["git", "branch", "--show-current"],
        repo_root,
        check=True,
    ).stdout.strip()

    head = run_command(
        ["git", "rev-parse", "HEAD"],
        repo_root,
        check=True,
    ).stdout.strip()

    git_status = run_command(
        [
            "git",
            "status",
            "--short",
            "--untracked-files=all",
        ],
        repo_root,
        check=True,
    ).stdout.strip()

    if not branch.startswith(EXPECTED_BRANCH_PREFIX):
        raise RuntimeError(
            f"Unsafe branch for the locked pilot: {branch}"
        )

    if head != EXPECTED_HEAD:
        raise RuntimeError(
            "Repository HEAD differs from the locked protocol.\n"
            f"Expected: {EXPECTED_HEAD}\n"
            f"Actual:   {head}"
        )

    if git_status:
        raise RuntimeError(
            "Repository working tree is not clean:\n"
            + git_status
        )

    workspace, protocol_dir = (
        resolve_protocol_directory(drive_root)
    )

    protocol_json_path = (
        protocol_dir / "PROTOCOL_LOCK.json"
    )
    manifest_path = (
        protocol_dir / (
            "FULL_QUERY_MANIFEST.csv"
            if args.mode == "full"
            else "PILOT_QUERY_MANIFEST.csv"
        )
    )

    if not protocol_json_path.is_file():
        raise FileNotFoundError(protocol_json_path)
    if not manifest_path.is_file():
        raise FileNotFoundError(manifest_path)

    protocol_lock = json.loads(
        protocol_json_path.read_text(
            encoding="utf-8"
        )
    )

    if protocol_lock.get("protocol_version") != "1.0-LOCKED":
        raise RuntimeError(
            "Unexpected protocol version: "
            f"{protocol_lock.get('protocol_version')}"
        )

    if protocol_lock.get("model", {}).get(
        "identifier"
    ) != MODEL_ID:
        raise RuntimeError(
            "Locked model ID does not match the runner."
        )

    manifest_all = pd.read_csv(manifest_path)
    manifest = select_manifest_rows(
        manifest_all,
        args.mode,
    )
    validate_manifest_structure(
        manifest,
        args.mode,
    )

    sys.path.insert(0, str(repo_root))
    os.chdir(repo_root)

    from dataset_loader import build_graph_from_config
    import protections_v8 as protection_core
    import protections_v8_baselines as standard_protection
    from protections_v8_dk2_baseline import (
        apply_variant as apply_dk2_variant,
    )

    base_configs = load_base_configs(
        repo_root,
        drive_root,
    )

    base_graphs: Dict[str, Any] = {}
    dataset_relation_vocabulary: Dict[str, List[str]] = {}

    print("VALIDATING BASE GRAPHS AND LOCKED QUERIES")

    for dataset_name in DATASET_ORDER:
        base_config = copy.deepcopy(
            base_configs[dataset_name]
        )
        base_config["seed"] = 42

        graph = build_graph_from_config(
            base_config
        )
        base_graphs[dataset_name] = graph
        dataset_relation_vocabulary[dataset_name] = sorted({
            normalize_relation(
                attributes.get(
                    "relation_type",
                    "UNKNOWN",
                )
            )
            for _, _, attributes in graph.edges(data=True)
        } | SPECIAL_RELATIONS)

        print(
            dataset_name,
            "nodes=",
            graph.number_of_nodes(),
            "edges=",
            graph.number_of_edges(),
        )

    validated_rows = validate_locked_queries(
        manifest,
        base_graphs,
        protection_core,
    )

    validation_lookup = {
        item["path_id"]: item
        for item in validated_rows
    }

    print(
        "LOCKED_QUERY_VALIDATION: PASS",
        "queries=",
        len(validated_rows),
    )

    seeds = (
        DRY_RUN_SEEDS
        if args.mode == "dry-run"
        else PILOT_SEEDS
        if args.mode == "pilot"
        else FULL_SEEDS
    )
    repeats = 2 if args.mode == "dry-run" else 1

    expected_rows = (
        len(manifest)
        * len(seeds)
        * len(DISPLAY_VARIANTS)
        * repeats
    )

    locked_expected_by_mode = {
        "dry-run": 160,
        "pilot": 1152,
        "full": 43080,
    }
    locked_expected = locked_expected_by_mode[args.mode]

    if expected_rows != locked_expected:
        raise RuntimeError(
            f"Expected locked count {locked_expected}, "
            f"computed {expected_rows}."
        )

    run_dir = create_run_directory(
        workspace,
        args.mode,
        args.run_dir,
    )

    metadata = prepare_metadata(
        run_dir=run_dir,
        mode=args.mode,
        repo_root=repo_root,
        protocol_dir=protocol_dir,
        manifest_path=manifest_path,
        branch=branch,
        head=head,
        script_path=script_path,
        batch_size=args.batch_size,
        side_edges_per_node=args.side_edges_per_node,
        allow_model_download=args.allow_model_download,
    )

    results_jsonl = run_dir / "results_checkpoint.jsonl"
    errors_jsonl = run_dir / "errors_checkpoint.jsonl"

    existing_rows = load_jsonl(results_jsonl)

    completed_keys = {
        str(row["task_key"])
        for row in existing_rows
    }

    if len(completed_keys) != len(existing_rows):
        raise RuntimeError(
            "Duplicate task keys found in existing checkpoint."
        )

    print("RUN_DIRECTORY:", run_dir)
    print("EXPECTED_ROWS:", expected_rows)
    print("ALREADY_COMPLETED:", len(completed_keys))
    print("PENDING:", expected_rows - len(completed_keys))

    if len(completed_keys) == expected_rows:
        print("Checkpoint already complete; rebuilding summaries.")
        audit = summarize_results(
            existing_rows,
            run_dir,
            args.mode,
            expected_rows,
        )

        metadata["status"] = (
            "COMPLETE_PASS"
            if audit["audit_pass"] == 1
            else "COMPLETE_FAIL"
        )
        metadata["completed_utc"] = dt.datetime.now(
            dt.timezone.utc
        ).isoformat()
        metadata["actual_rows"] = len(existing_rows)
        metadata["audit_pass"] = audit["audit_pass"]

        atomic_write_json(
            run_dir / "RUN_METADATA.json",
            metadata,
        )
        write_sha256s(run_dir)

        print("\nFINAL AUDIT")
        print(
            json.dumps(
                audit,
                indent=2,
                ensure_ascii=False,
            )
        )

        if audit["audit_pass"] != 1:
            raise RuntimeError(
                "Completed checkpoint exists, but the locked audit failed."
            )

        return 0

    print("LOADING MODEL:", MODEL_ID)

    tokenizer, model, device_label = load_model(
        allow_model_download=args.allow_model_download,
        allow_cpu=args.allow_cpu,
    )

    print("MODEL_DEVICE:", device_label)

    metadata["status"] = "RUNNING"
    metadata["model_device"] = device_label
    metadata["expected_rows"] = expected_rows
    metadata["resume_completed_rows"] = len(completed_keys)
    atomic_write_json(
        run_dir / "RUN_METADATA.json",
        metadata,
    )

    manifest_by_dataset = {
        dataset_name: (
            manifest[
                manifest["dataset_name"]
                == dataset_name
            ]
            .sort_values(
                [
                    "task",
                    "selection_index",
                    "path_id",
                ]
            )
            .reset_index(drop=True)
        )
        for dataset_name in DATASET_ORDER
    }

    total_completed = len(completed_keys)

    for dataset_name in DATASET_ORDER:
        base_graph = base_graphs[dataset_name]
        dataset_manifest = manifest_by_dataset[
            dataset_name
        ]

        for protection_seed in seeds:
            protection_config = copy.deepcopy(
                base_configs[dataset_name]
            )
            protection_config["seed"] = (
                int(protection_seed)
            )

            for display_variant in DISPLAY_VARIANTS:
                internal_variant = INTERNAL_VARIANT[
                    display_variant
                ]

                protection_start = time.perf_counter()

                if display_variant == "2K":
                    protected_graph = apply_dk2_variant(
                        base_graph,
                        ({}, {}, {}),
                        internal_variant,
                        protection_config,
                    )
                else:
                    protected_graph = (
                        standard_protection.apply_variant(
                            base_graph,
                            ({}, {}, {}),
                            internal_variant,
                            protection_config,
                        )
                    )

                protection_seconds = (
                    time.perf_counter()
                    - protection_start
                )

                graph_audit = validate_protected_graph(
                    display_variant,
                    base_graph,
                    protected_graph,
                )

                for repeat_index in range(1, repeats + 1):
                    pending_items: List[Dict[str, Any]] = []

                    for record in dataset_manifest.itertuples(
                        index=False
                    ):
                        key = task_key(
                            dataset_name=dataset_name,
                            protection_seed=protection_seed,
                            variant=display_variant,
                            path_id=str(record.path_id),
                            repeat_index=repeat_index,
                        )

                        if key in completed_keys:
                            continue

                        locked = validation_lookup[
                            str(record.path_id)
                        ]

                        retrieved = build_retrieved_context(
                            graph=protected_graph,
                            source=str(record.source),
                            target=str(record.target),
                            hop_budget=int(record.hop),
                            side_edges_per_node=(
                                args.side_edges_per_node
                            ),
                        )

                        prompt = build_prompt(
                            tokenizer,
                            retrieved["context"],
                        )

                        exposed_sequence = [
                            normalize_relation(value)
                            for value in retrieved[
                                "exposed_relation_sequence"
                            ]
                        ]

                        allowed_relations = sorted(
                            set(
                                dataset_relation_vocabulary[
                                    dataset_name
                                ]
                            )
                            | set(exposed_sequence)
                            | SPECIAL_RELATIONS
                        )

                        pending_items.append({
                            "task_key": key,
                            "record": record,
                            "locked": locked,
                            "retrieved": retrieved,
                            "prompt": prompt,
                            "prompt_sha256": sha256_text(
                                prompt
                            ),
                            "allowed_relations":
                                allowed_relations,
                        })

                    for batch_start in range(
                        0,
                        len(pending_items),
                        args.batch_size,
                    ):
                        batch = pending_items[
                            batch_start:
                            batch_start + args.batch_size
                        ]

                        prompts = [
                            item["prompt"]
                            for item in batch
                        ]

                        try:
                            answers, batch_runtime = (
                                generate_batch(
                                    tokenizer,
                                    model,
                                    prompts,
                                )
                            )
                        except Exception as exc:
                            error_payload = {
                                "timestamp_utc": dt.datetime.now(
                                    dt.timezone.utc
                                ).isoformat(),
                                "dataset_name": dataset_name,
                                "protection_seed":
                                    protection_seed,
                                "variant": display_variant,
                                "repeat_index":
                                    repeat_index,
                                "task_keys": [
                                    item["task_key"]
                                    for item in batch
                                ],
                                "error_type":
                                    type(exc).__name__,
                                "error": repr(exc),
                            }
                            append_jsonl(
                                errors_jsonl,
                                error_payload,
                            )
                            raise

                        per_item_runtime = (
                            batch_runtime / len(batch)
                        )

                        for item, raw_answer in zip(
                            batch,
                            answers,
                        ):
                            record = item["record"]
                            locked = item["locked"]
                            retrieved = item["retrieved"]

                            parsed_sequence = (
                                parse_relation_sequence(
                                    raw_answer,
                                    item[
                                        "allowed_relations"
                                    ],
                                )
                            )

                            parse_success = int(
                                parsed_sequence
                                != ["PARSE_ERROR"]
                            )

                            gold_sequence = [
                                normalize_relation(value)
                                for value in locked[
                                    "gold_relation_sequence"
                                ]
                            ]

                            sensitive_flags = [
                                int(value)
                                for value in locked[
                                    "gold_sensitive_flags"
                                ]
                            ]

                            sensitive_gold_tokens = [
                                relation
                                for relation, is_sensitive
                                in zip(
                                    gold_sequence,
                                    sensitive_flags,
                                )
                                if is_sensitive
                            ]

                            exposed_sequence = [
                                normalize_relation(value)
                                for value in retrieved[
                                    "exposed_relation_sequence"
                                ]
                            ]

                            gold_metrics = multiset_metrics(
                                parsed_sequence,
                                gold_sequence,
                            )

                            exposed_metrics = (
                                multiset_metrics(
                                    parsed_sequence,
                                    exposed_sequence,
                                )
                            )

                            retrieved_gold_metrics = (
                                multiset_metrics(
                                    exposed_sequence,
                                    gold_sequence,
                                )
                            )

                            sensitive_prediction_recall = (
                                sensitive_token_recall(
                                    parsed_sequence,
                                    sensitive_gold_tokens,
                                )
                            )

                            sensitive_retrieval_recall = (
                                sensitive_token_recall(
                                    exposed_sequence,
                                    sensitive_gold_tokens,
                                )
                            )

                            result = {
                                "task_key":
                                    item["task_key"],
                                "timestamp_utc":
                                    dt.datetime.now(
                                        dt.timezone.utc
                                    ).isoformat(),
                                "mode": args.mode,
                                "dataset_name":
                                    dataset_name,
                                "protection_seed":
                                    int(protection_seed),
                                "variant":
                                    display_variant,
                                "internal_variant":
                                    internal_variant,
                                "repeat_index":
                                    int(repeat_index),
                                "path_id":
                                    str(record.path_id),
                                "task":
                                    str(record.task),
                                "path_scope":
                                    str(record.path_scope),
                                "source":
                                    str(record.source),
                                "target":
                                    str(record.target),
                                "locked_hop_budget":
                                    int(record.hop),
                                "locked_path_nodes":
                                    locked["path_nodes"],
                                "gold_relation_sequence":
                                    gold_sequence,
                                "gold_sensitive_flags":
                                    sensitive_flags,
                                "gold_sensitive_relations":
                                    sensitive_gold_tokens,
                                "retrieved_path_nodes":
                                    retrieved[
                                        "retrieved_path_nodes"
                                    ],
                                "exposed_relation_sequence":
                                    exposed_sequence,
                                "retrieved_path_found":
                                    int(
                                        retrieved[
                                            "retrieved_path_found"
                                        ]
                                    ),
                                "retrieved_hops":
                                    retrieved[
                                        "retrieved_hops"
                                    ],
                                "side_edge_count":
                                    int(
                                        retrieved[
                                            "side_edge_count"
                                        ]
                                    ),
                                "retrieved_context":
                                    retrieved["context"],
                                "prompt_sha256":
                                    item["prompt_sha256"],
                                "raw_answer":
                                    raw_answer,
                                "parsed_relation_sequence":
                                    parsed_sequence,
                                "parsed_relation_sequence_json":
                                    json.dumps(
                                        parsed_sequence,
                                        ensure_ascii=False,
                                    ),
                                "parse_success":
                                    parse_success,
                                "exact_sequence_match":
                                    int(
                                        parsed_sequence
                                        == gold_sequence
                                    ),
                                "relation_token_precision":
                                    gold_metrics[
                                        "precision"
                                    ],
                                "relation_token_recall":
                                    gold_metrics["recall"],
                                "relation_token_f1":
                                    gold_metrics["f1"],
                                "retrieved_evidence_recall":
                                    retrieved_gold_metrics[
                                        "recall"
                                    ],
                                "faithfulness_to_retrieved_evidence":
                                    int(
                                        parsed_sequence
                                        == exposed_sequence
                                    ),
                                "faithfulness_token_f1":
                                    exposed_metrics["f1"],
                                "matches_exposed_sequence":
                                    int(
                                        parsed_sequence
                                        == exposed_sequence
                                    ),
                                "original_sensitive_relation_disclosed":
                                    int(
                                        sensitive_prediction_recall
                                        > 0.0
                                    ),
                                "sensitive_token_recall":
                                    (
                                        sensitive_prediction_recall
                                    ),
                                "protected_marker_response":
                                    int(
                                        "PRIVATE_RELATION"
                                        in parsed_sequence
                                    ),
                                "retrieved_sensitive_evidence_exposure":
                                    (
                                        sensitive_retrieval_recall
                                    ),
                                "not_connected_response":
                                    int(
                                        parsed_sequence
                                        == ["NOT_CONNECTED"]
                                    ),
                                "protection_seconds":
                                    float(
                                        protection_seconds
                                    ),
                                "generation_batch_seconds":
                                    float(
                                        batch_runtime
                                    ),
                                "generation_seconds_estimate":
                                    float(
                                        per_item_runtime
                                    ),
                                "degree_changed_nodes":
                                    graph_audit[
                                        "changed_degree_nodes"
                                    ],
                                "degree_preserved_exactly":
                                    graph_audit[
                                        "degree_preserved_exactly"
                                    ],
                                "joint_degree_distribution_preserved_exactly":
                                    graph_audit[
                                        "joint_degree_distribution_preserved_exactly"
                                    ],
                                "protection_audit":
                                    graph_audit[
                                        "protection_audit"
                                    ],
                                "model_id": MODEL_ID,
                                "prompt_contract_version":
                                    PROMPT_CONTRACT_VERSION,
                                "max_new_tokens":
                                    MAX_NEW_TOKENS,
                                "generation_seed":
                                    GENERATION_SEED,
                            }

                            append_jsonl(
                                results_jsonl,
                                result,
                            )

                            completed_keys.add(
                                item["task_key"]
                            )
                            total_completed += 1

                            print(
                                f"[{total_completed}/{expected_rows}]",
                                dataset_name,
                                f"seed={protection_seed}",
                                f"variant={display_variant}",
                                f"repeat={repeat_index}",
                                f"path={record.path_id}",
                                f"parse={parse_success}",
                                f"gold_f1={gold_metrics['f1']:.3f}",
                                f"faithful={int(parsed_sequence == exposed_sequence)}",
                            )

                        progress = {
                            "status": "RUNNING",
                            "mode": args.mode,
                            "expected_rows":
                                expected_rows,
                            "completed_rows":
                                total_completed,
                            "remaining_rows":
                                expected_rows
                                - total_completed,
                            "last_dataset":
                                dataset_name,
                            "last_seed":
                                int(protection_seed),
                            "last_variant":
                                display_variant,
                            "last_repeat":
                                int(repeat_index),
                            "updated_utc":
                                dt.datetime.now(
                                    dt.timezone.utc
                                ).isoformat(),
                        }

                        atomic_write_json(
                            run_dir
                            / "PROGRESS.json",
                            progress,
                        )

    final_rows = load_jsonl(results_jsonl)

    audit = summarize_results(
        rows=final_rows,
        run_dir=run_dir,
        mode=args.mode,
        expected_rows=expected_rows,
    )

    metadata["status"] = (
        "COMPLETE_PASS"
        if audit["audit_pass"] == 1
        else "COMPLETE_FAIL"
    )
    metadata["completed_utc"] = dt.datetime.now(
        dt.timezone.utc
    ).isoformat()
    metadata["actual_rows"] = len(final_rows)
    metadata["audit_pass"] = audit["audit_pass"]

    atomic_write_json(
        run_dir / "RUN_METADATA.json",
        metadata,
    )

    checksum_path = write_sha256s(run_dir)

    latest_name_by_mode = {
        "dry-run": "LATEST_E2E_RELATION_QA_DRY_RUN.txt",
        "pilot": "LATEST_E2E_RELATION_QA_PILOT.txt",
        "full": "LATEST_E2E_RELATION_QA_FULL.txt",
    }
    latest_name = latest_name_by_mode[args.mode]

    latest_path = (
        workspace
        / "experiments"
        / latest_name
    )
    latest_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    atomic_write_text(
        latest_path,
        "\n".join([
            f"status={metadata['status']}",
            f"mode={args.mode}",
            f"run_dir={run_dir}",
            f"results_jsonl={results_jsonl}",
            f"audit={run_dir / 'RUN_AUDIT.json'}",
            f"details={run_dir / 'relation_qa_details.csv'}",
            f"seed_summary={run_dir / 'relation_qa_seed_summary.csv'}",
            f"overall_summary={run_dir / 'relation_qa_overall_summary.csv'}",
            f"sha256s={checksum_path}",
            f"expected_rows={expected_rows}",
            f"actual_rows={len(final_rows)}",
            f"audit_pass={audit['audit_pass']}",
            "repository_files_modified=NO",
            "manuscript_modified=NO",
            "",
        ]),
    )

    print("\nFINAL AUDIT")
    print(
        json.dumps(
            audit,
            indent=2,
            ensure_ascii=False,
        )
    )
    print("RUN_DIRECTORY:", run_dir)
    print("SHA256SUMS:", checksum_path)

    final_git_status = run_command(
        [
            "git",
            "status",
            "--short",
            "--untracked-files=all",
        ],
        repo_root,
        check=True,
    ).stdout.strip()

    if final_git_status != git_status:
        raise RuntimeError(
            "Repository status changed during the run.\n"
            f"Before:\n{git_status}\nAfter:\n{final_git_status}"
        )

    if audit["audit_pass"] != 1:
        raise RuntimeError(
            "Run completed, but the locked audit failed."
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
