from pathlib import Path
import pandas as pd
import hashlib, json, shutil, time

ROOT = Path("/content/drive/MyDrive/TAFP_GraphRAG")
SRC = ROOT / "restored_data/TAFP_GRAPH_CSVS_20260620T233210Z/data"
OUT = ROOT / "minority_sensitive_ablation" / time.strftime("MSA_INPUTS_%Y%m%d_%H%M%S")
OUT.mkdir(parents=True, exist_ok=True)

DATASETS = {
    "agnews": ("agnews_nodes.csv", "agnews_edges.csv"),
    "cnndm": ("cnndm_nodes.csv", "cnndm_edges.csv"),
    "imdb": ("imdb_nodes.csv", "imdb_edges.csv"),
    "pubmed": ("pubmed_nodes.csv", "pubmed_edges.csv"),
    "synthpii": ("synthpii_nodes.csv", "synthpii_edges.csv"),
}

LEVELS = [0.05, 0.10, 0.20, 0.30]
SEED = 20260621

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

summary = {
    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    "source_dir": str(SRC),
    "output_dir": str(OUT),
    "policy_seed": SEED,
    "levels": LEVELS,
    "records": []
}

for ds, (node_file, edge_file) in DATASETS.items():
    node_src = SRC / node_file
    edge_src = SRC / edge_file

    if not node_src.exists() or not edge_src.exists():
        print("MISSING:", ds, node_src.exists(), edge_src.exists())
        continue

    nodes = pd.read_csv(node_src)
    edges_orig = pd.read_csv(edge_src)

    if "sensitive" not in edges_orig.columns:
        raise ValueError(f"{edge_src} has no sensitive column")

    for level in LEVELS:
        tag = f"{int(level*100):02d}pct"
        ds_out = OUT / ds / tag
        ds_out.mkdir(parents=True, exist_ok=True)

        node_out = ds_out / node_file
        edge_out = ds_out / edge_file

        shutil.copy2(node_src, node_out)

        edges = edges_orig.copy()

        # Deterministic minority-sensitive policy:
        # choose exact fraction of edges from original sensitive candidates only.
        eligible = edges.index[pd.to_numeric(edges["sensitive"], errors="coerce").fillna(0) > 0].tolist()
        target = int(round(len(edges) * level))
        target = min(target, len(eligible))

        # stable deterministic sampling
        seed_material = f"{ds}-{tag}-{SEED}".encode()
        local_seed = int(hashlib.md5(seed_material).hexdigest()[:8], 16)

        selected = (
            pd.Series(eligible).sample(n=target, random_state=local_seed).tolist()
            if target > 0 else []
        )

        edges["original_sensitive"] = pd.to_numeric(edges["sensitive"], errors="coerce").fillna(0)
        edges["sensitive"] = 0
        edges.loc[selected, "sensitive"] = 1

        edges.to_csv(edge_out, index=False)

        rec = {
            "dataset": ds,
            "level": tag,
            "nodes_file": str(node_out),
            "edges_file": str(edge_out),
            "rows": int(len(edges)),
            "original_sensitive_edges": int((edges["original_sensitive"] > 0).sum()),
            "new_sensitive_edges": int((edges["sensitive"] > 0).sum()),
            "new_sensitive_ratio": float((edges["sensitive"] > 0).mean()),
            "node_sha256": sha256_file(node_out),
            "edge_sha256": sha256_file(edge_out),
        }
        summary["records"].append(rec)

        print(ds, tag, "edges", rec["rows"], "new_sensitive", rec["new_sensitive_edges"], "ratio", round(100*rec["new_sensitive_ratio"], 2))

summary_path = OUT / "minority_sensitive_inputs_manifest.json"
with open(summary_path, "w") as f:
    json.dump(summary, f, indent=2)

print("\nDONE")
print("OUT:", OUT)
print("MANIFEST:", summary_path)