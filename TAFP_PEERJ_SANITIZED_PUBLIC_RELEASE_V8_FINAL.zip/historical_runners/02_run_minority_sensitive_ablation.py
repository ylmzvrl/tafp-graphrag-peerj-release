from pathlib import Path
import sys, time, json, hashlib, math
import pandas as pd
import numpy as np

REPO = Path("/content/tafp_repo_audit/tafp-graphrag")
INPUT_ROOT = Path("/content/drive/MyDrive/TAFP_GraphRAG/minority_sensitive_ablation/MSA_INPUTS_20260621_232857")
OUT_ROOT = Path("/content/drive/MyDrive/TAFP_GraphRAG/minority_sensitive_ablation") / time.strftime("MSA_RESULTS_%Y%m%d_%H%M%S")
OUT_ROOT.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(REPO))

from dataset_loader import build_graph_from_csv
import protections_v8_baselines as protections

DATASETS = {
    "agnews": ("agnews_nodes.csv", "agnews_edges.csv"),
    "cnndm": ("cnndm_nodes.csv", "cnndm_edges.csv"),
    "imdb": ("imdb_nodes.csv", "imdb_edges.csv"),
    "pubmed": ("pubmed_nodes.csv", "pubmed_edges.csv"),
    "synthpii": ("synthpii_nodes.csv", "synthpii_edges.csv"),
}

LEVELS = ["05pct", "10pct", "20pct", "30pct"]
SEEDS = [1, 7, 21, 42, 99, 123, 202, 303, 404, 505, 606, 707, 808, 909, 1001]
VARIANTS = ["baseline", "full", "random_relation_budget", "random_full_budget"]

CONFIG_BASE = {
    "entity_mask_rate": 0.75,
    "relation_remove_rate": 0.12,
    "topology_rewire_rate": 0.08,
    "entity_sensitivity_threshold": 0.45,
}

def edge_key(u, v):
    return tuple(sorted((str(u), str(v))))

def graph_edge_map(G):
    out = {}
    for u, v, d in G.edges(data=True):
        out[edge_key(u, v)] = dict(d)
    return out

def compute_metrics(G0, Gp):
    base_edges = graph_edge_map(G0)
    prot_edges = graph_edge_map(Gp)

    base_deg = dict(G0.degree())
    prot_deg = dict(Gp.degree())

    changed_degree_nodes = sum(base_deg[n] != prot_deg.get(n, None) for n in base_deg)
    exact_degree_preservation = int(changed_degree_nodes == 0)

    E0 = set(base_edges.keys())
    Ep = set(prot_edges.keys())
    retained_edges = E0 & Ep

    sensitive_edges = []
    nonsensitive_edges = []

    for k, d in base_edges.items():
        sensitive = float(d.get("sensitive", 0) or 0) > 0
        if sensitive:
            sensitive_edges.append(k)
        else:
            nonsensitive_edges.append(k)

    # Sensitive original-label concealment:
    # concealed if original sensitive edge is removed OR exposed protected relation differs from original relation.
    concealed = 0
    recovered = 0
    for k in sensitive_edges:
        orig_rel = str(base_edges[k].get("relation_type", "related_to"))
        if k not in prot_edges:
            concealed += 1
        else:
            exposed = str(prot_edges[k].get("protected_relation_type", prot_edges[k].get("relation_type", "related_to")))
            if exposed != orig_rel:
                concealed += 1
            else:
                recovered += 1

    # Non-sensitive semantic retention:
    # retained if original non-sensitive edge remains and exposed protected relation equals original relation.
    ns_retained = 0
    for k in nonsensitive_edges:
        if k in prot_edges:
            orig_rel = str(base_edges[k].get("relation_type", "related_to"))
            exposed = str(prot_edges[k].get("protected_relation_type", prot_edges[k].get("relation_type", "related_to")))
            if exposed == orig_rel:
                ns_retained += 1

    return {
        "nodes": G0.number_of_nodes(),
        "edges_original": len(E0),
        "edges_protected": len(Ep),
        "sensitive_edges": len(sensitive_edges),
        "nonsensitive_edges": len(nonsensitive_edges),
        "sensitive_prevalence": len(sensitive_edges) / len(E0) if E0 else np.nan,
        "original_edge_retention": len(retained_edges) / len(E0) if E0 else np.nan,
        "sensitive_original_label_concealment": concealed / len(sensitive_edges) if sensitive_edges else np.nan,
        "sensitive_original_label_recovery": recovered / len(sensitive_edges) if sensitive_edges else np.nan,
        "nonsensitive_semantic_retention": ns_retained / len(nonsensitive_edges) if nonsensitive_edges else np.nan,
        "changed_degree_nodes": changed_degree_nodes,
        "exact_degree_preservation": exact_degree_preservation,
    }

rows = []
errors = []

for ds, (node_file, edge_file) in DATASETS.items():
    for level in LEVELS:
        node_path = INPUT_ROOT / ds / level / node_file
        edge_path = INPUT_ROOT / ds / level / edge_file

        if not node_path.exists() or not edge_path.exists():
            errors.append({"dataset": ds, "level": level, "error": "missing input"})
            continue

        for seed in SEEDS:
            try:
                G0 = build_graph_from_csv(str(node_path), str(edge_path), seed=seed)
            except Exception as e:
                errors.append({"dataset": ds, "level": level, "seed": seed, "error": f"build_graph: {repr(e)}"})
                continue

            for variant in VARIANTS:
                cfg = dict(CONFIG_BASE)
                cfg["seed"] = seed

                try:
                    Gp = protections.apply_variant(G0, risks=None, variant=variant, config=cfg)
                    m = compute_metrics(G0, Gp)
                    audit = dict(Gp.graph.get("protection_audit", {}))

                    row = {
                        "dataset": ds,
                        "prevalence_level": level,
                        "seed": seed,
                        "variant": variant,
                        **m,
                        "audit_degree_preserved_exactly": audit.get("degree_preserved_exactly", None),
                        "audit_degree_changed_nodes": audit.get("degree_changed_nodes", None),
                        "audit_sensitive_node_candidates": audit.get("sensitive_node_candidates", None),
                        "audit_masked_nodes": audit.get("masked_nodes", None),
                        "audit_relation_target_edges": audit.get("relation_target_edges", None),
                        "audit_relation_rewired_edges": audit.get("relation_rewired_edges", None),
                        "audit_topology_target_edges": audit.get("topology_target_edges", None),
                        "audit_topology_rewired_edges": audit.get("topology_rewired_edges", None),
                    }
                    rows.append(row)
                except Exception as e:
                    errors.append({"dataset": ds, "level": level, "seed": seed, "variant": variant, "error": repr(e)})

            print("done", ds, level, seed)

df = pd.DataFrame(rows)
raw_path = OUT_ROOT / "minority_sensitive_ablation_raw.csv"
df.to_csv(raw_path, index=False)

summary = (
    df.groupby(["dataset", "prevalence_level", "variant"])
      .agg(
          n=("seed", "count"),
          sensitive_prevalence_mean=("sensitive_prevalence", "mean"),
          sensitive_concealment_mean=("sensitive_original_label_concealment", "mean"),
          sensitive_concealment_sd=("sensitive_original_label_concealment", "std"),
          nonsensitive_retention_mean=("nonsensitive_semantic_retention", "mean"),
          nonsensitive_retention_sd=("nonsensitive_semantic_retention", "std"),
          original_edge_retention_mean=("original_edge_retention", "mean"),
          original_edge_retention_sd=("original_edge_retention", "std"),
          exact_degree_preservation_mean=("exact_degree_preservation", "mean"),
          changed_degree_nodes_sum=("changed_degree_nodes", "sum"),
      )
      .reset_index()
)

summary_path = OUT_ROOT / "minority_sensitive_ablation_summary.csv"
summary.to_csv(summary_path, index=False)

# Pairwise seed-level deltas: full minus random baselines
pair_rows = []
for (ds, level), sub in df.groupby(["dataset", "prevalence_level"]):
    for comparator in ["random_relation_budget", "random_full_budget"]:
        for seed in SEEDS:
            f = sub[(sub["seed"] == seed) & (sub["variant"] == "full")]
            c = sub[(sub["seed"] == seed) & (sub["variant"] == comparator)]
            if len(f) != 1 or len(c) != 1:
                continue
            f = f.iloc[0]
            c = c.iloc[0]
            pair_rows.append({
                "dataset": ds,
                "prevalence_level": level,
                "seed": seed,
                "comparison": f"full_vs_{comparator}",
                "delta_sensitive_concealment": f["sensitive_original_label_concealment"] - c["sensitive_original_label_concealment"],
                "delta_nonsensitive_retention": f["nonsensitive_semantic_retention"] - c["nonsensitive_semantic_retention"],
                "delta_original_edge_retention": f["original_edge_retention"] - c["original_edge_retention"],
                "delta_exact_degree_preservation": f["exact_degree_preservation"] - c["exact_degree_preservation"],
            })

pairs = pd.DataFrame(pair_rows)
pairs_path = OUT_ROOT / "minority_sensitive_ablation_paired_deltas.csv"
pairs.to_csv(pairs_path, index=False)

manifest = {
    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    "repo": str(REPO),
    "input_root": str(INPUT_ROOT),
    "output_root": str(OUT_ROOT),
    "datasets": DATASETS,
    "levels": LEVELS,
    "seeds": SEEDS,
    "variants": VARIANTS,
    "row_count": int(len(df)),
    "error_count": int(len(errors)),
    "errors": errors[:50],
    "files": {
        "raw": str(raw_path),
        "summary": str(summary_path),
        "paired_deltas": str(pairs_path),
    }
}

manifest_path = OUT_ROOT / "minority_sensitive_ablation_manifest.json"
with open(manifest_path, "w") as f:
    json.dump(manifest, f, indent=2)

print("\nDONE")
print("OUT_ROOT:", OUT_ROOT)
print("RAW:", raw_path)
print("SUMMARY:", summary_path)
print("PAIRS:", pairs_path)
print("MANIFEST:", manifest_path)
print("ROWS:", len(df), "ERRORS:", len(errors))

print("\nSUMMARY PREVIEW")
display(summary.head(20))