from pathlib import Path
import json
import time

import networkx as nx
import pandas as pd

import protections_v8_baselines as existing
from dataset_loader import build_graph_from_config
from protections_v8_dk2_baseline import (
    apply_variant as apply_dk2_variant,
    joint_degree_counter,
)


OUTPUT_DIR = Path(
    "outputs/v13_dk2_baseline_15seed"
)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_PATTERNS = {
    "AGNews": "config_agnews_v8_seed_{seed}.json",
    "CNN_DM": "config_cnn_dm_v8_seed_{seed}.json",
    "IMDB": "config_imdb_v8_seed_{seed}.json",
    "PubMed": "config_pubmed_v8_seed_{seed}.json",
    "SynthPII": "config_synthpii_v8_seed_{seed}.json",
}

SEEDS = [
    1, 7, 21, 42, 99,
    123, 202, 303, 404, 505,
    606, 707, 808, 909, 1001,
]

VARIANTS = [
    "full",
    "random_full_budget",
    "dk2_full_budget",
]


def normalized_edge_set(graph):
    return {
        frozenset((source, target))
        for source, target in graph.edges()
    }


def exposed_relation(graph, source, target):
    if not graph.has_edge(source, target):
        return None

    attributes = graph.edges[source, target]

    return str(
        attributes.get(
            "protected_relation_type",
            attributes.get(
                "relation_type",
                "UNKNOWN",
            ),
        )
    )


def largest_component_ratio(graph):
    if graph.number_of_nodes() == 0:
        return 0.0

    largest = max(
        nx.connected_components(graph),
        key=len,
        default=set(),
    )

    return (
        len(largest)
        / graph.number_of_nodes()
    )


def jdd_l1_error(
    base_graph,
    protected_graph,
):
    reference_degrees = dict(
        base_graph.degree()
    )

    base_jdd = joint_degree_counter(
        base_graph,
        reference_degrees,
    )

    protected_jdd = joint_degree_counter(
        protected_graph,
        reference_degrees,
    )

    keys = set(base_jdd) | set(protected_jdd)

    return int(
        sum(
            abs(
                base_jdd.get(key, 0)
                - protected_jdd.get(key, 0)
            )
            for key in keys
        )
    )


def canonical_budget(
    variant,
    audit,
):
    if variant == "dk2_full_budget":
        return {
            "masked_nodes":
                int(audit["masked_nodes"]),
            "relation_selected_edges":
                int(
                    audit[
                        "dk2_relation_selected_edges"
                    ]
                ),
            "relation_target_edges":
                int(
                    audit[
                        "dk2_relation_target_edges"
                    ]
                ),
            "relation_rewired_edges":
                int(
                    audit[
                        "dk2_relation_rewired_edges"
                    ]
                ),
            "topology_target_edges":
                int(
                    audit[
                        "dk2_topology_target_edges"
                    ]
                ),
            "topology_rewired_edges":
                int(
                    audit[
                        "dk2_topology_rewired_edges"
                    ]
                ),
            "relation_target_reached":
                int(
                    audit[
                        "dk2_relation_target_reached"
                    ]
                ),
            "topology_target_reached":
                int(
                    audit[
                        "dk2_topology_target_reached"
                    ]
                ),
        }

    selected_edges = audit.get(
        "random_relation_selected_edges",
        audit.get("sensitive_edges", 0),
    )

    return {
        "masked_nodes":
            int(audit["masked_nodes"]),
        "relation_selected_edges":
            int(selected_edges),
        "relation_target_edges":
            int(
                audit["relation_target_edges"]
            ),
        "relation_rewired_edges":
            int(
                audit["relation_rewired_edges"]
            ),
        "topology_target_edges":
            int(
                audit["topology_target_edges"]
            ),
        "topology_rewired_edges":
            int(
                audit["topology_rewired_edges"]
            ),
        "relation_target_reached":
            int(
                audit["relation_target_edges"]
                == audit["relation_rewired_edges"]
            ),
        "topology_target_reached":
            int(
                audit["topology_target_edges"]
                == audit["topology_rewired_edges"]
            ),
    }


def evaluate_graph(
    dataset_name,
    seed,
    variant,
    base_graph,
    protected_graph,
    runtime_seconds,
):
    base_edges = normalized_edge_set(
        base_graph
    )

    protected_edges = normalized_edge_set(
        protected_graph
    )

    sensitive_total = 0
    sensitive_hidden = 0
    non_sensitive_total = 0
    non_sensitive_retained = 0

    for (
        source,
        target,
        attributes,
    ) in base_graph.edges(data=True):

        original_relation = str(
            attributes.get(
                "relation_type",
                "UNKNOWN",
            )
        )

        exposed = exposed_relation(
            protected_graph,
            source,
            target,
        )

        retained = (
            exposed == original_relation
        )

        if existing.core._v7_edge_sensitive(
            attributes
        ):
            sensitive_total += 1
            sensitive_hidden += int(
                not retained
            )
        else:
            non_sensitive_total += 1
            non_sensitive_retained += int(
                retained
            )

    base_degrees = dict(
        base_graph.degree()
    )

    protected_degrees = dict(
        protected_graph.degree()
    )

    changed_degree_nodes = int(
        sum(
            base_degrees[node]
            != protected_degrees[node]
            for node in base_graph.nodes()
        )
    )

    base_components = (
        nx.number_connected_components(
            base_graph
        )
    )

    protected_components = (
        nx.number_connected_components(
            protected_graph
        )
    )

    base_lcc = largest_component_ratio(
        base_graph
    )

    protected_lcc = largest_component_ratio(
        protected_graph
    )

    base_clustering = (
        nx.average_clustering(
            base_graph
        )
    )

    protected_clustering = (
        nx.average_clustering(
            protected_graph
        )
    )

    base_transitivity = nx.transitivity(
        base_graph
    )

    protected_transitivity = (
        nx.transitivity(
            protected_graph
        )
    )

    audit = protected_graph.graph.get(
        "protection_audit",
        {},
    )

    budget = canonical_budget(
        variant,
        audit,
    )

    return {
        "dataset_name": dataset_name,
        "protection_seed": seed,
        "variant": variant,
        "node_count":
            protected_graph.number_of_nodes(),
        "edge_count":
            protected_graph.number_of_edges(),
        **budget,
        "sensitive_edge_count":
            sensitive_total,
        "non_sensitive_edge_count":
            non_sensitive_total,
        "sensitive_relation_concealment":
            (
                sensitive_hidden
                / sensitive_total
                if sensitive_total
                else 0.0
            ),
        "non_sensitive_semantic_retention":
            (
                non_sensitive_retained
                / non_sensitive_total
                if non_sensitive_total
                else 0.0
            ),
        "original_edge_retention":
            (
                len(
                    base_edges
                    & protected_edges
                )
                / len(base_edges)
                if base_edges
                else 1.0
            ),
        "changed_degree_nodes":
            changed_degree_nodes,
        "exact_degree_sequence_match":
            int(
                changed_degree_nodes == 0
            ),
        "joint_degree_l1_error":
            jdd_l1_error(
                base_graph,
                protected_graph,
            ),
        "base_connected_components":
            base_components,
        "protected_connected_components":
            protected_components,
        "component_count_absolute_deviation":
            abs(
                protected_components
                - base_components
            ),
        "base_largest_component_ratio":
            base_lcc,
        "protected_largest_component_ratio":
            protected_lcc,
        "largest_component_ratio_absolute_deviation":
            abs(
                protected_lcc
                - base_lcc
            ),
        "base_average_clustering":
            base_clustering,
        "protected_average_clustering":
            protected_clustering,
        "average_clustering_absolute_deviation":
            abs(
                protected_clustering
                - base_clustering
            ),
        "base_transitivity":
            base_transitivity,
        "protected_transitivity":
            protected_transitivity,
        "transitivity_absolute_deviation":
            abs(
                protected_transitivity
                - base_transitivity
            ),
        "runtime_seconds":
            float(runtime_seconds),
    }


rows = []

for dataset_name, pattern in (
    CONFIG_PATTERNS.items()
):
    seed_one_path = Path(
        pattern.format(seed=1)
    )

    with seed_one_path.open(
        "r",
        encoding="utf-8",
    ) as handle:
        seed_one_config = json.load(handle)

    base_graph = build_graph_from_config(
        seed_one_config
    )

    print(
        "\nDATASET",
        dataset_name,
        "nodes=",
        base_graph.number_of_nodes(),
        "edges=",
        base_graph.number_of_edges(),
    )

    for seed in SEEDS:
        config_path = Path(
            pattern.format(seed=seed)
        )

        with config_path.open(
            "r",
            encoding="utf-8",
        ) as handle:
            config = json.load(handle)

        for variant in VARIANTS:
            start = time.perf_counter()

            if variant == "dk2_full_budget":
                protected_graph = (
                    apply_dk2_variant(
                        base_graph,
                        ({}, {}, {}),
                        variant,
                        config,
                    )
                )
            else:
                protected_graph = (
                    existing.apply_variant(
                        base_graph,
                        ({}, {}, {}),
                        variant,
                        config,
                    )
                )

            runtime_seconds = (
                time.perf_counter()
                - start
            )

            row = evaluate_graph(
                dataset_name=dataset_name,
                seed=seed,
                variant=variant,
                base_graph=base_graph,
                protected_graph=protected_graph,
                runtime_seconds=runtime_seconds,
            )

            rows.append(row)

            print(
                dataset_name,
                "seed=",
                seed,
                "variant=",
                variant,
                "concealment=",
                round(
                    row[
                        "sensitive_relation_concealment"
                    ],
                    4,
                ),
                "non_sensitive=",
                round(
                    row[
                        "non_sensitive_semantic_retention"
                    ],
                    4,
                ),
                "edge_retention=",
                round(
                    row[
                        "original_edge_retention"
                    ],
                    4,
                ),
                "jdd_l1=",
                row[
                    "joint_degree_l1_error"
                ],
            )


details = pd.DataFrame(rows)

key_columns = [
    "dataset_name",
    "protection_seed",
    "variant",
]

expected_rows = (
    len(CONFIG_PATTERNS)
    * len(SEEDS)
    * len(VARIANTS)
)

summary_metrics = [
    "sensitive_relation_concealment",
    "non_sensitive_semantic_retention",
    "original_edge_retention",
    "exact_degree_sequence_match",
    "joint_degree_l1_error",
    "component_count_absolute_deviation",
    "largest_component_ratio_absolute_deviation",
    "average_clustering_absolute_deviation",
    "transitivity_absolute_deviation",
    "runtime_seconds",
]

summary = (
    details.groupby(
        [
            "dataset_name",
            "variant",
        ],
        observed=True,
    )[summary_metrics]
    .agg(["mean", "std"])
    .reset_index()
)

summary.columns = [
    "_".join(
        str(part)
        for part in column
        if str(part)
    )
    if isinstance(column, tuple)
    else str(column)
    for column in summary.columns
]


budget_columns = [
    "masked_nodes",
    "relation_selected_edges",
    "relation_target_edges",
    "relation_rewired_edges",
    "topology_target_edges",
    "topology_rewired_edges",
]

budget_mismatch_rows = 0

for (
    dataset_name,
    protection_seed,
), group in details.groupby(
    [
        "dataset_name",
        "protection_seed",
    ],
    observed=True,
):
    if len(group) != 3:
        budget_mismatch_rows += 1
        continue

    for column in budget_columns:
        if group[column].nunique() != 1:
            budget_mismatch_rows += 1
            break


dk2_rows = details[
    details["variant"]
    == "dk2_full_budget"
]

audit = {
    "expected_rows": expected_rows,
    "actual_rows": len(details),
    "datasets":
        details["dataset_name"].nunique(),
    "protection_seeds":
        details[
            "protection_seed"
        ].nunique(),
    "variants":
        details["variant"].nunique(),
    "duplicate_rows": int(
        details.duplicated(
            key_columns
        ).sum()
    ),
    "missing_values": int(
        details.isna().sum().sum()
    ),
    "budget_mismatch_dataset_seed_groups":
        budget_mismatch_rows,
    "edge_count_change_rows": int(
        (
            details["edge_count"]
            != details.groupby(
                "dataset_name"
            )["edge_count"].transform(
                "first"
            )
        ).sum()
    ),
    "degree_preservation_failures": int(
        (
            details[
                "exact_degree_sequence_match"
            ] != 1
        ).sum()
    ),
    "relation_target_failures": int(
        (
            details[
                "relation_target_reached"
            ] != 1
        ).sum()
    ),
    "topology_target_failures": int(
        (
            details[
                "topology_target_reached"
            ] != 1
        ).sum()
    ),
    "dk2_rows": len(dk2_rows),
    "dk2_joint_degree_failures": int(
        (
            dk2_rows[
                "joint_degree_l1_error"
            ] != 0
        ).sum()
    ),
}

audit_pass = (
    len(details) == expected_rows
    and details[
        "dataset_name"
    ].nunique() == 5
    and details[
        "protection_seed"
    ].nunique() == 15
    and details["variant"].nunique() == 3
    and audit["duplicate_rows"] == 0
    and audit["missing_values"] == 0
    and budget_mismatch_rows == 0
    and audit[
        "edge_count_change_rows"
    ] == 0
    and audit[
        "degree_preservation_failures"
    ] == 0
    and audit[
        "relation_target_failures"
    ] == 0
    and audit[
        "topology_target_failures"
    ] == 0
    and len(dk2_rows) == 75
    and audit[
        "dk2_joint_degree_failures"
    ] == 0
)

audit["audit_pass"] = int(
    audit_pass
)

details.to_csv(
    OUTPUT_DIR
    / "dk2_baseline_comparison_details.csv",
    index=False,
)

summary.to_csv(
    OUTPUT_DIR
    / "dk2_baseline_comparison_summary.csv",
    index=False,
)

with (
    OUTPUT_DIR
    / "dk2_baseline_comparison_audit.json"
).open(
    "w",
    encoding="utf-8",
) as handle:
    json.dump(
        audit,
        handle,
        indent=2,
    )

print("\nSUMMARY")
print(
    summary[
        [
            "dataset_name",
            "variant",
            "sensitive_relation_concealment_mean",
            "non_sensitive_semantic_retention_mean",
            "original_edge_retention_mean",
            "joint_degree_l1_error_mean",
            "average_clustering_absolute_deviation_mean",
            "transitivity_absolute_deviation_mean",
        ]
    ].to_string(index=False)
)

print("\nAUDIT")
print(
    json.dumps(
        audit,
        indent=2,
    )
)

print(
    "\nSTEP 9C STATUS:",
    "PASS" if audit_pass else "FAIL",
)

if not audit_pass:
    raise RuntimeError(
        "DK2 15-seed comparison audit failed."
    )
