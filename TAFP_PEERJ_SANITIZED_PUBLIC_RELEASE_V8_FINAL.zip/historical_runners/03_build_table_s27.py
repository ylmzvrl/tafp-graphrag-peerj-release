import pandas as pd
from pathlib import Path

OUT_ROOT = Path("/content/drive/MyDrive/TAFP_GraphRAG/minority_sensitive_ablation/MSA_RESULTS_20260621_233248")
summary = pd.read_csv(OUT_ROOT / "minority_sensitive_ablation_summary.csv")

# Only key variants for reviewer response
keep = summary[summary["variant"].isin(["full", "random_full_budget", "random_relation_budget"])].copy()

# Rounded compact table
compact = keep[[
    "dataset",
    "prevalence_level",
    "variant",
    "sensitive_concealment_mean",
    "nonsensitive_retention_mean",
    "original_edge_retention_mean",
    "exact_degree_preservation_mean"
]].copy()

for col in [
    "sensitive_concealment_mean",
    "nonsensitive_retention_mean",
    "original_edge_retention_mean",
    "exact_degree_preservation_mean"
]:
    compact[col] = compact[col].round(4)

compact_path = OUT_ROOT / "table_s27_minority_sensitive_policy_ablation_compact.csv"
compact.to_csv(compact_path, index=False)

# Overall summary by prevalence and variant
overall = keep.groupby(["prevalence_level", "variant"]).agg(
    sensitive_concealment_mean=("sensitive_concealment_mean", "mean"),
    sensitive_concealment_min=("sensitive_concealment_mean", "min"),
    sensitive_concealment_max=("sensitive_concealment_mean", "max"),
    nonsensitive_retention_mean=("nonsensitive_retention_mean", "mean"),
    nonsensitive_retention_min=("nonsensitive_retention_mean", "min"),
    nonsensitive_retention_max=("nonsensitive_retention_mean", "max"),
    original_edge_retention_mean=("original_edge_retention_mean", "mean"),
    exact_degree_preservation_mean=("exact_degree_preservation_mean", "mean"),
).reset_index()

for col in overall.columns:
    if col not in ["prevalence_level", "variant"]:
        overall[col] = overall[col].round(4)

overall_path = OUT_ROOT / "table_s27_minority_sensitive_policy_ablation_overall.csv"
overall.to_csv(overall_path, index=False)

print("WROTE:")
print(compact_path)
print(overall_path)

print("\nOVERALL")
print(overall.to_string(index=False))