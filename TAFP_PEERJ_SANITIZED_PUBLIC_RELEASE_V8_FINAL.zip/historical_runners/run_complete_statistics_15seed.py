from pathlib import Path
import math
import numpy as np
import pandas as pd
from scipy import stats

INPUT = "outputs/final_multidataset_15seed_gpu_embedding_all.csv"
OUTDIR = Path("outputs/statistical_tests_15seed")
OUTDIR.mkdir(parents=True, exist_ok=True)

RNG_SEED = 20260617
BOOTSTRAP_SAMPLES = 20000

METRICS = [
    "recall_at_k",
    "ndcg_at_k",
    "mia_auc",
    "link_inference_auc",
    "topology_leakage_score",
    "reconstruction_similarity",
]

UTILITY_METRICS = {"recall_at_k", "ndcg_at_k"}

COMPARISONS = [
    ("primary", "baseline_vs_full", "baseline", "full"),

    ("secondary", "baseline_vs_entity_only", "baseline", "entity_only"),
    ("secondary", "baseline_vs_relation_only", "baseline", "relation_only"),
    ("secondary", "baseline_vs_topology_only", "baseline", "topology_only"),

    ("ablation", "full_vs_entity_only", "full", "entity_only"),
    ("ablation", "full_vs_relation_only", "full", "relation_only"),
    ("ablation", "full_vs_topology_only", "full", "topology_only"),
]


def holm_adjust(p_values):
    p = np.asarray(p_values, dtype=float)
    p = np.where(np.isnan(p), 1.0, p)

    n = len(p)
    order = np.argsort(p)
    adjusted = np.empty(n, dtype=float)

    running_max = 0.0

    for rank, index in enumerate(order):
        candidate = (n - rank) * p[index]
        running_max = max(running_max, candidate)
        adjusted[index] = min(running_max, 1.0)

    return adjusted


_sign_cache = {}


def exact_sign_flip_pvalue(differences):
    """
    Exact two-sided paired permutation test using all sign flips.
    For n=15, this evaluates 2^15 = 32,768 permutations.
    """
    d = np.asarray(differences, dtype=float)
    d = d[np.isfinite(d)]

    if len(d) == 0 or np.allclose(d, 0):
        return 1.0

    n = len(d)

    if n not in _sign_cache:
        integers = np.arange(2 ** n, dtype=np.uint32)[:, None]
        bits = (integers >> np.arange(n, dtype=np.uint32)) & 1
        _sign_cache[n] = np.where(bits == 0, 1.0, -1.0)

    signs = _sign_cache[n]

    observed = abs(np.mean(d))
    permuted = np.abs(np.mean(signs * d[None, :], axis=1))

    return float(np.mean(permuted >= observed - 1e-15))


def bootstrap_mean_ci(differences, samples=BOOTSTRAP_SAMPLES):
    d = np.asarray(differences, dtype=float)
    d = d[np.isfinite(d)]

    if len(d) == 0:
        return np.nan, np.nan

    if np.allclose(d, d[0]):
        return float(d[0]), float(d[0])

    rng = np.random.default_rng(RNG_SEED)
    indices = rng.integers(0, len(d), size=(samples, len(d)))
    boot_means = d[indices].mean(axis=1)

    low, high = np.percentile(boot_means, [2.5, 97.5])
    return float(low), float(high)


def matched_rank_biserial(differences):
    """
    Positive value means A > B.
    Negative value means A < B.
    """
    d = np.asarray(differences, dtype=float)
    d = d[np.isfinite(d)]
    d = d[~np.isclose(d, 0)]

    if len(d) == 0:
        return 0.0

    ranks = stats.rankdata(np.abs(d))
    positive = ranks[d > 0].sum()
    negative = ranks[d < 0].sum()
    total = positive + negative

    if total == 0:
        return 0.0

    return float((positive - negative) / total)


def safe_wilcoxon(a, b):
    difference = np.asarray(a) - np.asarray(b)

    if np.allclose(difference, 0):
        return 1.0

    try:
        return float(
            stats.wilcoxon(
                a,
                b,
                alternative="two-sided",
                zero_method="wilcox",
                method="auto",
            ).pvalue
        )
    except Exception:
        return np.nan


def paired_statistics(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    d = a - b

    n = len(d)
    mean_difference = float(np.mean(d))
    median_difference = float(np.median(d))

    difference_std = float(np.std(d, ddof=1)) if n > 1 else 0.0

    if n > 1 and difference_std > 0:
        t_result = stats.ttest_rel(a, b)
        paired_t_p = float(t_result.pvalue)

        standard_error = difference_std / math.sqrt(n)
        t_critical = stats.t.ppf(0.975, df=n - 1)

        parametric_ci_low = mean_difference - t_critical * standard_error
        parametric_ci_high = mean_difference + t_critical * standard_error

        cohens_dz = mean_difference / difference_std
    else:
        paired_t_p = 1.0
        parametric_ci_low = mean_difference
        parametric_ci_high = mean_difference
        cohens_dz = 0.0

    bootstrap_low, bootstrap_high = bootstrap_mean_ci(d)

    return {
        "n_seeds": n,
        "mean_a": float(np.mean(a)),
        "std_a": float(np.std(a, ddof=1)),
        "mean_b": float(np.mean(b)),
        "std_b": float(np.std(b, ddof=1)),
        "mean_difference_a_minus_b": mean_difference,
        "median_difference_a_minus_b": median_difference,
        "parametric_ci95_low": float(parametric_ci_low),
        "parametric_ci95_high": float(parametric_ci_high),
        "bootstrap_ci95_low": bootstrap_low,
        "bootstrap_ci95_high": bootstrap_high,
        "paired_t_p": paired_t_p,
        "wilcoxon_p": safe_wilcoxon(a, b),
        "exact_permutation_p": exact_sign_flip_pvalue(d),
        "cohens_dz": float(cohens_dz),
        "rank_biserial": matched_rank_biserial(d),
    }


df = pd.read_csv(INPUT)

required = {
    "dataset_name",
    "variant",
    "seed",
    *METRICS,
}

missing = required - set(df.columns)

if missing:
    raise RuntimeError(f"Missing columns: {sorted(missing)}")

duplicates = df.duplicated(
    ["dataset_name", "variant", "seed"],
    keep=False,
)

if duplicates.any():
    raise RuntimeError(
        f"Duplicate dataset/variant/seed rows: {int(duplicates.sum())}"
    )

counts = (
    df.groupby(["dataset_name", "variant"])["seed"]
    .nunique()
)

if not (counts == 15).all():
    raise RuntimeError("Not every dataset/variant group contains 15 seeds.")


# ---------------------------------------------------------
# Table 1: Descriptive main results
# ---------------------------------------------------------
means = (
    df.groupby(["dataset_name", "variant"])[METRICS]
    .mean()
    .reset_index()
)

stds = (
    df.groupby(["dataset_name", "variant"])[METRICS]
    .std()
    .reset_index()
)

main_rows = []

for dataset in sorted(df["dataset_name"].unique()):
    baseline = means[
        (means["dataset_name"] == dataset)
        & (means["variant"] == "baseline")
    ].iloc[0]

    full = means[
        (means["dataset_name"] == dataset)
        & (means["variant"] == "full")
    ].iloc[0]

    main_rows.append({
        "dataset": dataset,

        "baseline_recall": baseline["recall_at_k"],
        "full_recall": full["recall_at_k"],
        "recall_retention_percent":
            100 * full["recall_at_k"] / baseline["recall_at_k"],

        "baseline_ndcg": baseline["ndcg_at_k"],
        "full_ndcg": full["ndcg_at_k"],
        "ndcg_retention_percent":
            100 * full["ndcg_at_k"] / baseline["ndcg_at_k"],

        "baseline_mia_auc": baseline["mia_auc"],
        "full_mia_auc": full["mia_auc"],
        "mia_auc_absolute_reduction":
            baseline["mia_auc"] - full["mia_auc"],

        "baseline_link_auc": baseline["link_inference_auc"],
        "full_link_auc": full["link_inference_auc"],
        "link_auc_absolute_reduction":
            baseline["link_inference_auc"] - full["link_inference_auc"],

        "full_topology_leakage":
            full["topology_leakage_score"],

        "full_reconstruction_similarity":
            full["reconstruction_similarity"],
    })

main_table = pd.DataFrame(main_rows)

main_table.to_csv(
    OUTDIR / "table1_main_results_15seed.csv",
    index=False,
)


# ---------------------------------------------------------
# Complete paired comparisons
# ---------------------------------------------------------
rows = []

for family, comparison_name, variant_a, variant_b in COMPARISONS:
    for dataset in sorted(df["dataset_name"].unique()):
        subset = df[df["dataset_name"] == dataset]

        a_df = subset[subset["variant"] == variant_a]
        b_df = subset[subset["variant"] == variant_b]

        common_seeds = sorted(
            set(a_df["seed"]).intersection(b_df["seed"])
        )

        if len(common_seeds) != 15:
            raise RuntimeError(
                f"{comparison_name}, {dataset}: expected 15 common seeds, "
                f"found {len(common_seeds)}"
            )

        for metric in METRICS:
            a = (
                a_df[a_df["seed"].isin(common_seeds)]
                .sort_values("seed")[metric]
                .to_numpy()
            )

            b = (
                b_df[b_df["seed"].isin(common_seeds)]
                .sort_values("seed")[metric]
                .to_numpy()
            )

            result = paired_statistics(a, b)

            rows.append({
                "family": family,
                "comparison": comparison_name,
                "variant_a": variant_a,
                "variant_b": variant_b,
                "dataset": dataset,
                "metric": metric,
                "metric_type":
                    "utility" if metric in UTILITY_METRICS
                    else "privacy_risk",
                "preferred_direction":
                    "higher_is_better"
                    if metric in UTILITY_METRICS
                    else "lower_is_better",
                **result,
            })

tests = pd.DataFrame(rows)


# ---------------------------------------------------------
# Multiple-comparison corrections
# ---------------------------------------------------------

tests["permutation_p_holm_within_comparison"] = np.nan
tests["wilcoxon_p_holm_within_comparison"] = np.nan

for comparison in tests["comparison"].unique():
    mask = tests["comparison"] == comparison

    tests.loc[
        mask,
        "permutation_p_holm_within_comparison"
    ] = holm_adjust(
        tests.loc[mask, "exact_permutation_p"].to_numpy()
    )

    tests.loc[
        mask,
        "wilcoxon_p_holm_within_comparison"
    ] = holm_adjust(
        tests.loc[mask, "wilcoxon_p"].to_numpy()
    )


tests["permutation_p_holm_by_metric"] = np.nan

for comparison in tests["comparison"].unique():
    for metric in METRICS:
        mask = (
            (tests["comparison"] == comparison)
            & (tests["metric"] == metric)
        )

        tests.loc[
            mask,
            "permutation_p_holm_by_metric"
        ] = holm_adjust(
            tests.loc[mask, "exact_permutation_p"].to_numpy()
        )


primary_mask = tests["family"] == "primary"
tests.loc[
    primary_mask,
    "permutation_p_holm_primary_global"
] = holm_adjust(
    tests.loc[
        primary_mask,
        "exact_permutation_p"
    ].to_numpy()
)


# ---------------------------------------------------------
# Save complete and primary tables
# ---------------------------------------------------------

tests.to_csv(
    OUTDIR / "tableS_complete_paired_comparisons_15seed.csv",
    index=False,
)

primary = tests[tests["family"] == "primary"].copy()

primary.to_csv(
    OUTDIR / "table2_primary_baseline_vs_full_15seed.csv",
    index=False,
)

secondary = tests[tests["family"] != "primary"].copy()

secondary.to_csv(
    OUTDIR / "tableS_secondary_and_ablation_tests_15seed.csv",
    index=False,
)

df.sort_values(
    ["dataset_name", "variant", "seed"]
).to_csv(
    OUTDIR / "tableS_per_seed_results_15seed.csv",
    index=False,
)


# ---------------------------------------------------------
# Concise audit report
# ---------------------------------------------------------

primary_significant = (
    primary["permutation_p_holm_primary_global"] < 0.05
)

print("DONE: complete 15-seed statistical package created")
print("Saved directory:", OUTDIR)
print()

print("PRIMARY TEST COUNT:", len(primary))
print(
    "PRIMARY HOLM-SIGNIFICANT:",
    int(primary_significant.sum()),
    "/",
    len(primary),
)

print(
    "MAX PRIMARY HOLM-CORRECTED PERMUTATION P:",
    primary["permutation_p_holm_primary_global"].max(),
)

non_significant = primary[
    primary["permutation_p_holm_primary_global"] >= 0.05
][
    [
        "dataset",
        "metric",
        "exact_permutation_p",
        "permutation_p_holm_primary_global",
    ]
]

print("\nNON-SIGNIFICANT PRIMARY RESULTS:")
if non_significant.empty:
    print("None")
else:
    print(non_significant.to_string(index=False))

print("\nMAIN 15-SEED RESULTS:")
print(main_table.round(4).to_string(index=False))

print("\nFILES:")
for path in sorted(OUTDIR.glob("*.csv")):
    print(path)
