#!/usr/bin/env python3
"""
TAFP-GraphRAG released-view GNN attacker capacity check.

Evidence-locked design
----------------------
- Authoritative branch/commit/manuscript are verified before execution.
- Active source files are verified against exact SHA256 values recovered from
  the submission repository.
- PubMed and SynthPII raw graph tables are accepted only when their exact
  recovered SHA256 values match.
- The locked 10-split assignment file is accepted only at its exact SHA256.
- Split-edge endpoints, relation labels, and sensitivity groups are verified
  against the loaded simple graphs before any model is trained.
- The experiment does not edit the repository or manuscript.

Attack
------
A two-layer GCN graph autoencoder learns node representations from an explicit
release projection of the protected graph. The embeddings are then used in the exact pair-feature
construction employed by the recovered V22 spectral attack, followed by the
same balanced MLP relation classifier. Two settings are evaluated:
  1. topology_only: topology-derived node features only;
  2. topology_plus_entity_type: the same features plus non-text entity type;
  3. topology_plus_released_attributes: entity-type-aware GCN embeddings plus
     target-edge-excluded distributions of neighboring exposed protected
     relation labels.

The release projection relabels node keys through protected_label and retains only
entity_type on nodes and protected_relation_type on edges. The GCN encoder never
consumes relation labels, raw node text, original labels, sensitivity flags, policy
scores, or audit metadata. The target
edge is present because this is the manuscript's fixed-edge relation-inference
setting: the adversary observes the released graph and tries to recover the
original relation class.
"""

from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
import math
import os
import random
import shutil
import subprocess
import sys
import time
import warnings
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import networkx as nx
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

try:
    import torch
    from torch import nn
except Exception as exc:  # pragma: no cover
    raise RuntimeError(
        "PyTorch is required. Google Colab normally provides it by default."
    ) from exc


# ---------------------------------------------------------------------------
# Locked provenance
# ---------------------------------------------------------------------------
EXPECTED_BRANCH = "revision/applied-sciences-pre-submission-20260620t212703z"
EXPECTED_COMMIT = "0b5ce8e9080fc7ded51f2d9bf92219fa9afcc384"
EXPECTED_MANUSCRIPT_SHA256 = (
    "8e6c24a8f858f90acec1773abd5f063eb3f834a05816accaef37f166a57ffcb2"
)
MANUSCRIPT_REL = Path("manuscript/TAFP_GraphRAG_Revised_E2E_Integrated.docx")

EXPECTED_SOURCE_HASHES = {
    "dataset_loader.py": "ad8dc201402b61c838f6afd6ea5b4dce6e08b3f3f967c4f0e2419668f152bb5d",
    "protections_v8.py": "b4e3dd30745189c01d58b80463d901c305c178df67c05edd17541fcb614d84c9",
    "protections_v8_baselines.py": "f18984ce9f2d4ac6e251c832e7a1a1ecab908c3c9bc3bfaa11cee507ebb0cf81",
    "risk.py": "48ccf110fd43da4471011af9e9442d58e2b83beff2f73fca6eaa5d337037b6a1",
    "v9_semantic_relation_structure_smoke.py": "f3862c13fcf5b30ac37c8c62d294a02497be336c9412bcb38790c4d1336b148d",
    "v9_semantic_relation_local_topology_multisplit.py": "adaaac752cecd3c8d866d2ab383e8263cb2768016a3d12d9c9d137b61c8bf8db",
}

EXPECTED_CONFIG_HASHES = {
    "config_pubmed_gpu_embedding.json": "6c613006d0277fdea67f9b38c54cbaf6e61f0951b245adf6838fcd3c87df6547",
    "config_synthpii_gpu_embedding.json": "fc1f98684b4c6d1795c882bceef88261d56191315ab78e7cf986942df3e9ebcb",
}

EXPECTED_RAW_HASHES = {
    "pubmed_nodes.csv": "61b08841a8681f84fb34b5afd6feb58c46bc275bab64fe8d60b610d2d5c8f20c",
    "pubmed_edges.csv": "d493c12ca52d33a92085e5ea6fa27874c98347c02fc66ecb09cbab2e816ffad9",
    "synthpii_nodes.csv": "e6f9bd57498f94caf8a4c7c57cf8fa20245e8fee7ebd600d1c0338c2266e4d8a",
    "synthpii_edges.csv": "32e31c6dd4d45e10ff7ca4d80e9daca4c182d841769c955e196d2944a3b229c1",
}

EXPECTED_SPLIT_SHA256 = (
    "b7220d25d48cedd7cb790d3c919d50520d25bd4fb9627f8e58d710fd20d3ebe7"
)
EXPECTED_SPLIT_ROWS = 8900
EXPECTED_UNIQUE_MODELING_EDGES = {"PubMed": 430, "SynthPII": 460}
EXPECTED_GRAPH_COUNTS = {
    "PubMed": {"nodes": 1070, "edges": 4254},
    "SynthPII": {"nodes": 800, "edges": 2400},
}

DATASETS = ["PubMed", "SynthPII"]
PROTECTION_SEEDS = [
    1, 7, 21, 42, 99, 123, 202, 303, 404, 505, 606, 707, 808, 909, 1001
]
SPLIT_SEEDS = [101, 202, 303, 404, 505, 606, 707, 808, 909, 1001]
VARIANTS = ["baseline", "full", "random_full_budget"]
FEATURE_MODES = [
    "topology_only",
    "topology_plus_entity_type",
    "topology_plus_released_attributes",
]
METRICS = ["macro_f1", "balanced_accuracy", "accuracy"]
KEY_COLUMNS = [
    "dataset_name",
    "protection_seed",
    "variant",
    "feature_mode",
    "split_seed",
]
EXPECTED_ROWS = (
    len(DATASETS)
    * len(PROTECTION_SEEDS)
    * len(VARIANTS)
    * len(FEATURE_MODES)
    * len(SPLIT_SEEDS)
)

# Fixed capacity-check hyperparameters, declared before observing results.
GCN_HIDDEN_DIM = 64
GCN_OUTPUT_DIM = 32
GCN_EPOCHS = 160
GCN_LEARNING_RATE = 0.01
GCN_WEIGHT_DECAY = 1e-4
GCN_DROPOUT = 0.10
NEGATIVE_RATIO = 1.0


# ---------------------------------------------------------------------------
# General utilities
# ---------------------------------------------------------------------------
def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def stable_seed(*parts: Any) -> int:
    payload = "|".join(map(str, parts)).encode("utf-8")
    return int(hashlib.sha256(payload).hexdigest()[:8], 16)


def canonical_edge_key(u: Any, v: Any) -> str:
    a, b = sorted([str(u), str(v)])
    return f"{a}||{b}"


def run_git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=repo,
        check=True,
        text=True,
        capture_output=True,
    )
    return result.stdout.strip()


def find_repo() -> Path:
    candidates = [
        Path(os.environ.get("TAFP_REPO_PATH", "")),
        Path("/content/tafp_repo_audit/tafp-graphrag"),
        Path("/content/tafp-graphrag"),
        Path("/content/tafp_repo/tafp-graphrag"),
    ]
    for candidate in candidates:
        if candidate and (candidate / ".git").exists():
            return candidate.resolve()
    raise RuntimeError("Authoritative repository clone was not found.")


def mount_drive() -> Path:
    drive_root = Path("/content/drive")
    project = drive_root / "MyDrive" / "TAFP_GraphRAG"
    if project.exists():
        return project
    try:
        from google.colab import drive
        drive.mount(str(drive_root))
    except Exception as exc:
        raise RuntimeError(f"Google Drive could not be mounted: {exc}") from exc
    if not project.exists():
        raise RuntimeError(f"Drive project directory not found: {project}")
    return project


def verify_repo(repo: Path) -> dict[str, Any]:
    branch = run_git(repo, "branch", "--show-current")
    commit = run_git(repo, "rev-parse", "HEAD")
    status = run_git(repo, "status", "--porcelain").splitlines()
    manuscript = repo / MANUSCRIPT_REL
    report = {
        "branch": branch,
        "branch_match": branch == EXPECTED_BRANCH,
        "commit": commit,
        "commit_match": commit == EXPECTED_COMMIT,
        "worktree_clean": len(status) == 0,
        "git_status": status,
        "manuscript": str(manuscript),
        "manuscript_sha256": sha256_file(manuscript) if manuscript.exists() else None,
    }
    report["manuscript_hash_match"] = (
        report["manuscript_sha256"] == EXPECTED_MANUSCRIPT_SHA256
    )
    if not all([
        report["branch_match"],
        report["commit_match"],
        report["worktree_clean"],
        report["manuscript_hash_match"],
    ]):
        raise RuntimeError("Repository verification failed:\n" + json.dumps(report, indent=2))
    return report


def verify_locked_sources(repo: Path) -> dict[str, str]:
    verified: dict[str, str] = {}
    for relative, expected in {**EXPECTED_SOURCE_HASHES, **EXPECTED_CONFIG_HASHES}.items():
        path = repo / relative
        if not path.exists():
            raise FileNotFoundError(path)
        actual = sha256_file(path)
        if actual != expected:
            raise RuntimeError(
                f"Locked source mismatch: {relative}\nexpected={expected}\nactual={actual}"
            )
        verified[relative] = actual
    return verified


def find_exact_file(
    roots: list[Path],
    basename: str,
    expected_sha256: str,
) -> Path:
    preferred = []
    for root in roots:
        if not root.exists():
            continue
        if root.is_file():
            candidates = [root]
        else:
            candidates = list(root.rglob(basename))
        for candidate in candidates:
            if candidate.is_file() and candidate.name == basename:
                try:
                    if sha256_file(candidate) == expected_sha256:
                        preferred.append(candidate.resolve())
                except OSError:
                    continue
    if not preferred:
        raise FileNotFoundError(
            f"No exact-hash file found for {basename}: {expected_sha256}"
        )
    preferred.sort(key=lambda p: ("restored_data" not in str(p), len(str(p))))
    return preferred[0]


def load_and_verify_split(split_path: Path) -> pd.DataFrame:
    if sha256_file(split_path) != EXPECTED_SPLIT_SHA256:
        raise RuntimeError("Locked split hash mismatch.")
    frame = pd.read_csv(split_path)
    required = {
        "split_seed", "edge_key", "split", "target_group", "relation_type", "dataset_name"
    }
    if not required.issubset(frame.columns):
        raise RuntimeError(f"Locked split columns missing: {sorted(required - set(frame.columns))}")
    if len(frame) != EXPECTED_SPLIT_ROWS:
        raise RuntimeError(f"Locked split row mismatch: {len(frame)}")
    if set(frame["dataset_name"].astype(str)) != set(DATASETS):
        raise RuntimeError("Locked split dataset mismatch.")
    if set(frame["split_seed"].astype(int)) != set(SPLIT_SEEDS):
        raise RuntimeError("Locked split seed mismatch.")
    if set(frame["split"].astype(str)) != {"train", "test"}:
        raise RuntimeError("Locked split values mismatch.")
    duplicate_count = int(
        frame.duplicated(["dataset_name", "split_seed", "edge_key"]).sum()
    )
    if duplicate_count:
        raise RuntimeError(f"Duplicate split assignments: {duplicate_count}")
    for dataset, expected_count in EXPECTED_UNIQUE_MODELING_EDGES.items():
        count = int(frame.loc[frame["dataset_name"].eq(dataset), "edge_key"].nunique())
        if count != expected_count:
            raise RuntimeError(
                f"{dataset}: modeling-edge count mismatch {count} != {expected_count}"
            )
    return frame


def parse_edge_key(value: str) -> tuple[str, str]:
    parts = str(value).split("||")
    if len(parts) != 2:
        raise ValueError(f"Invalid locked edge key: {value}")
    return parts[0], parts[1]


def validate_graph_against_split(
    dataset: str,
    graph: nx.Graph,
    split_frame: pd.DataFrame,
) -> dict[str, Any]:
    unique = (
        split_frame.loc[split_frame["dataset_name"].eq(dataset)]
        .sort_values(["edge_key", "split_seed"])
        .drop_duplicates("edge_key")
        .reset_index(drop=True)
    )
    missing = []
    relation_mismatches = []
    group_mismatches = []
    for row in unique.itertuples(index=False):
        u, v = parse_edge_key(row.edge_key)
        if not graph.has_edge(u, v):
            missing.append(row.edge_key)
            continue
        attrs = graph.get_edge_data(u, v)
        relation = str(attrs.get("relation_type", "related_to"))
        if relation != str(row.relation_type):
            relation_mismatches.append((row.edge_key, row.relation_type, relation))
        sensitive = int(
            float(attrs.get("sensitive", 0.0)) >= 0.5
            or float(attrs.get("relation_sensitivity", 0.0)) >= 0.45
        )
        expected_group = "sensitive" if sensitive else "non_sensitive"
        if expected_group != str(row.target_group):
            group_mismatches.append((row.edge_key, row.target_group, expected_group))
    result = {
        "dataset": dataset,
        "unique_split_edges": len(unique),
        "missing_edges": len(missing),
        "relation_mismatches": len(relation_mismatches),
        "target_group_mismatches": len(group_mismatches),
        "missing_examples": missing[:10],
        "relation_mismatch_examples": relation_mismatches[:10],
        "group_mismatch_examples": group_mismatches[:10],
    }
    if any([missing, relation_mismatches, group_mismatches]):
        raise RuntimeError("Graph/split validation failed:\n" + json.dumps(result, indent=2))
    return result


def exact_signflip_pvalue(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) == 0:
        return float("nan")
    if np.allclose(values, 0.0):
        return 1.0
    observed = abs(float(values.mean()))
    total = 1 << len(values)
    extreme = 0
    for mask in range(total):
        signed = np.array([
            value if ((mask >> index) & 1) else -value
            for index, value in enumerate(values)
        ])
        if abs(float(signed.mean())) >= observed - 1e-15:
            extreme += 1
    return float(extreme / total)


def holm_adjust(pvalues: list[float]) -> list[float]:
    result = [float("nan")] * len(pvalues)
    finite = [(i, p) for i, p in enumerate(pvalues) if np.isfinite(p)]
    finite.sort(key=lambda item: item[1])
    running = 0.0
    m = len(finite)
    for rank, (index, pvalue) in enumerate(finite):
        adjusted = min(1.0, (m - rank) * pvalue)
        running = max(running, adjusted)
        result[index] = running
    return result


# ---------------------------------------------------------------------------
# GCN graph autoencoder
# ---------------------------------------------------------------------------
class GCNEncoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, dropout: float):
        super().__init__()
        self.linear1 = nn.Linear(input_dim, hidden_dim, bias=False)
        self.linear2 = nn.Linear(hidden_dim, output_dim, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, features: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        hidden = torch.sparse.mm(adjacency, self.linear1(features))
        hidden = torch.relu(hidden)
        hidden = self.dropout(hidden)
        embeddings = torch.sparse.mm(adjacency, self.linear2(hidden))
        return embeddings


def set_all_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        torch.use_deterministic_algorithms(True, warn_only=True)
    except Exception:
        pass


def normalized_adjacency(graph: nx.Graph, nodes: list[str], device: torch.device) -> torch.Tensor:
    index = {node: i for i, node in enumerate(nodes)}
    rows: list[int] = []
    cols: list[int] = []
    for u, v in graph.edges():
        iu, iv = index[u], index[v]
        rows.extend([iu, iv])
        cols.extend([iv, iu])
    for i in range(len(nodes)):
        rows.append(i)
        cols.append(i)
    indices = torch.tensor([rows, cols], dtype=torch.long, device=device)
    values = torch.ones(len(rows), dtype=torch.float32, device=device)
    degree = torch.zeros(len(nodes), dtype=torch.float32, device=device)
    degree.scatter_add_(0, indices[0], values)
    inv_sqrt = degree.clamp(min=1.0).pow(-0.5)
    norm_values = values * inv_sqrt[indices[0]] * inv_sqrt[indices[1]]
    return torch.sparse_coo_tensor(
        indices, norm_values, (len(nodes), len(nodes)), device=device
    ).coalesce()




PROHIBITED_RELEASE_NODE_ATTRIBUTES = {
    "original_label", "text", "pii", "semantic_sensitivity"
}
PROHIBITED_RELEASE_EDGE_ATTRIBUTES = {
    "sensitive", "relation_sensitivity", "original_relation_type"
}

def build_release_projection(graph: nx.Graph) -> tuple[nx.Graph, dict[str, str], dict[str, Any]]:
    """Create the exact adversarial release view used by this GNN audit.

    Public node keys are protected labels/pseudonyms. Only entity_type is
    retained as a node attribute. Only the exposed protected relation label is
    retained as an edge attribute. Source labels, text, policy fields, original
    relation labels, and audit records are dropped.
    """
    released = nx.Graph()
    original_to_public: dict[str, str] = {}
    public_ids: set[str] = set()

    for node, data in graph.nodes(data=True):
        public_id = str(data.get("protected_label", node))
        if public_id in public_ids:
            raise RuntimeError(f"Release-view node ID collision: {public_id}")
        public_ids.add(public_id)
        original_to_public[str(node)] = public_id
        released.add_node(
            public_id,
            entity_type=str(data.get("entity_type", "ENTITY")),
        )

    for source, target, data in graph.edges(data=True):
        public_source = original_to_public[str(source)]
        public_target = original_to_public[str(target)]
        exposed_relation = str(
            data.get(
                "protected_relation_type",
                data.get("relation_type", "related_to"),
            )
        )
        released.add_edge(
            public_source,
            public_target,
            relation_type=exposed_relation,
        )

    released.graph.clear()
    released.graph["release_view_schema"] = "TAFP_RELEASE_VIEW_V1"

    node_attribute_names = {
        key
        for _, data in released.nodes(data=True)
        for key in data
    }
    edge_attribute_names = {
        key
        for _, _, data in released.edges(data=True)
        for key in data
    }

    audit = {
        "node_count": released.number_of_nodes(),
        "edge_count": released.number_of_edges(),
        "node_id_unique": len(public_ids) == graph.number_of_nodes(),
        "topology_count_preserved": int(
            released.number_of_nodes() == graph.number_of_nodes()
            and released.number_of_edges() == graph.number_of_edges()
        ),
        "node_attribute_names": sorted(node_attribute_names),
        "edge_attribute_names": sorted(edge_attribute_names),
        "graph_attribute_names": sorted(released.graph.keys()),
        "prohibited_node_attributes_present": sorted(
            node_attribute_names & PROHIBITED_RELEASE_NODE_ATTRIBUTES
        ),
        "prohibited_edge_attributes_present": sorted(
            edge_attribute_names & PROHIBITED_RELEASE_EDGE_ATTRIBUTES
        ),
    }
    audit["pass"] = bool(
        audit["node_id_unique"]
        and audit["topology_count_preserved"] == 1
        and node_attribute_names == {"entity_type"}
        and edge_attribute_names == {"relation_type"}
        and not audit["prohibited_node_attributes_present"]
        and not audit["prohibited_edge_attributes_present"]
    )
    if not audit["pass"]:
        raise RuntimeError(
            "Release projection audit failed:\n" + json.dumps(audit, indent=2)
        )
    return released, original_to_public, audit


def build_node_features(
    graph: nx.Graph,
    nodes: list[str],
    feature_mode: str,
) -> tuple[np.ndarray, dict[str, Any]]:
    degrees = np.array([graph.degree(node) for node in nodes], dtype=np.float64)
    max_degree = max(1.0, float(degrees.max()))
    degree_norm = degrees / max_degree
    log_degree = np.log1p(degrees)
    log_degree /= max(1.0, float(log_degree.max()))
    clustering_map = nx.clustering(graph)
    clustering = np.array([clustering_map.get(node, 0.0) for node in nodes], dtype=np.float64)
    base = np.column_stack([
        np.ones(len(nodes), dtype=np.float64),
        degree_norm,
        log_degree,
        clustering,
    ])
    metadata: dict[str, Any] = {
        "topology_feature_names": [
            "constant", "degree_normalized", "log_degree_normalized", "clustering"
        ],
        "entity_types": [],
    }
    if feature_mode == "topology_only":
        features = base
    elif feature_mode in {
        "topology_plus_entity_type",
        "topology_plus_released_attributes",
    }:
        entity_types = sorted({str(graph.nodes[node].get("entity_type", "ENTITY")) for node in nodes})
        type_index = {name: i for i, name in enumerate(entity_types)}
        one_hot = np.zeros((len(nodes), len(entity_types)), dtype=np.float64)
        for row_index, node in enumerate(nodes):
            entity_type = str(graph.nodes[node].get("entity_type", "ENTITY"))
            one_hot[row_index, type_index[entity_type]] = 1.0
        features = np.column_stack([base, one_hot])
        metadata["entity_types"] = entity_types
    else:
        raise ValueError(feature_mode)
    return features.astype(np.float32), metadata


def sample_fixed_negative_edges(
    graph: nx.Graph,
    nodes: list[str],
    count: int,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    index = {node: i for i, node in enumerate(nodes)}
    existing = {
        tuple(sorted((index[u], index[v])))
        for u, v in graph.edges()
        if u != v
    }
    selected: set[tuple[int, int]] = set()
    n = len(nodes)
    attempts = 0
    max_attempts = max(10000, count * 100)
    while len(selected) < count and attempts < max_attempts:
        attempts += 1
        u = int(rng.integers(0, n))
        v = int(rng.integers(0, n))
        if u == v:
            continue
        pair = tuple(sorted((u, v)))
        if pair in existing or pair in selected:
            continue
        selected.add(pair)
    if len(selected) != count:
        raise RuntimeError(f"Negative sampling incomplete: {len(selected)} / {count}")
    return np.asarray(sorted(selected), dtype=np.int64)


class EmbeddingLookup(dict):
    """Embedding dictionary carrying the exact released-view context."""

    def __init__(
        self,
        *args: Any,
        release_graph: nx.Graph,
        original_to_public: dict[str, str],
        relation_vocabulary: list[str],
        feature_mode: str,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.release_graph = release_graph
        self.original_to_public = original_to_public
        self.relation_vocabulary = relation_vocabulary
        self.feature_mode = feature_mode


def neighboring_released_relation_features(
    graph: nx.Graph,
    source: str,
    target: str,
    relation_vocabulary: list[str],
) -> np.ndarray:
    """Pair-specific released relation context with target label excluded."""
    counts_source: Counter[str] = Counter()
    counts_target: Counter[str] = Counter()

    for _, neighbor, data in graph.edges(source, data=True):
        if str(neighbor) == str(target):
            continue
        counts_source[str(data.get("relation_type", "related_to"))] += 1

    for _, neighbor, data in graph.edges(target, data=True):
        if str(neighbor) == str(source):
            continue
        counts_target[str(data.get("relation_type", "related_to"))] += 1

    total_source = max(1, sum(counts_source.values()))
    total_target = max(1, sum(counts_target.values()))
    features: list[float] = []

    for relation in relation_vocabulary:
        source_count = float(counts_source.get(relation, 0))
        target_count = float(counts_target.get(relation, 0))
        source_fraction = source_count / total_source
        target_fraction = target_count / total_target
        features.extend([
            source_count + target_count,
            abs(source_count - target_count),
            source_fraction + target_fraction,
            abs(source_fraction - target_fraction),
        ])

    return np.asarray(features, dtype=np.float64)


def train_gcn_gae(
    graph: nx.Graph,
    feature_mode: str,
    seed: int,
    device: torch.device,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    set_all_seeds(seed)
    released_graph, original_to_public, release_audit = build_release_projection(graph)
    requested_feature_mode = feature_mode
    node_feature_mode = (
        "topology_plus_entity_type"
        if feature_mode == "topology_plus_released_attributes"
        else feature_mode
    )

    nodes = sorted(map(str, released_graph.nodes()))
    if set(nodes) != set(map(str, released_graph.nodes())):
        raise RuntimeError("Released node string conversion collision detected.")
    graph_nodes = list(released_graph.nodes())
    string_lookup = {str(node): node for node in graph_nodes}
    ordered_nodes = [string_lookup[name] for name in nodes]

    features_np, feature_metadata = build_node_features(
        released_graph, ordered_nodes, node_feature_mode
    )
    features = torch.tensor(features_np, dtype=torch.float32, device=device)
    adjacency = normalized_adjacency(released_graph, ordered_nodes, device)
    node_index = {node: i for i, node in enumerate(ordered_nodes)}

    positive_pairs = np.asarray(
        sorted({
            tuple(sorted((node_index[u], node_index[v])))
            for u, v in released_graph.edges()
            if u != v
        }),
        dtype=np.int64,
    )
    negative_count = int(round(len(positive_pairs) * NEGATIVE_RATIO))
    negative_pairs = sample_fixed_negative_edges(
        released_graph,
        ordered_nodes,
        negative_count,
        stable_seed(seed, feature_mode, "negative"),
    )

    positive_tensor = torch.tensor(positive_pairs, dtype=torch.long, device=device)
    negative_tensor = torch.tensor(negative_pairs, dtype=torch.long, device=device)

    model = GCNEncoder(
        input_dim=features.shape[1],
        hidden_dim=GCN_HIDDEN_DIM,
        output_dim=GCN_OUTPUT_DIM,
        dropout=GCN_DROPOUT,
    ).to(device)
    optimizer = torch.optim.Adam(
        model.parameters(), lr=GCN_LEARNING_RATE, weight_decay=GCN_WEIGHT_DECAY
    )
    criterion = nn.BCEWithLogitsLoss()
    start = time.time()
    loss_history: list[float] = []

    for _ in range(GCN_EPOCHS):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        embeddings = model(features, adjacency)
        positive_logits = (
            embeddings[positive_tensor[:, 0]] * embeddings[positive_tensor[:, 1]]
        ).sum(dim=1)
        negative_logits = (
            embeddings[negative_tensor[:, 0]] * embeddings[negative_tensor[:, 1]]
        ).sum(dim=1)
        logits = torch.cat([positive_logits, negative_logits])
        labels = torch.cat([
            torch.ones_like(positive_logits),
            torch.zeros_like(negative_logits),
        ])
        loss = criterion(logits, labels)
        if not torch.isfinite(loss):
            raise RuntimeError("Non-finite GCN-GAE loss.")
        loss.backward()
        optimizer.step()
        loss_history.append(float(loss.detach().cpu()))

    model.eval()
    with torch.no_grad():
        embeddings = model(features, adjacency)
        embeddings = torch.nn.functional.normalize(embeddings, p=2, dim=1)
        embedding_np = embeddings.detach().cpu().numpy().astype(np.float64)

    public_lookup = {
        str(node): embedding_np[index]
        for index, node in enumerate(ordered_nodes)
    }
    relation_vocabulary = sorted({
        str(data.get("relation_type", "related_to"))
        for _, _, data in released_graph.edges(data=True)
    })
    original_lookup = EmbeddingLookup(
        {
            original: public_lookup[public]
            for original, public in original_to_public.items()
        },
        release_graph=released_graph,
        original_to_public=original_to_public,
        relation_vocabulary=relation_vocabulary,
        feature_mode=requested_feature_mode,
    )
    metadata = {
        "feature_mode": requested_feature_mode,
        "gcn_node_feature_mode": node_feature_mode,
        "released_relation_vocabulary": relation_vocabulary,
        "target_edge_relation_label_excluded": True,
        "released_pair_attribute_dimension": (
            4 * len(relation_vocabulary)
            if requested_feature_mode == "topology_plus_released_attributes"
            else 0
        ),
        "input_dimension": int(features.shape[1]),
        "hidden_dimension": GCN_HIDDEN_DIM,
        "embedding_dimension": GCN_OUTPUT_DIM,
        "epochs": GCN_EPOCHS,
        "learning_rate": GCN_LEARNING_RATE,
        "weight_decay": GCN_WEIGHT_DECAY,
        "dropout": GCN_DROPOUT,
        "positive_edges": int(len(positive_pairs)),
        "negative_edges": int(len(negative_pairs)),
        "initial_loss": float(loss_history[0]),
        "final_loss": float(loss_history[-1]),
        "training_seconds": float(time.time() - start),
        "device": str(device),
        "release_view_audit": release_audit,
        **feature_metadata,
    }
    return original_lookup, metadata


def make_pair_feature(vector_u: np.ndarray, vector_v: np.ndarray) -> np.ndarray:
    absolute_difference = np.abs(vector_u - vector_v)
    elementwise_product = vector_u * vector_v
    vector_sum = vector_u + vector_v
    dot_product = float(np.dot(vector_u, vector_v))
    l2_distance = float(np.linalg.norm(vector_u - vector_v))
    return np.concatenate([
        absolute_difference,
        elementwise_product,
        vector_sum,
        np.array([dot_product, l2_distance], dtype=np.float64),
    ])


def pair_matrix(
    frame: pd.DataFrame,
    lookup: dict[str, np.ndarray],
) -> tuple[np.ndarray, np.ndarray]:
    features: list[np.ndarray] = []
    labels: list[str] = []
    released_mode = (
        isinstance(lookup, EmbeddingLookup)
        and lookup.feature_mode == "topology_plus_released_attributes"
    )

    for row in frame.itertuples(index=False):
        u, v = parse_edge_key(row.edge_key)
        if u not in lookup or v not in lookup:
            raise KeyError(f"Missing embedding endpoint: {row.edge_key}")
        pair_feature = make_pair_feature(lookup[u], lookup[v])

        if released_mode:
            public_u = lookup.original_to_public[u]
            public_v = lookup.original_to_public[v]
            released_attributes = neighboring_released_relation_features(
                lookup.release_graph,
                public_u,
                public_v,
                lookup.relation_vocabulary,
            )
            pair_feature = np.concatenate([
                pair_feature,
                released_attributes,
            ])

        features.append(pair_feature)
        labels.append(str(row.relation_type))

    return np.asarray(features, dtype=np.float64), np.asarray(labels, dtype=object)


def balanced_resample(
    features: np.ndarray,
    labels: np.ndarray,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    classes, counts = np.unique(labels, return_counts=True)
    target_count = int(counts.max())
    selected: list[int] = []
    for class_name in classes:
        class_indices = np.where(labels == class_name)[0]
        sampled = rng.choice(
            class_indices,
            size=target_count,
            replace=len(class_indices) < target_count,
        )
        selected.extend(sampled.tolist())
    selected_array = np.asarray(selected, dtype=int)
    rng.shuffle(selected_array)
    return features[selected_array], labels[selected_array]


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def build_summary(results: pd.DataFrame) -> pd.DataFrame:
    rows = []
    grouping = ["dataset_name", "feature_mode", "variant"]
    for keys, group in results.groupby(grouping, sort=True):
        row = dict(zip(grouping, keys))
        row["n_runs"] = int(len(group))
        row["n_protection_seeds"] = int(group["protection_seed"].nunique())
        row["n_split_seeds"] = int(group["split_seed"].nunique())
        for metric in METRICS:
            row[f"{metric}_mean"] = float(group[metric].mean())
            row[f"{metric}_std"] = float(group[metric].std(ddof=1))
        row["gcn_training_seconds_mean"] = float(group["gcn_training_seconds"].mean())
        rows.append(row)
    return pd.DataFrame(rows).sort_values(grouping).reset_index(drop=True)


def build_paired_tests(results: pd.DataFrame) -> pd.DataFrame:
    protection_level = (
        results.groupby(
            ["dataset_name", "feature_mode", "variant", "protection_seed"],
            as_index=False,
        )[METRICS]
        .mean()
    )
    comparisons = [
        ("full_vs_baseline", "full", "baseline"),
        ("full_vs_random_full_budget", "full", "random_full_budget"),
    ]
    rows = []
    for dataset in DATASETS:
        for feature_mode in FEATURE_MODES:
            subset = protection_level[
                protection_level["dataset_name"].eq(dataset)
                & protection_level["feature_mode"].eq(feature_mode)
            ]
            for comparison, left, right in comparisons:
                left_frame = subset[subset["variant"].eq(left)].set_index("protection_seed")
                right_frame = subset[subset["variant"].eq(right)].set_index("protection_seed")
                common = sorted(set(left_frame.index) & set(right_frame.index))
                if common != PROTECTION_SEEDS:
                    raise RuntimeError(
                        f"Incomplete paired seeds: {dataset}, {feature_mode}, {comparison}"
                    )
                for metric in METRICS:
                    differences = (
                        left_frame.loc[common, metric].to_numpy(dtype=float)
                        - right_frame.loc[common, metric].to_numpy(dtype=float)
                    )
                    if np.allclose(differences, 0.0):
                        wilcoxon_p = 1.0
                    else:
                        wilcoxon_p = float(wilcoxon(differences, zero_method="wilcox").pvalue)
                    rows.append({
                        "dataset_name": dataset,
                        "feature_mode": feature_mode,
                        "comparison": comparison,
                        "metric": metric,
                        "n_protection_seeds": len(common),
                        "left_variant": left,
                        "right_variant": right,
                        "left_mean": float(left_frame.loc[common, metric].mean()),
                        "right_mean": float(right_frame.loc[common, metric].mean()),
                        "mean_difference_left_minus_right": float(differences.mean()),
                        "exact_signflip_p": exact_signflip_pvalue(differences),
                        "wilcoxon_p": wilcoxon_p,
                    })
    tests = pd.DataFrame(rows)
    tests["exact_signflip_p_holm"] = holm_adjust(tests["exact_signflip_p"].tolist())
    tests["wilcoxon_p_holm"] = holm_adjust(tests["wilcoxon_p"].tolist())
    return tests



def internal_release_view_self_test() -> None:
    toy = nx.Graph()
    toy.add_node("Alice", protected_label="ENT_HIGH_abc12345", entity_type="PERSON",
                 original_label="Alice", text="secret", pii=1, semantic_sensitivity=0.9)
    toy.add_node("Clinic", protected_label="Clinic", entity_type="ORG",
                 original_label="Clinic", text="clinic", pii=0, semantic_sensitivity=0.2)
    toy.add_edge("Alice", "Clinic", relation_type="diagnosis",
                 protected_relation_type="PRIVATE_RELATION", sensitive=1, weight=1.0)
    released, mapping, audit = build_release_projection(toy)
    assert audit["pass"]
    assert set(released.nodes()) == {"ENT_HIGH_abc12345", "Clinic"}
    assert set(released.nodes["ENT_HIGH_abc12345"].keys()) == {"entity_type"}
    attrs = next(iter(released.edges(data=True)))[2]
    assert attrs == {"relation_type": "PRIVATE_RELATION"}
    assert mapping["Alice"] == "ENT_HIGH_abc12345"
    relation_features = neighboring_released_relation_features(
        released,
        "ENT_HIGH_abc12345",
        "Clinic",
        ["PRIVATE_RELATION"],
    )
    # The only edge is the target edge and must be excluded.
    assert relation_features.tolist() == [0.0, 0.0, 0.0, 0.0]


def main() -> None:
    internal_release_view_self_test()
    print("INTERNAL RELEASE-VIEW SELF-TEST: PASS")
    stamp = utc_stamp()
    repo = find_repo()
    drive_project = mount_drive()
    repo_verification = verify_repo(repo)
    source_hashes = verify_locked_sources(repo)

    evidence_roots = [
        drive_project / "restored_data" / "TAFP_GRAPH_CSVS_20260620T233210Z" / "data",
        drive_project,
        repo,
    ]
    raw_paths = {
        basename: find_exact_file(evidence_roots, basename, digest)
        for basename, digest in EXPECTED_RAW_HASHES.items()
    }
    split_path = find_exact_file(
        [repo, drive_project], "split_assignments.csv", EXPECTED_SPLIT_SHA256
    )
    split_frame = load_and_verify_split(split_path)

    if str(repo) not in sys.path:
        sys.path.insert(0, str(repo))
    from dataset_loader import build_graph_from_config
    from protections_v8_baselines import apply_variant
    from risk import compute_all_risks
    from v9_semantic_relation_structure_smoke import seeded_config

    output_dir = drive_project / "reviewer2_experiments" / f"GNN_GAE_RELEASED_ATTRIBUTES_{stamp}"
    output_dir.mkdir(parents=True, exist_ok=False)
    checkpoint_path = output_dir / "gcn_gae_relation_attack_checkpoint.csv"
    final_results_path = output_dir / "gcn_gae_relation_attack_results.csv"
    summary_path = output_dir / "table_gcn_gae_relation_attack_summary.csv"
    paired_path = output_dir / "table_gcn_gae_relation_attack_paired_tests.csv"
    audit_path = output_dir / "gcn_gae_relation_attack_audit.json"

    if checkpoint_path.exists():
        results = pd.read_csv(checkpoint_path)
    else:
        results = pd.DataFrame()
    completed = set()
    if len(results):
        completed = set(
            zip(*(results[column].tolist() for column in KEY_COLUMNS))
        )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    graph_validation: list[dict[str, Any]] = []
    embedding_records: list[dict[str, Any]] = []
    new_rows: list[dict[str, Any]] = []

    for dataset in DATASETS:
        prefix = "pubmed" if dataset == "PubMed" else "synthpii"
        config_path = repo / f"config_{prefix}_gpu_embedding.json"
        with config_path.open("r", encoding="utf-8") as handle:
            original_config = json.load(handle)
        original_config["node_csv_path"] = str(raw_paths[f"{prefix}_nodes.csv"])
        original_config["edge_csv_path"] = str(raw_paths[f"{prefix}_edges.csv"])
        base_graph = build_graph_from_config(original_config)
        expected_counts = EXPECTED_GRAPH_COUNTS[dataset]
        if (
            base_graph.number_of_nodes() != expected_counts["nodes"]
            or base_graph.number_of_edges() != expected_counts["edges"]
        ):
            raise RuntimeError(
                f"{dataset}: graph count mismatch: "
                f"{base_graph.number_of_nodes()} nodes, {base_graph.number_of_edges()} edges"
            )
        graph_validation.append(
            validate_graph_against_split(dataset, base_graph, split_frame)
        )
        risks = compute_all_risks(base_graph)
        dataset_splits = split_frame[split_frame["dataset_name"].eq(dataset)].copy()

        for protection_seed in PROTECTION_SEEDS:
            config = seeded_config(original_config, protection_seed)
            for variant in VARIANTS:
                required = {
                    (dataset, protection_seed, variant, feature_mode, split_seed)
                    for feature_mode in FEATURE_MODES
                    for split_seed in SPLIT_SEEDS
                }
                if required.issubset(completed):
                    continue
                random.seed(protection_seed)
                np.random.seed(protection_seed)
                protected_graph = apply_variant(base_graph, risks, variant, config)
                degree_exact = int(dict(base_graph.degree()) == dict(protected_graph.degree()))
                edge_count_exact = int(
                    base_graph.number_of_edges() == protected_graph.number_of_edges()
                )
                if not degree_exact or not edge_count_exact:
                    raise RuntimeError(
                        f"Integrity failure: {dataset}, seed={protection_seed}, variant={variant}"
                    )

                for feature_mode in FEATURE_MODES:
                    missing_for_mode = {
                        (dataset, protection_seed, variant, feature_mode, split_seed)
                        for split_seed in SPLIT_SEEDS
                    } - completed
                    if not missing_for_mode:
                        continue
                    embedding_seed = stable_seed(
                        dataset, protection_seed, variant, feature_mode, "gcn_gae"
                    )
                    embedding_lookup, embedding_meta = train_gcn_gae(
                        protected_graph, feature_mode, embedding_seed, device
                    )
                    embedding_records.append({
                        "dataset_name": dataset,
                        "protection_seed": protection_seed,
                        "variant": variant,
                        **embedding_meta,
                    })

                    for split_seed in SPLIT_SEEDS:
                        key = (dataset, protection_seed, variant, feature_mode, split_seed)
                        if key in completed:
                            continue
                        current = dataset_splits[
                            dataset_splits["split_seed"].astype(int).eq(split_seed)
                        ].copy()
                        train_frame = current[current["split"].eq("train")].copy()
                        test_frame = current[current["split"].eq("test")].copy()
                        if set(train_frame["edge_key"]) & set(test_frame["edge_key"]):
                            raise RuntimeError("Train/test edge overlap.")
                        x_train, y_train = pair_matrix(train_frame, embedding_lookup)
                        x_test, y_test = pair_matrix(test_frame, embedding_lookup)
                        model_seed = stable_seed(
                            dataset, protection_seed, variant, feature_mode, split_seed, "mlp"
                        )
                        balanced_x, balanced_y = balanced_resample(
                            x_train, y_train, model_seed
                        )
                        model = make_pipeline(
                            StandardScaler(),
                            MLPClassifier(
                                hidden_layer_sizes=(64, 32),
                                activation="relu",
                                solver="lbfgs",
                                alpha=1e-3,
                                max_iter=2000,
                                random_state=model_seed,
                            ),
                        )
                        fit_start = time.time()
                        with warnings.catch_warnings(record=True) as caught:
                            warnings.simplefilter("always", ConvergenceWarning)
                            model.fit(balanced_x, balanced_y)
                        predictions = model.predict(x_test)
                        warning_count = sum(
                            issubclass(item.category, ConvergenceWarning) for item in caught
                        )
                        new_rows.append({
                            "dataset_name": dataset,
                            "protection_seed": protection_seed,
                            "variant": variant,
                            "feature_mode": feature_mode,
                            "split_seed": split_seed,
                            "attack_model": "gcn_gae_mlp",
                            "n_train": int(len(y_train)),
                            "n_test": int(len(y_test)),
                            "n_classes": int(len(np.unique(y_train))),
                            "pair_feature_dimension": int(x_train.shape[1]),
                            "macro_f1": float(
                                f1_score(y_test, predictions, average="macro", zero_division=0)
                            ),
                            "balanced_accuracy": float(
                                balanced_accuracy_score(y_test, predictions)
                            ),
                            "accuracy": float(accuracy_score(y_test, predictions)),
                            "gcn_initial_loss": embedding_meta["initial_loss"],
                            "gcn_final_loss": embedding_meta["final_loss"],
                            "gcn_training_seconds": embedding_meta["training_seconds"],
                            "classifier_fit_seconds": float(time.time() - fit_start),
                            "convergence_warnings": int(warning_count),
                            "degree_preserved_exactly": degree_exact,
                            "edge_count_preserved_exactly": edge_count_exact,
                        })
                        completed.add(key)

                    if new_rows:
                        combined = pd.concat(
                            [results, pd.DataFrame(new_rows)], ignore_index=True
                        ) if len(results) else pd.DataFrame(new_rows)
                        combined = (
                            combined.drop_duplicates(KEY_COLUMNS, keep="last")
                            .sort_values(KEY_COLUMNS)
                            .reset_index(drop=True)
                        )
                        atomic_csv(combined, checkpoint_path)
                        results = combined
                        new_rows = []

    results = pd.read_csv(checkpoint_path)
    results = results.sort_values(KEY_COLUMNS).reset_index(drop=True)
    if len(results) != EXPECTED_ROWS:
        raise RuntimeError(f"Result row mismatch: {len(results)} != {EXPECTED_ROWS}")
    if int(results.duplicated(KEY_COLUMNS).sum()) != 0:
        raise RuntimeError("Duplicate result keys.")
    if not np.isfinite(results[METRICS].to_numpy(dtype=float)).all():
        raise RuntimeError("Non-finite metrics.")
    if not results["degree_preserved_exactly"].astype(int).eq(1).all():
        raise RuntimeError("Degree preservation failure.")
    if not results["edge_count_preserved_exactly"].astype(int).eq(1).all():
        raise RuntimeError("Edge-count preservation failure.")

    atomic_csv(results, final_results_path)
    summary = build_summary(results)
    tests = build_paired_tests(results)
    atomic_csv(summary, summary_path)
    atomic_csv(tests, paired_path)

    audit: dict[str, Any] = {
        "status": "PASS",
        "created_at_utc": stamp,
        "experiment": "GCN-GAE released-view relation-inference capacity check",
        "release_view_enforced": True,
        "released_attribute_mode": {
            "entity_type": True,
            "neighboring_protected_relation_distributions": True,
            "target_edge_relation_label_excluded": True,
            "raw_text": False,
            "original_labels": False,
            "sensitivity_flags_or_scores": False,
            "audit_metadata": False,
        },
        "release_view_schema": "TAFP_RELEASE_VIEW_V1",
        "scope": {
            "datasets": DATASETS,
            "protection_seeds": PROTECTION_SEEDS,
            "split_seeds": SPLIT_SEEDS,
            "variants": VARIANTS,
            "feature_modes": FEATURE_MODES,
            "expected_rows": EXPECTED_ROWS,
        },
        "repo_verification": repo_verification,
        "source_hashes": source_hashes,
        "raw_paths": {
            name: {"path": str(path), "sha256": sha256_file(path)}
            for name, path in raw_paths.items()
        },
        "split": {"path": str(split_path), "sha256": sha256_file(split_path)},
        "graph_split_validation": graph_validation,
        "device": str(device),
        "torch_version": torch.__version__,
        "hyperparameters": {
            "hidden_dim": GCN_HIDDEN_DIM,
            "output_dim": GCN_OUTPUT_DIM,
            "epochs": GCN_EPOCHS,
            "learning_rate": GCN_LEARNING_RATE,
            "weight_decay": GCN_WEIGHT_DECAY,
            "dropout": GCN_DROPOUT,
            "negative_ratio": NEGATIVE_RATIO,
            "classifier": "balanced MLP (64, 32), lbfgs, alpha=1e-3",
        },
        "result_checks": {
            "rows": len(results),
            "expected_rows": EXPECTED_ROWS,
            "duplicate_keys": int(results.duplicated(KEY_COLUMNS).sum()),
            "degree_failures": int((results["degree_preserved_exactly"] != 1).sum()),
            "edge_count_failures": int((results["edge_count_preserved_exactly"] != 1).sum()),
            "nonfinite_metric_rows": int(
                (~np.isfinite(results[METRICS].to_numpy(dtype=float))).any(axis=1).sum()
            ),
        },
        "outputs": {},
    }
    for path in [final_results_path, summary_path, paired_path]:
        audit["outputs"][path.name] = {
            "path": str(path),
            "size_bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    audit_path.write_text(json.dumps(audit, indent=2), encoding="utf-8")

    manifest_records = []
    for path in sorted(output_dir.rglob("*")):
        if path.is_file() and path.name not in {"EVIDENCE_MANIFEST.json"}:
            manifest_records.append({
                "path": str(path.relative_to(output_dir)),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    manifest_path = output_dir / "EVIDENCE_MANIFEST.json"
    manifest_path.write_text(json.dumps({"files": manifest_records}, indent=2), encoding="utf-8")

    bundle_path = output_dir.with_suffix(".zip")
    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(output_dir.rglob("*")):
            if path.is_file():
                archive.write(path, arcname=f"{output_dir.name}/{path.relative_to(output_dir)}")

    print("PASS: GCN-GAE released-attribute attacker capacity check completed")
    print("OUTPUT_DIR:", output_dir)
    print("RESULTS:", final_results_path)
    print("SUMMARY:", summary_path)
    print("PAIRED_TESTS:", paired_path)
    print("AUDIT:", audit_path)
    print("BUNDLE:", bundle_path)
    print("BUNDLE_SHA256:", sha256_file(bundle_path))
    print("ROWS:", len(results))
    print("DEVICE:", device)

    try:
        from google.colab import files
        files.download(str(bundle_path))
    except Exception:
        pass


if __name__ == "__main__":
    main()
