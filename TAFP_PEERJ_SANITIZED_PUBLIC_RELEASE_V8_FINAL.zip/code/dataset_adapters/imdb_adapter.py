import re
import random
from pathlib import Path

import pandas as pd
from datasets import load_dataset


SENTIMENT_LABELS = {
    0: "NEGATIVE",
    1: "POSITIVE"
}


THEME_KEYWORDS = {
    "ACTING": ["acting", "actor", "actress", "performance", "cast"],
    "PLOT": ["plot", "story", "script", "ending", "twist"],
    "DIRECTING": ["director", "directed", "direction"],
    "VISUALS": ["camera", "cinematography", "visual", "scene"],
    "SOUND": ["music", "soundtrack", "score"],
    "GENRE": ["horror", "comedy", "drama", "action", "romance", "thriller"],
    "SPOILER": ["spoiler", "ending", "dies", "death", "killer", "murder", "twist"]
}


def clean_token(value, max_len=60):
    value = str(value)
    value = re.sub(r"<br\s*/?>", " ", value, flags=re.IGNORECASE)
    value = re.sub(r"[^A-Za-z0-9_\- ]+", "", value)
    value = re.sub(r"\s+", "_", value.strip())
    return value[:max_len]


def clean_text(text, max_len=900):
    text = str(text)
    text = re.sub(r"<br\s*/?>", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_len]


def extract_entities(text, max_entities=8):
    """
    Lightweight entity-like phrase extraction from movie reviews.
    This is not full NER; it creates reproducible graph nodes.
    """
    text = str(text)

    quoted = re.findall(r'"([^"]{3,60})"', text)
    capitalized = re.findall(
        r"\b[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,2}\b",
        text
    )

    candidates = quoted + capitalized

    stop_phrases = {
        "The", "A", "An", "In", "On", "For", "To", "From", "By",
        "And", "But", "With", "After", "Before", "At", "As", "Of",
        "This", "That", "It", "Its", "He", "She", "They", "We",
        "I", "You", "Movie", "Film"
    }

    entities = []
    seen = set()

    for phrase in candidates:
        phrase = phrase.strip()

        if phrase in stop_phrases:
            continue

        if len(phrase) < 3:
            continue

        token = clean_token(phrase)

        if not token:
            continue

        if token not in seen:
            seen.add(token)
            entities.append(token)

        if len(entities) >= max_entities:
            break

    return entities


def detect_themes(text):
    low = str(text).lower()
    themes = []

    for theme, keywords in THEME_KEYWORDS.items():
        if any(k in low for k in keywords):
            themes.append(theme)

    return themes


def review_sensitivity(label, themes, rng):
    """
    IMDB has no direct PII. Sensitivity is modeled as opinion/context sensitivity.
    Negative sentiment and spoiler-like signals are treated as more sensitive.
    """
    base = 0.35

    if label == 0:
        base += 0.15

    if "SPOILER" in themes:
        base += 0.18

    if "PLOT" in themes:
        base += 0.05

    return round(max(0.05, min(0.95, base + rng.uniform(-0.08, 0.08))), 4)


def is_quasi_sensitive_relation(relation_type, label, themes, src_type=None, dst_type=None, rng=None):
    sensitive_relations = {"expresses_sentiment", "mentions", "has_theme", "co_mentions"}

    if relation_type == "expresses_sentiment":
        return 1

    if label == 0 and relation_type in sensitive_relations:
        return 1

    if "SPOILER" in themes and relation_type in sensitive_relations:
        return 1

    if rng is not None and rng.random() < 0.12:
        return 1

    return 0


def load_imdb_split():
    return load_dataset("stanfordnlp/imdb", split="train")


def generate_imdb_graph(
    out_dir="data",
    num_docs=500,
    max_entities_per_doc=8,
    seed=42
):
    rng = random.Random(seed)

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    ds = load_imdb_split()

    indices = list(range(len(ds)))
    rng.shuffle(indices)
    indices = indices[:num_docs]

    nodes = []
    edges = []

    seen_nodes = set()
    seen_edges = set()

    def add_node(node):
        node_id = node["id"]
        if node_id not in seen_nodes:
            seen_nodes.add(node_id)
            nodes.append(node)

    def add_edge(source, target, relation_type, sensitive=0, weight=1.0):
        if source == target:
            return

        key = (source, target, relation_type)

        if key in seen_edges:
            return

        seen_edges.add(key)

        edges.append({
            "source": source,
            "target": target,
            "relation_type": relation_type,
            "sensitive": int(sensitive),
            "weight": round(float(weight), 4)
        })

    for idx in indices:
        item = ds[idx]

        text = clean_text(item["text"])
        label = int(item["label"])
        sentiment = SENTIMENT_LABELS[label]

        review_id = f"REVIEW_IMDB_{idx}"
        sentiment_id = f"SENTIMENT_{sentiment}"

        themes = detect_themes(text)
        sens = review_sensitivity(label, themes, rng)

        add_node({
            "id": review_id,
            "entity_type": "REVIEW",
            "pii": 0,
            "semantic_sensitivity": sens,
            "text": text
        })

        add_node({
            "id": sentiment_id,
            "entity_type": "SENTIMENT",
            "pii": 0,
            "semantic_sensitivity": 0.55 if sentiment == "NEGATIVE" else 0.35,
            "text": f"IMDB sentiment label: {sentiment}"
        })

        add_edge(
            source=review_id,
            target=sentiment_id,
            relation_type="expresses_sentiment",
            sensitive=is_quasi_sensitive_relation(
                "expresses_sentiment",
                label,
                themes,
                src_type="REVIEW",
                dst_type="SENTIMENT",
                rng=rng
            ),
            weight=1.0
        )

        for theme in themes:
            theme_id = f"THEME_{theme}"

            add_node({
                "id": theme_id,
                "entity_type": "THEME",
                "pii": 0,
                "semantic_sensitivity": 0.65 if theme == "SPOILER" else 0.40,
                "text": f"IMDB review theme: {theme}"
            })

            add_edge(
                source=review_id,
                target=theme_id,
                relation_type="has_theme",
                sensitive=is_quasi_sensitive_relation(
                    "has_theme",
                    label,
                    themes,
                    src_type="REVIEW",
                    dst_type="THEME",
                    rng=rng
                ),
                weight=rng.uniform(0.40, 1.0)
            )

        entities = extract_entities(text, max_entities=max_entities_per_doc)
        entity_ids = []

        for ent in entities:
            ent_id = f"ENTITY_IMDB_{clean_token(ent)}"
            entity_ids.append(ent_id)

            add_node({
                "id": ent_id,
                "entity_type": "ENTITY",
                "pii": 0,
                "semantic_sensitivity": round(
                    max(0.05, min(0.85, sens + rng.uniform(-0.12, 0.12))),
                    4
                ),
                "text": f"Entity-like movie review mention extracted from IMDB: {ent}"
            })

            add_edge(
                source=review_id,
                target=ent_id,
                relation_type="mentions",
                sensitive=is_quasi_sensitive_relation(
                    "mentions",
                    label,
                    themes,
                    src_type="REVIEW",
                    dst_type="ENTITY",
                    rng=rng
                ),
                weight=rng.uniform(0.40, 1.0)
            )

        for a, b in zip(entity_ids, entity_ids[1:]):
            add_edge(
                source=a,
                target=b,
                relation_type="co_mentions",
                sensitive=is_quasi_sensitive_relation(
                    "co_mentions",
                    label,
                    themes,
                    src_type="ENTITY",
                    dst_type="ENTITY",
                    rng=rng
                ),
                weight=rng.uniform(0.20, 0.70)
            )

    node_df = pd.DataFrame(nodes)
    edge_df = pd.DataFrame(edges)

    node_path = out_dir / "imdb_nodes.csv"
    edge_path = out_dir / "imdb_edges.csv"

    node_df.to_csv(node_path, index=False)
    edge_df.to_csv(edge_path, index=False)

    print("DONE: IMDB graph generated")
    print("Nodes:", node_path, len(node_df))
    print("Edges:", edge_path, len(edge_df))

    print("\nNode type counts:")
    print(node_df["entity_type"].value_counts())

    print("\nPII counts:")
    print(node_df["pii"].value_counts())

    print("\nRelation type counts:")
    print(edge_df["relation_type"].value_counts())

    print("\nSensitive edge counts:")
    print(edge_df["sensitive"].value_counts())

    print("\nSensitive by relation:")
    print(pd.crosstab(edge_df["relation_type"], edge_df["sensitive"]))

    return node_path, edge_path


if __name__ == "__main__":
    generate_imdb_graph(
        out_dir="data",
        num_docs=500,
        max_entities_per_doc=8,
        seed=42
    )
