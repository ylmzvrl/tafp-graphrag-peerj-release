import random
from pathlib import Path
import pandas as pd


ENTITY_TYPES = [
    "PERSON",
    "EMAIL",
    "MEDICAL_ID",
    "ORG",
    "PROJECT",
    "LOCATION",
    "DOCUMENT"
]

RELATIONS = [
    "works_on",
    "collaborates_with",
    "reports_to",
    "mentions",
    "located_in",
    "accesses",
    "owns",
    "treats",
    "assigned_to"
]


def make_node(i, rng):
    etype = rng.choices(
        ENTITY_TYPES,
        weights=[0.20, 0.16, 0.14, 0.16, 0.12, 0.10, 0.12],
        k=1
    )[0]

    node_id = f"{etype}_{i}"

    pii = 1 if etype in ["PERSON", "EMAIL", "MEDICAL_ID"] else 0

    base_sensitivity = {
        "PERSON": 0.85,
        "EMAIL": 0.90,
        "MEDICAL_ID": 0.95,
        "ORG": 0.35,
        "PROJECT": 0.45,
        "LOCATION": 0.40,
        "DOCUMENT": 0.55
    }[etype]

    sensitivity = min(
        0.99,
        max(0.05, base_sensitivity + rng.uniform(-0.12, 0.12))
    )

    if etype == "PERSON":
        text = (
            f"Synthetic person record person_{i} with employee profile, "
            f"department assignment, project membership, and contact reference."
        )
    elif etype == "EMAIL":
        text = (
            f"Synthetic email account user{i}@example.org connected to "
            f"internal communication, project updates, and identity references."
        )
    elif etype == "MEDICAL_ID":
        text = (
            f"Synthetic medical identifier MID-{100000+i} linked to "
            f"clinical document access, treatment notes, and patient workflow."
        )
    elif etype == "ORG":
        text = (
            f"Synthetic organization unit org_{i} with collaboration links, "
            f"project ownership, and operational records."
        )
    elif etype == "PROJECT":
        text = (
            f"Synthetic project project_{i} involving teams, documents, "
            f"assignments, and cross-organization collaboration."
        )
    elif etype == "LOCATION":
        text = (
            f"Synthetic location site_{i} associated with organizations, "
            f"documents, access records, and operational activity."
        )
    else:
        text = (
            f"Synthetic document doc_{i} containing references to projects, "
            f"organizations, contact records, and sensitive workflow notes."
        )

    return {
        "id": node_id,
        "entity_type": etype,
        "pii": pii,
        "semantic_sensitivity": round(sensitivity, 4),
        "text": text
    }


def relation_is_sensitive(rel, src_type, dst_type):
    if src_type in ["PERSON", "EMAIL", "MEDICAL_ID"]:
        return 1
    if dst_type in ["PERSON", "EMAIL", "MEDICAL_ID"]:
        return 1
    if rel in ["treats", "accesses", "owns"]:
        return 1
    return 0


def generate_synthpii_graph(
    out_dir="data",
    num_nodes=800,
    num_edges=2400,
    seed=42
):
    rng = random.Random(seed)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    nodes = [make_node(i, rng) for i in range(num_nodes)]
    node_df = pd.DataFrame(nodes)

    id_to_type = dict(zip(node_df["id"], node_df["entity_type"]))
    node_ids = list(node_df["id"])

    edges = []
    seen = set()

    # Structured edges: PII-heavy nodes connect to documents/projects/orgs
    pii_nodes = node_df[node_df["pii"] == 1]["id"].tolist()
    non_pii_nodes = node_df[node_df["pii"] == 0]["id"].tolist()

    while len(edges) < num_edges:
        if rng.random() < 0.60 and pii_nodes and non_pii_nodes:
            src = rng.choice(pii_nodes)
            dst = rng.choice(non_pii_nodes)
        else:
            src, dst = rng.sample(node_ids, 2)

        if src == dst:
            continue

        key = tuple(sorted((src, dst)))
        if key in seen:
            continue

        seen.add(key)

        rel = rng.choice(RELATIONS)
        src_type = id_to_type[src]
        dst_type = id_to_type[dst]

        sensitive = relation_is_sensitive(rel, src_type, dst_type)

        weight = round(rng.uniform(0.25, 1.0), 4)

        edges.append({
            "source": src,
            "target": dst,
            "relation_type": rel,
            "sensitive": sensitive,
            "weight": weight
        })

    edge_df = pd.DataFrame(edges)

    node_path = out_dir / "synthpii_nodes.csv"
    edge_path = out_dir / "synthpii_edges.csv"

    node_df.to_csv(node_path, index=False)
    edge_df.to_csv(edge_path, index=False)

    print("DONE: SynthPII graph generated")
    print("Nodes:", node_path, len(node_df))
    print("Edges:", edge_path, len(edge_df))
    print("\nNode type counts:")
    print(node_df["entity_type"].value_counts())
    print("\nPII counts:")
    print(node_df["pii"].value_counts())

    return node_path, edge_path


if __name__ == "__main__":
    generate_synthpii_graph()
