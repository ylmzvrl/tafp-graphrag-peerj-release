import re
import random
from pathlib import Path

import pandas as pd
from datasets import load_dataset


DISEASE_TERMS = [
    "cancer", "tumor", "diabetes", "obesity", "depression", "anxiety",
    "infection", "inflammation", "hypertension", "stroke", "asthma",
    "arthritis", "alzheimer", "parkinson", "covid", "hiv", "aids",
    "hepatitis", "cardiovascular", "renal", "kidney", "liver",
    "pneumonia", "sepsis", "dementia", "epilepsy"
]

TREATMENT_TERMS = [
    "therapy", "treatment", "drug", "dose", "chemotherapy", "radiotherapy",
    "surgery", "intervention", "vaccine", "antibiotic", "antiviral",
    "inhibitor", "metformin", "insulin", "statin", "aspirin",
    "placebo", "clinical trial", "randomized", "trial"
]

METHOD_TERMS = [
    "cohort", "case-control", "meta-analysis", "systematic review",
    "regression", "survival analysis", "hazard ratio", "odds ratio",
    "confidence interval", "p value", "randomized controlled trial",
    "double blind", "prospective", "retrospective"
]

BIOMARKER_TERMS = [
    "protein", "gene", "expression", "biomarker", "mutation", "variant",
    "receptor", "enzyme", "cytokine", "interleukin", "antibody",
    "genomic", "rna", "dna", "serum", "plasma"
]


def clean_text(text, max_len=1000):
    text = str(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:max_len]


def clean_token(value, max_len=70):
    value = str(value)
    value = re.sub(r"[^A-Za-z0-9_\- ]+", "", value)
    value = re.sub(r"\s+", "_", value.strip())
    return value[:max_len]


def find_terms(text, terms):
    low = str(text).lower()
    found = []

    for t in terms:
        if t in low:
            found.append(clean_token(t.upper()))

    return found


def extract_capitalized_biomedical_phrases(text, max_items=8):
    text = str(text)

    candidates = re.findall(
        r"\b[A-Z][A-Za-z0-9\-]+(?:\s+[A-Z][A-Za-z0-9\-]+){0,3}\b",
        text
    )

    stop = {
        "The", "This", "These", "Those", "In", "On", "For", "With",
        "From", "By", "Of", "And", "Methods", "Results", "Conclusion",
        "Background", "Objective", "Objectives", "Study", "Patients"
    }

    out = []
    seen = set()

    for c in candidates:
        c = c.strip()

        if c in stop:
            continue

        if len(c) < 4:
            continue

        token = clean_token(c)

        if token not in seen:
            seen.add(token)
            out.append(token)

        if len(out) >= max_items:
            break

    return out


def concept_sensitivity(concept_type, rng):
    base = {
        "DISEASE": 0.80,
        "TREATMENT": 0.72,
        "BIOMARKER": 0.62,
        "METHOD": 0.42,
        "ENTITY": 0.50,
        "ABSTRACT": 0.58,
        "PAPER": 0.45
    }.get(concept_type, 0.40)

    return round(max(0.05, min(0.95, base + rng.uniform(-0.08, 0.08))), 4)


def relation_sensitive(relation_type, src_type=None, dst_type=None, rng=None):
    sensitive_relations = {
        "mentions_disease",
        "mentions_treatment",
        "mentions_biomarker",
        "abstract_summarizes",
        "co_mentions_medical",
        "disease_treatment_context"
    }

    if relation_type in sensitive_relations:
        return 1

    if src_type in {"DISEASE", "TREATMENT", "BIOMARKER"}:
        return 1

    if dst_type in {"DISEASE", "TREATMENT", "BIOMARKER"}:
        return 1

    if rng is not None and rng.random() < 0.10:
        return 1

    return 0


def load_pubmed_stream(seed):
    ds = load_dataset(
        "ccdv/pubmed-summarization",
        split="train",
        streaming=True
    )

    try:
        ds = ds.shuffle(buffer_size=2000, seed=seed)
    except Exception:
        pass

    return ds


def generate_pubmed_graph(
    out_dir="data",
    num_docs=500,
    max_concepts_per_doc=10,
    seed=42
):
    rng = random.Random(seed)

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    ds = load_pubmed_stream(seed)

    nodes = []
    edges = []

    seen_nodes = set()
    seen_edges = set()

    def add_node(node):
        node_id = node["id"]
        if node_id not in seen_nodes:
            seen_nodes.add(node_id)
            nodes.append(node)

    def add_edge(source, target, relation_type, sensitive=0, weight=1.0):
        if source == target:
            return

        key = (source, target, relation_type)

        if key in seen_edges:
            return

        seen_edges.add(key)

        edges.append({
            "source": source,
            "target": target,
            "relation_type": relation_type,
            "sensitive": int(sensitive),
            "weight": round(float(weight), 4)
        })

    count = 0

    for item in ds:
        if count >= num_docs:
            break

        raw_id = str(item.get("id", count))
        article = clean_text(item.get("article", ""), max_len=1000)
        abstract = clean_text(item.get("abstract", ""), max_len=700)

        if len(article) < 100 or len(abstract) < 40:
            continue

        paper_id = f"PAPER_PUBMED_{clean_token(raw_id, 40)}"
        abstract_id = f"ABSTRACT_PUBMED_{clean_token(raw_id, 40)}"

        combined = article + " " + abstract

        disease_terms = find_terms(combined, DISEASE_TERMS)
        treatment_terms = find_terms(combined, TREATMENT_TERMS)
        method_terms = find_terms(combined, METHOD_TERMS)
        biomarker_terms = find_terms(combined, BIOMARKER_TERMS)
        phrase_terms = extract_capitalized_biomedical_phrases(combined, max_items=6)

        concepts = []

        for t in disease_terms:
            concepts.append(("DISEASE", f"DISEASE_{t}", t))

        for t in treatment_terms:
            concepts.append(("TREATMENT", f"TREATMENT_{t}", t))

        for t in method_terms:
            concepts.append(("METHOD", f"METHOD_{t}", t))

        for t in biomarker_terms:
            concepts.append(("BIOMARKER", f"BIOMARKER_{t}", t))

        for t in phrase_terms:
            concepts.append(("ENTITY", f"ENTITY_PUBMED_{t}", t))

        # dedupe while preserving order
        deduped = []
        seen_concepts = set()

        for c in concepts:
            if c[1] not in seen_concepts:
                seen_concepts.add(c[1])
                deduped.append(c)

        concepts = deduped[:max_concepts_per_doc]

        add_node({
            "id": paper_id,
            "entity_type": "PAPER",
            "pii": 0,
            "semantic_sensitivity": concept_sensitivity("PAPER", rng),
            "text": article
        })

        add_node({
            "id": abstract_id,
            "entity_type": "ABSTRACT",
            "pii": 0,
            "semantic_sensitivity": concept_sensitivity("ABSTRACT", rng),
            "text": abstract
        })

        add_edge(
            source=paper_id,
            target=abstract_id,
            relation_type="abstract_summarizes",
            sensitive=relation_sensitive(
                "abstract_summarizes",
                src_type="PAPER",
                dst_type="ABSTRACT",
                rng=rng
            ),
            weight=1.0
        )

        concept_ids = []

        for ctype, cid, label in concepts:
            concept_ids.append((cid, ctype))

            add_node({
                "id": cid,
                "entity_type": ctype,
                "pii": 0,
                "semantic_sensitivity": concept_sensitivity(ctype, rng),
                "text": f"PubMed biomedical concept: {label}"
            })

            if ctype == "DISEASE":
                rel = "mentions_disease"
            elif ctype == "TREATMENT":
                rel = "mentions_treatment"
            elif ctype == "BIOMARKER":
                rel = "mentions_biomarker"
            elif ctype == "METHOD":
                rel = "mentions_method"
            else:
                rel = "mentions_entity"

            add_edge(
                source=paper_id,
                target=cid,
                relation_type=rel,
                sensitive=relation_sensitive(
                    rel,
                    src_type="PAPER",
                    dst_type=ctype,
                    rng=rng
                ),
                weight=rng.uniform(0.35, 1.0)
            )

            add_edge(
                source=abstract_id,
                target=cid,
                relation_type=rel,
                sensitive=relation_sensitive(
                    rel,
                    src_type="ABSTRACT",
                    dst_type=ctype,
                    rng=rng
                ),
                weight=rng.uniform(0.35, 1.0)
            )

        # disease-treatment contextual links
        diseases = [cid for cid, ctype in concept_ids if ctype == "DISEASE"]
        treatments = [cid for cid, ctype in concept_ids if ctype == "TREATMENT"]

        for d in diseases[:3]:
            for t in treatments[:3]:
                add_edge(
                    source=d,
                    target=t,
                    relation_type="disease_treatment_context",
                    sensitive=1,
                    weight=rng.uniform(0.40, 0.90)
                )

        # local concept co-mention chain
        for (a, atype), (b, btype) in zip(concept_ids, concept_ids[1:]):
            add_edge(
                source=a,
                target=b,
                relation_type="co_mentions_medical",
                sensitive=relation_sensitive(
                    "co_mentions_medical",
                    src_type=atype,
                    dst_type=btype,
                    rng=rng
                ),
                weight=rng.uniform(0.20, 0.75)
            )

        count += 1

    node_df = pd.DataFrame(nodes)
    edge_df = pd.DataFrame(edges)

    node_path = out_dir / "pubmed_nodes.csv"
    edge_path = out_dir / "pubmed_edges.csv"

    node_df.to_csv(node_path, index=False)
    edge_df.to_csv(edge_path, index=False)

    print("DONE: PubMed graph generated")
    print("Nodes:", node_path, len(node_df))
    print("Edges:", edge_path, len(edge_df))

    print("\nNode type counts:")
    print(node_df["entity_type"].value_counts())

    print("\nPII counts:")
    print(node_df["pii"].value_counts())

    print("\nRelation type counts:")
    print(edge_df["relation_type"].value_counts())

    print("\nSensitive edge counts:")
    print(edge_df["sensitive"].value_counts())

    print("\nSensitive by relation:")
    print(pd.crosstab(edge_df["relation_type"], edge_df["sensitive"]))

    return node_path, edge_path


if __name__ == "__main__":
    generate_pubmed_graph(
        out_dir="data",
        num_docs=500,
        max_concepts_per_doc=10,
        seed=42
    )
