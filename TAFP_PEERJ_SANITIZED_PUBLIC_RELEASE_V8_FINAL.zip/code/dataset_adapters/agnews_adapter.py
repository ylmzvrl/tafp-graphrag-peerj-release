import re
import random
from pathlib import Path

import pandas as pd
from datasets import load_dataset


TOPIC_LABELS = {
    0: "World",
    1: "Sports",
    2: "Business",
    3: "SciTech"
}


RELATION_TYPES = [
    "mentions",
    "has_topic",
    "co_mentions",
    "topic_contains",
    "related_to"
]


def clean_token(value, max_len=60):
    value = str(value)
    value = re.sub(r"[^A-Za-z0-9_\- ]+", "", value)
    value = re.sub(r"\s+", "_", value.strip())
    return value[:max_len]


def extract_entities(text, max_entities=8):
    """
    Lightweight transparent entity-like phrase extraction.
    This is not full NER; it creates reproducible graph nodes from news text.
    """
    phrases = re.findall(
        r"\b[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,2}\b",
        str(text)
    )

    stop_phrases = {
        "The", "A", "An", "In", "On", "For", "To", "From", "By",
        "And", "But", "With", "After", "Before", "At", "As", "Of",
        "This", "That", "It", "Its", "He", "She", "They", "We"
    }

    entities = []
    seen = set()

    for phrase in phrases:
        phrase = phrase.strip()

        if phrase in stop_phrases:
            continue

        if len(phrase) < 3:
            continue

        token = clean_token(phrase)

        if not token:
            continue

        if token not in seen:
            seen.add(token)
            entities.append(token)

        if len(entities) >= max_entities:
            break

    return entities


def infer_entity_type(entity_name):
    lower = entity_name.lower()

    org_keywords = [
        "inc", "corp", "company", "bank", "group", "agency",
        "microsoft", "google", "apple", "ibm", "nasa", "reuters"
    ]

    location_keywords = [
        "city", "state", "iraq", "china", "europe", "asia",
        "america", "washington", "london", "paris", "tokyo",
        "california", "russia", "india", "africa"
    ]

    if any(k in lower for k in org_keywords):
        return "ORG"

    if any(k in lower for k in location_keywords):
        return "LOCATION"

    return "ENTITY"


def sensitivity_for_topic(topic):
    """
    AG News is public news, so PII is not the main signal.
    Sensitivity is topic/context-based rather than personal-identity-based.
    """
    if topic == "Business":
        return 0.45
    if topic == "World":
        return 0.40
    if topic == "SciTech":
        return 0.35
    if topic == "Sports":
        return 0.25
    return 0.30


def load_agnews_split():
    """
    Namespaced dataset id avoids the previous ag_news URI issue.
    """
    try:
        return load_dataset("fancyzhx/ag_news", split="train")
    except Exception as e:
        print("ERROR: Could not load fancyzhx/ag_news from HuggingFace.")
        print("Original error:", repr(e))
        print("If this persists, we will use HF login or direct parquet/CSV download.")
        raise



def is_quasi_sensitive_relation(relation_type, topic, src_type=None, dst_type=None, rng=None):
    """
    AG News has no direct PII, so we model public-domain quasi-sensitive
    relations based on topic and relation structure.
    """
    high_context_topics = {"World", "Business"}
    sensitive_relation_types = {"mentions", "topic_contains", "co_mentions"}

    if topic in high_context_topics and relation_type in sensitive_relation_types:
        return 1

    if src_type in {"ORG", "LOCATION"} or dst_type in {"ORG", "LOCATION"}:
        if relation_type in {"mentions", "co_mentions", "topic_contains"}:
            return 1

    if rng is not None and rng.random() < 0.15:
        return 1

    return 0

def generate_agnews_graph(
    out_dir="data",
    num_docs=500,
    max_entities_per_doc=8,
    seed=42
):
    rng = random.Random(seed)

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    ds = load_agnews_split()

    indices = list(range(len(ds)))
    rng.shuffle(indices)
    indices = indices[:num_docs]

    nodes = []
    edges = []

    seen_nodes = set()
    seen_edges = set()

    def add_node(node):
        node_id = node["id"]
        if node_id not in seen_nodes:
            seen_nodes.add(node_id)
            nodes.append(node)

    def add_edge(source, target, relation_type, sensitive=0, weight=1.0):
        if source == target:
            return

        key = (source, target, relation_type)

        if key in seen_edges:
            return

        seen_edges.add(key)

        edges.append({
            "source": source,
            "target": target,
            "relation_type": relation_type,
            "sensitive": int(sensitive),
            "weight": round(float(weight), 4)
        })

    for idx in indices:
        item = ds[idx]

        text = str(item["text"])
        label = int(item["label"])
        topic = TOPIC_LABELS.get(label, "Unknown")

        topic_sens = sensitivity_for_topic(topic)

        doc_id = f"DOCUMENT_AGNEWS_{idx}"
        topic_id = f"TOPIC_{clean_token(topic)}"

        add_node({
            "id": doc_id,
            "entity_type": "DOCUMENT",
            "pii": 0,
            "semantic_sensitivity": round(topic_sens + rng.uniform(0.05, 0.15), 4),
            "text": text[:800]
        })

        add_node({
            "id": topic_id,
            "entity_type": "TOPIC",
            "pii": 0,
            "semantic_sensitivity": round(topic_sens, 4),
            "text": f"AG News topic category: {topic}"
        })

        add_edge(
            source=doc_id,
            target=topic_id,
            relation_type="has_topic",
            sensitive=0,
            weight=1.0
        )

        entities = extract_entities(
            text,
            max_entities=max_entities_per_doc
        )

        entity_ids = []

        for ent in entities:
            ent_id = f"ENTITY_AGNEWS_{clean_token(ent)}"
            entity_ids.append(ent_id)

            etype = infer_entity_type(ent)

            add_node({
                "id": ent_id,
                "entity_type": etype,
                "pii": 0,
                "semantic_sensitivity": round(
                    max(0.05, min(0.85, topic_sens + rng.uniform(-0.10, 0.10))),
                    4
                ),
                "text": f"Entity-like mention extracted from AG News: {ent}"
            })

            add_edge(
                source=doc_id,
                target=ent_id,
                relation_type="mentions",
                sensitive=is_quasi_sensitive_relation(
                    "mentions",
                    topic,
                    src_type="DOCUMENT",
                    dst_type=etype,
                    rng=rng
                ),
                weight=rng.uniform(0.40, 1.0)
            )

            if rng.random() < 0.35:
                add_edge(
                    source=topic_id,
                    target=ent_id,
                    relation_type="topic_contains",
                    sensitive=is_quasi_sensitive_relation(
                        "topic_contains",
                        topic,
                        src_type="TOPIC",
                        dst_type=etype,
                        rng=rng
                    ),
                    weight=rng.uniform(0.25, 0.85)
                )

        # Co-mention graph edges inside the same article
        for a, b in zip(entity_ids, entity_ids[1:]):
            add_edge(
                source=a,
                target=b,
                relation_type="co_mentions",
                sensitive=is_quasi_sensitive_relation(
                    "co_mentions",
                    topic,
                    src_type="ENTITY",
                    dst_type="ENTITY",
                    rng=rng
                ),
                weight=rng.uniform(0.20, 0.70)
            )

    node_df = pd.DataFrame(nodes)
    edge_df = pd.DataFrame(edges)

    node_path = out_dir / "agnews_nodes.csv"
    edge_path = out_dir / "agnews_edges.csv"

    node_df.to_csv(node_path, index=False)
    edge_df.to_csv(edge_path, index=False)

    print("DONE: AG News graph generated")
    print("Nodes:", node_path, len(node_df))
    print("Edges:", edge_path, len(edge_df))

    print("\nNode type counts:")
    print(node_df["entity_type"].value_counts())

    print("\nPII counts:")
    print(node_df["pii"].value_counts())

    print("\nRelation type counts:")
    print(edge_df["relation_type"].value_counts())

    return node_path, edge_path


if __name__ == "__main__":
    generate_agnews_graph(
        out_dir="data",
        num_docs=500,
        max_entities_per_doc=8,
        seed=42
    )
