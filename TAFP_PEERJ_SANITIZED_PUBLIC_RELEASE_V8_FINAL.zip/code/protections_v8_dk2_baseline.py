from collections import Counter
import random

import protections_v8_baselines as baseline


def joint_degree_counter(graph, degrees=None):
    if degrees is None:
        degrees = dict(graph.degree())

    return Counter(
        tuple(
            sorted(
                (
                    degrees[source],
                    degrees[target],
                )
            )
        )
        for source, target in graph.edges()
    )


def _dk2_swap_selected_edges(
    graph,
    selected_edges,
    target_edges,
    seed,
    make_private=False,
):
    """
    Restricted double-edge swaps.

    Two original edges are oriented as:
        (anchor_1, other_1)
        (anchor_2, other_2)

    A swap is allowed only when:
        degree(anchor_1) == degree(anchor_2)

    The replacement is:
        (anchor_1, other_2)
        (anchor_2, other_1)

    This preserves:
    - every node degree;
    - the undirected joint-degree edge-count matrix.
    """

    rng = random.Random(seed)
    reference_degrees = dict(graph.degree())

    available = [
        (
            source,
            target,
            dict(graph.edges[source, target]),
        )
        for source, target in selected_edges
        if graph.has_edge(source, target)
    ]

    target_edges = min(
        int(target_edges),
        len(available),
    )

    if target_edges % 2:
        target_edges -= 1

    rewired_edges = 0
    successful_swaps = 0
    attempts = 0
    max_attempts = max(
        10000,
        target_edges * 1000,
    )

    while (
        rewired_edges < target_edges
        and len(available) >= 2
        and attempts < max_attempts
    ):
        attempts += 1

        first_index, second_index = rng.sample(
            range(len(available)),
            2,
        )

        source_1, target_1, attributes_1 = (
            available[first_index]
        )

        source_2, target_2, attributes_2 = (
            available[second_index]
        )

        if (
            not graph.has_edge(
                source_1,
                target_1,
            )
            or not graph.has_edge(
                source_2,
                target_2,
            )
        ):
            for index in sorted(
                (
                    first_index,
                    second_index,
                ),
                reverse=True,
            ):
                available.pop(index)

            continue

        if len(
            {
                source_1,
                target_1,
                source_2,
                target_2,
            }
        ) != 4:
            continue

        orientations_1 = [
            (source_1, target_1),
            (target_1, source_1),
        ]

        orientations_2 = [
            (source_2, target_2),
            (target_2, source_2),
        ]

        proposals = []

        for anchor_1, other_1 in orientations_1:
            for anchor_2, other_2 in orientations_2:
                if (
                    reference_degrees[anchor_1]
                    != reference_degrees[anchor_2]
                ):
                    continue

                proposals.append(
                    (
                        (anchor_1, other_2),
                        (anchor_2, other_1),
                    )
                )

        rng.shuffle(proposals)

        chosen = None

        for new_edge_1, new_edge_2 in proposals:
            new_source_1, new_target_1 = new_edge_1
            new_source_2, new_target_2 = new_edge_2

            if (
                new_source_1 == new_target_1
                or new_source_2 == new_target_2
            ):
                continue

            if (
                frozenset(new_edge_1)
                == frozenset(new_edge_2)
            ):
                continue

            if (
                graph.has_edge(
                    new_source_1,
                    new_target_1,
                )
                or graph.has_edge(
                    new_source_2,
                    new_target_2,
                )
            ):
                continue

            chosen = (
                new_edge_1,
                new_edge_2,
            )
            break

        if chosen is None:
            continue

        new_edge_1, new_edge_2 = chosen

        graph.remove_edge(
            source_1,
            target_1,
        )
        graph.remove_edge(
            source_2,
            target_2,
        )

        if make_private:
            attributes_1 = baseline._private_attrs(
                attributes_1
            )

            attributes_2 = baseline._private_attrs(
                attributes_2
            )

        graph.add_edge(
            *new_edge_1,
            **attributes_1,
        )

        graph.add_edge(
            *new_edge_2,
            **attributes_2,
        )

        for index in sorted(
            (
                first_index,
                second_index,
            ),
            reverse=True,
        ):
            available.pop(index)

        rewired_edges += 2
        successful_swaps += 1

    return {
        "target_edges": target_edges,
        "rewired_edges": rewired_edges,
        "successful_swaps": successful_swaps,
        "attempts": attempts,
        "target_reached": int(
            rewired_edges == target_edges
        ),
    }


def _dk2_random_relation_budget(
    graph,
    config,
):
    seed = int(config.get("seed", 42))

    rng = random.Random(seed + 401)

    rate = baseline._rate(
        config,
        "relation_remove_rate",
        0.12,
    )

    sensitive_count = sum(
        baseline.core._v7_edge_sensitive(
            attributes
        )
        for _, _, attributes
        in graph.edges(data=True)
    )

    all_edges = list(graph.edges())

    selected_count = min(
        sensitive_count,
        len(all_edges),
    )

    selected_edges = (
        rng.sample(
            all_edges,
            selected_count,
        )
        if selected_count
        else []
    )

    for source, target in selected_edges:
        graph.edges[
            source,
            target,
        ]["protected_relation_type"] = (
            "PRIVATE_RELATION"
        )

    target_edges = baseline._even_target(
        selected_count,
        rate,
    )

    before_jdd = joint_degree_counter(graph)

    result = _dk2_swap_selected_edges(
        graph=graph,
        selected_edges=selected_edges,
        target_edges=target_edges,
        seed=seed + 402,
        make_private=True,
    )

    after_jdd = joint_degree_counter(graph)

    audit = graph.graph.setdefault(
        "protection_audit",
        {},
    )

    audit[
        "dk2_relation_selected_edges"
    ] = selected_count

    audit[
        "dk2_relation_target_edges"
    ] = result["target_edges"]

    audit[
        "dk2_relation_rewired_edges"
    ] = result["rewired_edges"]

    audit[
        "dk2_relation_successful_swaps"
    ] = result["successful_swaps"]

    audit[
        "dk2_relation_attempts"
    ] = result["attempts"]

    audit[
        "dk2_relation_target_reached"
    ] = result["target_reached"]

    audit[
        "dk2_relation_jdd_preserved"
    ] = int(before_jdd == after_jdd)


def _dk2_topology_budget(
    graph,
    config,
):
    seed = int(config.get("seed", 42))

    rate = baseline._rate(
        config,
        "topology_rewire_rate",
        0.08,
    )

    selected_edges = list(graph.edges())

    target_edges = baseline._even_target(
        len(selected_edges),
        rate,
    )

    before_jdd = joint_degree_counter(graph)

    result = _dk2_swap_selected_edges(
        graph=graph,
        selected_edges=selected_edges,
        target_edges=target_edges,
        seed=seed + 202,
        make_private=False,
    )

    after_jdd = joint_degree_counter(graph)

    audit = graph.graph.setdefault(
        "protection_audit",
        {},
    )

    audit[
        "dk2_topology_candidate_edges"
    ] = len(selected_edges)

    audit[
        "dk2_topology_target_edges"
    ] = result["target_edges"]

    audit[
        "dk2_topology_rewired_edges"
    ] = result["rewired_edges"]

    audit[
        "dk2_topology_successful_swaps"
    ] = result["successful_swaps"]

    audit[
        "dk2_topology_attempts"
    ] = result["attempts"]

    audit[
        "dk2_topology_target_reached"
    ] = result["target_reached"]

    audit[
        "dk2_topology_jdd_preserved"
    ] = int(before_jdd == after_jdd)


def apply_variant(
    graph_base,
    risks,
    variant,
    config,
):
    if variant != "dk2_full_budget":
        return baseline.apply_variant(
            graph_base,
            risks,
            variant,
            config,
        )

    graph = graph_base.copy()
    graph.graph["protection_audit"] = {}

    base_degrees = dict(
        graph_base.degree()
    )

    base_jdd = joint_degree_counter(
        graph_base,
        base_degrees,
    )

    baseline._random_entity_budget(
        graph,
        config,
    )

    _dk2_random_relation_budget(
        graph,
        config,
    )

    _dk2_topology_budget(
        graph,
        config,
    )

    protected_degrees = dict(
        graph.degree()
    )

    changed_degree_nodes = sum(
        base_degrees[node]
        != protected_degrees[node]
        for node in graph_base.nodes()
    )

    final_jdd = joint_degree_counter(
        graph,
        base_degrees,
    )

    audit = graph.graph[
        "protection_audit"
    ]

    audit["degree_changed_nodes"] = (
        changed_degree_nodes
    )

    audit["degree_preserved_exactly"] = int(
        changed_degree_nodes == 0
    )

    audit[
        "joint_degree_distribution_preserved_exactly"
    ] = int(
        base_jdd == final_jdd
    )

    audit["baseline_name"] = (
        "dk2_full_budget"
    )

    return graph
