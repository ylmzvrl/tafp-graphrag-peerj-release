from pathlib import Path
import re, random, json, subprocess, sys
import pandas as pd
from datasets import load_dataset

TOPICS = {
    "POLITICS": ["president","government","election","law","policy"],
    "BUSINESS": ["company","market","bank","economy","financial"],
    "CRIME": ["police","court","murder","arrested","attack"],
    "HEALTH": ["hospital","doctor","patient","health","medical","virus"],
    "WAR": ["war","military","soldier","bomb","troops"],
    "DISASTER": ["earthquake","flood","storm","fire","crash"],
    "SPORTS": ["game","team","coach","player","football"],
    "ENTERTAINMENT": ["actor","movie","music","film","celebrity"],
}
SENSITIVE_TOPICS = {"POLITICS","CRIME","HEALTH","WAR","DISASTER"}

def clean_text(x, n=1000):
    return re.sub(r"\s+", " ", str(x)).strip()[:n]

def clean_token(x, n=70):
    x = re.sub(r"[^A-Za-z0-9_\- ]+", "", str(x))
    return re.sub(r"\s+", "_", x.strip())[:n]

def topics_of(text):
    low = text.lower()
    return [t for t,kws in TOPICS.items() if any(k in low for k in kws)]

def entities(text, max_n=10):
    cand = re.findall(r"\b[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){0,3}\b", text)
    stop = {"The","This","That","CNN","Daily Mail","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"}
    out, seen = [], set()
    for c in cand:
        if c in stop or len(c) < 3:
            continue
        tok = clean_token(c)
        if tok and tok not in seen:
            seen.add(tok)
            out.append(tok)
        if len(out) >= max_n:
            break
    return out

def sens(kind, topics, rng):
    base = {"ARTICLE":0.45, "HIGHLIGHT":0.65, "TOPIC":0.45, "ENTITY":0.55}.get(kind,0.45)
    if any(t in SENSITIVE_TOPICS for t in topics):
        base += 0.15
    return round(max(0.05, min(0.95, base + rng.uniform(-0.08,0.08))), 4)

def rel_sens(rel, topics):
    if rel in {"summary_exposes","highlight_mentions","summary_entity_exposure","co_mentions_news"}:
        return 1
    if any(t in SENSITIVE_TOPICS for t in topics):
        return 1
    return 0

def main(seed=42, num_docs=500):
    rng = random.Random(seed)
    Path("data").mkdir(exist_ok=True)

    ds = load_dataset("abisee/cnn_dailymail", "3.0.0", split="train", streaming=True)
    try:
        ds = ds.shuffle(buffer_size=3000, seed=seed)
    except Exception:
        pass

    nodes, edges = [], []
    seen_nodes, seen_edges = set(), set()

    def add_node(i, kind, text, topics):
        if i in seen_nodes:
            return
        seen_nodes.add(i)
        nodes.append({
            "id": i,
            "entity_type": kind,
            "pii": 0,
            "semantic_sensitivity": sens(kind, topics, rng),
            "text": text
        })

    def add_edge(a,b,rel,topics,w=1.0):
        if a == b:
            return
        key = (a,b,rel)
        if key in seen_edges:
            return
        seen_edges.add(key)
        edges.append({
            "source": a,
            "target": b,
            "relation_type": rel,
            "sensitive": rel_sens(rel, topics),
            "weight": round(float(w),4)
        })

    count = 0
    for item in ds:
        if count >= num_docs:
            break

        raw = clean_token(item.get("id", count), 40)
        article = clean_text(item.get("article",""), 1000)
        high = clean_text(item.get("highlights",""), 700)

        if len(article) < 100 or len(high) < 30:
            continue

        aid = f"ARTICLE_CNNDM_{raw}"
        hid = f"HIGHLIGHT_CNNDM_{raw}"
        ts = topics_of(article + " " + high)

        add_node(aid, "ARTICLE", article, ts)
        add_node(hid, "HIGHLIGHT", high, ts)
        add_edge(aid, hid, "summary_exposes", ts, 1.0)

        for t in ts:
            tid = f"TOPIC_CNNDM_{t}"
            add_node(tid, "TOPIC", f"CNN/DM topic: {t}", ts)
            add_edge(aid, tid, "article_has_topic", ts, rng.uniform(0.4,1.0))
            add_edge(hid, tid, "highlight_has_topic", ts, rng.uniform(0.4,1.0))

        article_ents = entities(article, 10)
        high_ents = entities(high, 10)
        all_eids = []

        for e in article_ents:
            eid = f"ENTITY_CNNDM_{clean_token(e)}"
            all_eids.append(eid)
            add_node(eid, "ENTITY", f"Article entity: {e}", ts)
            add_edge(aid, eid, "article_mentions", ts, rng.uniform(0.35,1.0))

        article_set = set(article_ents)

        for e in high_ents:
            eid = f"ENTITY_CNNDM_{clean_token(e)}"
            all_eids.append(eid)
            add_node(eid, "ENTITY", f"Highlight entity: {e}", ts)
            add_edge(hid, eid, "highlight_mentions", ts, rng.uniform(0.35,1.0))
            if e in article_set:
                add_edge(hid, eid, "summary_entity_exposure", ts, rng.uniform(0.5,1.0))

        uniq = []
        for eid in all_eids:
            if eid not in uniq:
                uniq.append(eid)

        for a,b in zip(uniq, uniq[1:]):
            add_edge(a, b, "co_mentions_news", ts, rng.uniform(0.2,0.75))

        count += 1

    node_df = pd.DataFrame(nodes)
    edge_df = pd.DataFrame(edges)
    node_df.to_csv("data/cnndm_nodes.csv", index=False)
    edge_df.to_csv("data/cnndm_edges.csv", index=False)

    print("DONE: CNN/DM graph generated")
    print("Nodes:", len(node_df))
    print("Edges:", len(edge_df))
    print("\nNode type counts:")
    print(node_df["entity_type"].value_counts())
    print("\nSensitive edge counts:")
    print(edge_df["sensitive"].value_counts())
    print("\nSensitive by relation:")
    print(pd.crosstab(edge_df["relation_type"], edge_df["sensitive"]))

if __name__ == "__main__":
    main()
