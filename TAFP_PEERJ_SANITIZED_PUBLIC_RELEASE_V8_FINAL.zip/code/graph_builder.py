import random
import numpy as np
import networkx as nx

ENTITY_TYPES = ["PERSON", "ORG", "PROJECT", "LOCATION", "EMAIL", "MEDICAL_ID", "DOCUMENT"]
RELATION_TYPES = ["works_on", "reports_to", "collaborates_with", "located_in", "owns", "mentions", "treats", "assigned_to", "accesses"]

SENSITIVE_ENTITY_TYPES = {"PERSON", "EMAIL", "MEDICAL_ID"}
SENSITIVE_RELATIONS = {"reports_to", "treats", "assigned_to", "accesses"}

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)

def build_synthetic_pii_kg(num_entities=500, num_relations=1400, seed=42):
    set_seed(seed)
    G = nx.Graph()

    for i in range(num_entities):
        etype = random.choices(
            ENTITY_TYPES,
            weights=[0.20, 0.18, 0.15, 0.12, 0.10, 0.08, 0.17],
            k=1
        )[0]
        node_id = f"{etype}_{i}"
        pii = 1.0 if etype in SENSITIVE_ENTITY_TYPES else 0.0
        semantic_sensitivity = random.random()
        G.add_node(
            node_id,
            entity_type=etype,
            pii=pii,
            semantic_sensitivity=semantic_sensitivity,
            protected_label=node_id,
            original_label=node_id
        )

    nodes = list(G.nodes())

    attempts = 0
    while G.number_of_edges() < num_relations and attempts < num_relations * 20:
        attempts += 1
        u, v = random.sample(nodes, 2)
        if G.has_edge(u, v):
            continue

        rtype = random.choices(
            RELATION_TYPES,
            weights=[0.16, 0.08, 0.14, 0.13, 0.08, 0.17, 0.06, 0.08, 0.10],
            k=1
        )[0]
        sensitive = 1.0 if rtype in SENSITIVE_RELATIONS else 0.0
        weight = random.random()
        G.add_edge(
            u,
            v,
            relation_type=rtype,
            protected_relation_type=rtype,
            sensitive=sensitive,
            weight=weight
        )

    return G
