import random
import numpy as np
import networkx as nx
from sklearn.metrics import roc_auc_score

from retrieval import build_retrieval_index, retrieve, node_to_text


def safe_auc(y, s):
    try:
        if len(set(y)) < 2:
            return 0.5
        return float(roc_auc_score(y, s))
    except Exception:
        return 0.5


def _bounded(x):
    return float(max(0.0, min(1.0, x)))


def semantic_mia_auc(
    G_base,
    G_protected,
    num_samples=100,
    seed=42,
    backend="tfidf",
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    batch_size=64,
    device="auto"
):
    random.seed(seed)

    if G_base.number_of_nodes() == 0 or G_protected.number_of_nodes() == 0:
        return 0.5

    members = random.sample(
        list(G_base.nodes()),
        min(num_samples, G_base.number_of_nodes())
    )

    prot_index = build_retrieval_index(
        G_protected,
        protected=True,
        backend=backend,
        model_name=model_name,
        batch_size=batch_size,
        device=device
    )

    if backend == "gpu_embedding":
        print(
            f"[semantic_mia] backend=gpu_embedding | "
            f"device={prot_index.get('device')} | "
            f"model={prot_index.get('model_name')}"
        )

    y = []
    scores = []

    for n in members:
        q_text = node_to_text(G_base, n, protected=False)
        _, sims = retrieve(prot_index, q_text, k=1)
        y.append(1)
        scores.append(float(sims[0]) if sims else 0.0)

    entity_types = [
        "PERSON", "ORG", "PROJECT", "LOCATION",
        "EMAIL", "MEDICAL_ID", "DOCUMENT"
    ]

    for i in range(len(members)):
        etype = random.choice(entity_types)
        pii = 1 if etype in ["PERSON", "EMAIL", "MEDICAL_ID"] else 0

        fake_text = (
            f"NODE NONMEMBER_{etype}_{i} "
            f"TYPE {etype} "
            f"PII {pii} "
            f"NEIGHBORS none "
            f"RELATIONS none"
        )

        _, sims = retrieve(prot_index, fake_text, k=1)
        y.append(0)
        scores.append(float(sims[0]) if sims else 0.0)

    return safe_auc(y, scores)

def _node_struct_features(G, n):
    if n not in G:
        return np.zeros(5, dtype=float)

    deg = float(G.degree(n))
    clustering = float(nx.clustering(G, n))

    neigh = list(G.neighbors(n))
    avg_neighbor_degree = (
        float(np.mean([G.degree(x) for x in neigh]))
        if neigh else 0.0
    )

    ego = nx.ego_graph(G, n, radius=1)
    ego_nodes = float(ego.number_of_nodes())
    ego_edges = float(ego.number_of_edges())

    return np.array(
        [deg, clustering, avg_neighbor_degree, ego_nodes, ego_edges],
        dtype=float
    )


def _struct_similarity(a, b):
    scale = np.maximum(np.abs(a) + np.abs(b), 1.0)
    dist = np.mean(np.abs(a - b) / scale)
    return _bounded(1.0 - dist)


def structural_mia_auc(G_base, G_protected, num_samples=100, seed=42):
    random.seed(seed)

    if G_base.number_of_nodes() == 0 or G_protected.number_of_nodes() == 0:
        return 0.5

    members = random.sample(
        list(G_base.nodes()),
        min(num_samples, G_base.number_of_nodes())
    )

    protected_nodes = list(G_protected.nodes())

    y = []
    scores = []

    for n in members:
        a = _node_struct_features(G_base, n)
        b = _node_struct_features(G_protected, n)
        y.append(1)
        scores.append(_struct_similarity(a, b))

    for n in members:
        a = _node_struct_features(G_base, n)

        m = random.choice(protected_nodes)
        tries = 0

        while m == n and tries < 10:
            m = random.choice(protected_nodes)
            tries += 1

        b = _node_struct_features(G_protected, m)

        y.append(0)
        scores.append(_struct_similarity(a, b))

    return safe_auc(y, scores)


def membership_inference_auc(
    G_base,
    G_protected,
    num_samples=100,
    seed=42,
    backend="tfidf",
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    batch_size=64,
    device="auto"
):
    sem = semantic_mia_auc(
        G_base,
        G_protected,
        num_samples=num_samples,
        seed=seed,
        backend=backend,
        model_name=model_name,
        batch_size=batch_size,
        device=device
    )

    struct = structural_mia_auc(
        G_base,
        G_protected,
        num_samples=num_samples,
        seed=seed
    )

    return float(0.5 * sem + 0.5 * struct)

def link_inference_auc(G_base, G_protected, sample_size=500, seed=42):
    random.seed(seed)

    if G_base.number_of_nodes() < 2:
        return 0.5

    base_edges = {tuple(sorted(e)) for e in G_base.edges()}
    prot_edges = {tuple(sorted(e)) for e in G_protected.edges()}

    hidden_edges = list(base_edges - prot_edges)

    if len(hidden_edges) > 0:
        positives = random.sample(
            hidden_edges,
            min(sample_size // 2, len(hidden_edges))
        )
        hidden_mode = True
    else:
        positives = random.sample(
            list(base_edges),
            min(sample_size // 2, len(base_edges))
        )
        hidden_mode = False

    nodes = list(G_base.nodes())
    negatives = []
    seen = set(positives)

    tries = 0
    max_tries = sample_size * 100

    while len(negatives) < len(positives) and tries < max_tries:
        tries += 1
        u, v = random.sample(nodes, 2)
        key = tuple(sorted((u, v)))

        if key not in base_edges and key not in seen:
            negatives.append(key)
            seen.add(key)

    if len(positives) == 0 or len(negatives) == 0:
        return 0.5

    pairs = positives + negatives
    y = [1] * len(positives) + [0] * len(negatives)

    def score_pair(u, v):
        if u not in G_protected or v not in G_protected:
            return 0.0

        direct = 1.0 if G_protected.has_edge(u, v) else 0.0

        nu = set(G_protected.neighbors(u))
        nv = set(G_protected.neighbors(v))

        common_nodes = nu & nv
        common = len(common_nodes)
        union = len(nu | nv)

        jaccard = common / union if union else 0.0
        common_norm = common / max(1, min(len(nu), len(nv)))

        resource_alloc = 0.0
        for z in common_nodes:
            resource_alloc += 1.0 / max(1, G_protected.degree(z))
        resource_alloc = min(1.0, resource_alloc)

        try:
            dist = nx.shortest_path_length(G_protected, u, v)
            path_score = 1.0 / dist if dist > 0 else 1.0
        except Exception:
            path_score = 0.0

        if hidden_mode:
            score = (
                0.35 * jaccard +
                0.25 * common_norm +
                0.25 * resource_alloc +
                0.15 * path_score
            )
        else:
            score = (
                0.70 * direct +
                0.15 * jaccard +
                0.10 * common_norm +
                0.05 * resource_alloc
            )

        return float(max(0.0, min(1.0, score)))

    scores = [score_pair(u, v) for u, v in pairs]

    auc = safe_auc(y, scores)
    return float(max(0.5, auc))


def _hist_distance(a, b, bins=20):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)

    if len(a) == 0 or len(b) == 0:
        return 1.0

    hi = max(float(a.max()), float(b.max()), 1.0)

    ha, _ = np.histogram(a, bins=bins, range=(0.0, hi), density=True)
    hb, _ = np.histogram(b, bins=bins, range=(0.0, hi), density=True)

    return float(
        np.mean(np.abs(ha - hb)) /
        (np.mean(np.abs(ha)) + 1e-9)
    )


def topology_leakage_score(G_base, G_protected):
    if G_base.number_of_nodes() == 0 or G_protected.number_of_nodes() == 0:
        return 0.0

    base_deg = [d for _, d in G_base.degree()]
    prot_deg = [d for _, d in G_protected.degree()]
    deg_div = min(1.0, _hist_distance(base_deg, prot_deg))

    base_clust = list(nx.clustering(G_base).values())
    prot_clust = list(nx.clustering(G_protected).values())
    clust_div = min(1.0, _hist_distance(base_clust, prot_clust))

    base_components = nx.number_connected_components(G_base)
    prot_components = nx.number_connected_components(G_protected)

    comp_div = min(
        1.0,
        abs(base_components - prot_components) / max(1.0, base_components)
    )

    density_base = nx.density(G_base)
    density_prot = nx.density(G_protected)

    density_div = min(
        1.0,
        abs(density_base - density_prot) / (abs(density_base) + 1e-9)
    )

    divergence = (
        0.40 * deg_div +
        0.30 * clust_div +
        0.15 * comp_div +
        0.15 * density_div
    )

    leakage = 1.0 - min(1.0, divergence)

    return _bounded(leakage)


def reconstruction_similarity(G_base, G_protected):
    e_base = {tuple(sorted(e)) for e in G_base.edges()}
    e_prot = {tuple(sorted(e)) for e in G_protected.edges()}

    if not e_base and not e_prot:
        return 1.0

    return float(
        len(e_base & e_prot) /
        max(1, len(e_base | e_prot))
    )
