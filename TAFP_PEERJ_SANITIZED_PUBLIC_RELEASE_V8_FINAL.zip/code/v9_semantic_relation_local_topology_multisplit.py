import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

import v9_semantic_relation_structure_smoke as smoke
import v9_semantic_relation_feature_ablation as ablation


OUTPUT_DIR = Path(
    "outputs/v9_semantic_relation_local_topology_multisplit"
)

PROTECTION_SEEDS = [
    1, 7, 21, 42, 99,
    123, 202, 303, 404, 505,
    606, 707, 808, 909, 1001,
]

SPLIT_SEEDS = [
    101, 202, 303, 404, 505,
    606, 707, 808, 909, 1001,
]


def create_split_assignments(modeling_edges):
    assignments = []
    split_maps = {}

    for split_seed in SPLIT_SEEDS:
        train_df, test_df = train_test_split(
            modeling_edges,
            test_size=0.30,
            random_state=split_seed,
            stratify=modeling_edges[
                "original_relation_type"
            ],
        )

        train_keys = set(train_df["edge_key"])
        test_keys = set(test_df["edge_key"])

        if train_keys & test_keys:
            raise RuntimeError(
                f"Split {split_seed}: edge overlap"
            )

        if train_keys | test_keys != set(
            modeling_edges["edge_key"]
        ):
            raise RuntimeError(
                f"Split {split_seed}: incomplete edge coverage"
            )

        split_maps[split_seed] = {
            "train": train_keys,
            "test": test_keys,
        }

        for split_name, frame in [
            ("train", train_df),
            ("test", test_df),
        ]:
            for row in frame.itertuples(index=False):
                assignments.append({
                    "split_seed": split_seed,
                    "edge_key": row.edge_key,
                    "split": split_name,
                    "target_group": row.target_group,
                    "relation_type":
                        row.original_relation_type,
                })

    return split_maps, assignments


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    results = []
    all_assignments = []

    for dataset in smoke.DATASETS:
        print("\n" + "=" * 70)
        print("DATASET:", dataset)

        with open(
            smoke.CONFIGS[dataset],
            "r",
            encoding="utf-8",
        ) as handle:
            config = json.load(handle)

        base_graph = smoke.build_graph_from_config(config)

        unique_edges, _ = (
            smoke.load_unique_edges_and_split(dataset)
        )

        modeling_edges = unique_edges[
            unique_edges["included_in_main_attack"] == 1
        ].copy()

        modeling_edges["split"] = "train"

        split_maps, assignments = (
            create_split_assignments(modeling_edges)
        )

        for row in assignments:
            row["dataset_name"] = dataset

        all_assignments.extend(assignments)

        print(
            "Edges:",
            len(modeling_edges),
            "| Splits:",
            len(SPLIT_SEEDS),
        )

        print("Computing risks once...")
        risks = smoke.compute_all_risks(base_graph)

        for protection_seed in PROTECTION_SEEDS:
            for variant in smoke.VARIANTS:
                print(
                    f"{dataset} | seed={protection_seed} "
                    f"| {variant}"
                )

                _, feature_rows, empty_test = (
                    smoke.prepare_variant_data(
                        dataset=dataset,
                        attack_seed=protection_seed,
                        variant=variant,
                        base_graph=base_graph,
                        original_config=config,
                        risks=risks,
                        split_df=modeling_edges,
                    )
                )

                if empty_test:
                    raise RuntimeError(
                        "Unexpected test rows during "
                        "feature extraction"
                    )

                feature_lookup = {
                    row["edge_key"]: row
                    for row in feature_rows
                }

                if len(feature_lookup) != len(
                    modeling_edges
                ):
                    raise RuntimeError(
                        "Incomplete feature extraction"
                    )

                for split_seed, split_map in (
                    split_maps.items()
                ):
                    train_rows = [
                        feature_lookup[key]
                        for key in split_map["train"]
                    ]

                    test_rows = [
                        feature_lookup[key]
                        for key in split_map["test"]
                    ]

                    metrics = ablation.evaluate(
                        train_rows=train_rows,
                        test_rows=test_rows,
                        feature_group="local_topology",
                        seed=protection_seed,
                    )

                    results.append({
                        "dataset_name": dataset,
                        "split_seed": split_seed,
                        "protection_seed":
                            protection_seed,
                        "variant": variant,
                        "n_train": len(train_rows),
                        "n_test": len(test_rows),
                        **metrics,
                    })

    results_df = pd.DataFrame(results)
    assignments_df = pd.DataFrame(all_assignments)

    expected_rows = (
        len(smoke.DATASETS)
        * len(SPLIT_SEEDS)
        * len(PROTECTION_SEEDS)
        * len(smoke.VARIANTS)
    )

    duplicate_rows = int(
        results_df.duplicated(
            [
                "dataset_name",
                "split_seed",
                "protection_seed",
                "variant",
            ]
        ).sum()
    )

    missing_values = int(
        results_df.isna().sum().sum()
    )

    audit_pass = int(
        len(results_df) == expected_rows
        and duplicate_rows == 0
        and missing_values == 0
    )

    results_df.to_csv(
        OUTPUT_DIR / "multisplit_results.csv",
        index=False,
    )

    assignments_df.to_csv(
        OUTPUT_DIR / "split_assignments.csv",
        index=False,
    )

    audit = {
        "datasets": len(smoke.DATASETS),
        "split_seeds": len(SPLIT_SEEDS),
        "protection_seeds":
            len(PROTECTION_SEEDS),
        "variants": len(smoke.VARIANTS),
        "expected_rows": expected_rows,
        "actual_rows": len(results_df),
        "duplicate_rows": duplicate_rows,
        "missing_values": missing_values,
        "audit_pass": audit_pass,
    }

    with open(
        OUTPUT_DIR / "multisplit_audit.json",
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(audit, handle, indent=2)

    print("\nAUDIT")
    print(json.dumps(audit, indent=2))

    print("\nOVERALL MEAN RESULTS")
    print(
        results_df.groupby(
            ["dataset_name", "variant"]
        )[
            ["macro_f1", "balanced_accuracy"]
        ]
        .mean()
        .round(4)
        .to_string()
    )

    if audit_pass != 1:
        raise RuntimeError(
            "MULTI-SPLIT AUDIT FAILED"
        )

    print("\nLOCAL TOPOLOGY MULTI-SPLIT: PASS")


if __name__ == "__main__":
    main()
