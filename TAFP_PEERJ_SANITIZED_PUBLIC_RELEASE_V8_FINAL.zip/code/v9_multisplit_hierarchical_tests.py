from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd


INPUT = Path(
    "outputs/v9_semantic_relation_local_topology_multisplit/"
    "multisplit_results.csv"
)

OUTPUT_DIR = INPUT.parent

COMPARATORS = [
    "baseline",
    "random_edge_dropout",
    "random_full_budget",
    "random_relation_budget",
]

METRICS = [
    "macro_f1",
    "balanced_accuracy",
]

BOOTSTRAP_ITERATIONS = 50000
BOOTSTRAP_CHUNK = 5000
RANDOM_SEED = 20260618


def hierarchical_bootstrap_ci(
    differences,
    rng,
):
    differences = np.asarray(differences, dtype=float)

    n_splits, n_protection_seeds = differences.shape

    bootstrap_means = np.empty(
        BOOTSTRAP_ITERATIONS,
        dtype=float,
    )

    for start in range(
        0,
        BOOTSTRAP_ITERATIONS,
        BOOTSTRAP_CHUNK,
    ):
        stop = min(
            start + BOOTSTRAP_CHUNK,
            BOOTSTRAP_ITERATIONS,
        )

        size = stop - start

        sampled_splits = rng.integers(
            0,
            n_splits,
            size=(size, n_splits),
        )

        sampled_protection = rng.integers(
            0,
            n_protection_seeds,
            size=(
                size,
                n_splits,
                n_protection_seeds,
            ),
        )

        split_index = np.broadcast_to(
            sampled_splits[:, :, None],
            sampled_protection.shape,
        )

        sampled_values = differences[
            split_index,
            sampled_protection,
        ]

        bootstrap_means[start:stop] = (
            sampled_values.mean(axis=(1, 2))
        )

    return np.quantile(
        bootstrap_means,
        [0.025, 0.975],
    )


def exact_split_sign_flip_pvalue(
    split_mean_differences,
):
    differences = np.asarray(
        split_mean_differences,
        dtype=float,
    )

    observed = differences.mean()

    signs = np.asarray(
        list(
            product(
                [-1.0, 1.0],
                repeat=len(differences),
            )
        ),
        dtype=float,
    )

    null_means = (
        signs * differences[None, :]
    ).mean(axis=1)

    # One-sided alternative:
    # Full produces a lower attack score.
    return float(
        np.mean(
            null_means <= observed + 1e-15
        )
    )


def holm_adjust(rows):
    order = sorted(
        range(len(rows)),
        key=lambda index:
            rows[index]["raw_p_one_sided"],
    )

    adjusted = [0.0] * len(rows)
    running_max = 0.0
    total = len(rows)

    for rank, index in enumerate(order):
        corrected = min(
            1.0,
            (total - rank)
            * rows[index]["raw_p_one_sided"],
        )

        running_max = max(
            running_max,
            corrected,
        )

        adjusted[index] = running_max

    for row, value in zip(rows, adjusted):
        row["holm_p_one_sided"] = value
        row["significant_holm_0_05"] = int(
            value < 0.05
        )


def main():
    df = pd.read_csv(INPUT)

    required_columns = {
        "dataset_name",
        "split_seed",
        "protection_seed",
        "variant",
        "macro_f1",
        "balanced_accuracy",
    }

    missing_columns = required_columns - set(df.columns)

    if missing_columns:
        raise RuntimeError(
            f"Missing columns: {missing_columns}"
        )

    duplicate_count = int(
        df.duplicated(
            [
                "dataset_name",
                "split_seed",
                "protection_seed",
                "variant",
            ]
        ).sum()
    )

    if duplicate_count:
        raise RuntimeError(
            f"Duplicate rows: {duplicate_count}"
        )

    rng = np.random.default_rng(RANDOM_SEED)

    result_rows = []
    split_rows = []

    for dataset in sorted(
        df["dataset_name"].unique()
    ):
        dataset_df = df[
            df["dataset_name"] == dataset
        ]

        for metric in METRICS:
            pivot = dataset_df.pivot(
                index=[
                    "split_seed",
                    "protection_seed",
                ],
                columns="variant",
                values=metric,
            )

            family_rows = []

            for comparator in COMPARATORS:
                pair_df = (
                    pivot[["full", comparator]]
                    .dropna()
                    .reset_index()
                )

                pair_df["difference"] = (
                    pair_df["full"]
                    - pair_df[comparator]
                )

                matrix = pair_df.pivot(
                    index="split_seed",
                    columns="protection_seed",
                    values="difference",
                )

                if matrix.shape != (10, 15):
                    raise RuntimeError(
                        f"Unexpected matrix shape: "
                        f"{dataset}, {metric}, "
                        f"{comparator}, {matrix.shape}"
                    )

                if matrix.isna().any().any():
                    raise RuntimeError(
                        "Missing paired observations"
                    )

                difference_matrix = (
                    matrix.to_numpy(dtype=float)
                )

                split_means = (
                    difference_matrix.mean(axis=1)
                )

                ci_low, ci_high = (
                    hierarchical_bootstrap_ci(
                        difference_matrix,
                        rng,
                    )
                )

                full_mean = float(
                    pair_df["full"].mean()
                )

                comparator_mean = float(
                    pair_df[comparator].mean()
                )

                mean_difference = float(
                    difference_matrix.mean()
                )

                relative_reduction = (
                    100.0
                    * (
                        comparator_mean
                        - full_mean
                    )
                    / comparator_mean
                    if comparator_mean != 0
                    else np.nan
                )

                row = {
                    "dataset_name": dataset,
                    "metric": metric,
                    "comparison":
                        f"full_vs_{comparator}",
                    "n_splits":
                        difference_matrix.shape[0],
                    "protection_seeds_per_split":
                        difference_matrix.shape[1],
                    "n_paired_observations":
                        difference_matrix.size,
                    "full_mean": full_mean,
                    "comparator_mean":
                        comparator_mean,
                    "mean_difference_full_minus_comparator":
                        mean_difference,
                    "relative_attack_reduction_percent":
                        relative_reduction,
                    "hierarchical_ci95_low":
                        float(ci_low),
                    "hierarchical_ci95_high":
                        float(ci_high),
                    "full_lower_split_count":
                        int((split_means < 0).sum()),
                    "full_lower_pair_count":
                        int(
                            (
                                difference_matrix < 0
                            ).sum()
                        ),
                    "raw_p_one_sided":
                        exact_split_sign_flip_pvalue(
                            split_means
                        ),
                }

                family_rows.append(row)

                for split_seed, split_difference in zip(
                    matrix.index,
                    split_means,
                ):
                    split_rows.append({
                        "dataset_name": dataset,
                        "metric": metric,
                        "comparison":
                            f"full_vs_{comparator}",
                        "split_seed":
                            int(split_seed),
                        "mean_difference_full_minus_comparator":
                            float(split_difference),
                    })

            holm_adjust(family_rows)
            result_rows.extend(family_rows)

    results = pd.DataFrame(result_rows)
    split_results = pd.DataFrame(split_rows)

    results.to_csv(
        OUTPUT_DIR
        / "hierarchical_statistical_tests.csv",
        index=False,
    )

    split_results.to_csv(
        OUTPUT_DIR
        / "split_level_differences.csv",
        index=False,
    )

    print(
        results.round(6).to_string(index=False)
    )

    print(
        "\nSAVED:",
        OUTPUT_DIR
        / "hierarchical_statistical_tests.csv",
    )


if __name__ == "__main__":
    main()
