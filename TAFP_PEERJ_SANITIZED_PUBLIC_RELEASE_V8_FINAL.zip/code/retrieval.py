import random
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def node_to_text(G, node, protected=True):
    data = G.nodes[node]

    label = data.get("protected_label", node) if protected else data.get("original_label", node)
    node_text = str(data.get("text", ""))

    neighbors = []
    relations = []

    for nb in list(G.neighbors(node))[:8]:
        nb_data = G.nodes[nb]
        nb_label = nb_data.get("protected_label", nb) if protected else nb_data.get("original_label", nb)
        neighbors.append(str(nb_label))

        edge_data = G.edges[node, nb]

        if protected:
            rel = edge_data.get("protected_relation_type", edge_data.get("relation_type", "related_to"))
        else:
            rel = edge_data.get("relation_type", "related_to")

        relations.append(str(rel))

    return " ".join([
        f"NODE {label}",
        f"TYPE {data.get('entity_type', 'ENTITY')}",
        f"PII {data.get('pii', 0)}",
        f"TEXT {node_text}",
        "NEIGHBORS " + " ".join(neighbors),
        "RELATIONS " + " ".join(relations)
    ])


def sample_queries(G, num_queries=100, seed=42):
    random.seed(seed)
    nodes = list(G.nodes())
    return random.sample(nodes, min(num_queries, len(nodes)))


def _resolve_device(device="auto"):
    if device != "auto":
        return device

    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"


# =====================================================
# TF-IDF BACKEND
# =====================================================
def build_tfidf_index(G, protected=True):
    nodes = list(G.nodes())
    texts = [node_to_text(G, n, protected=protected) for n in nodes]

    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    matrix = vectorizer.fit_transform(texts)

    return {
        "backend": "tfidf",
        "nodes": nodes,
        "texts": texts,
        "vectorizer": vectorizer,
        "matrix": matrix
    }


def retrieve_tfidf(index, query_text, k=10):
    q = index["vectorizer"].transform([query_text])
    sims = cosine_similarity(q, index["matrix"])[0]
    ranked = np.argsort(-sims)

    return (
        [index["nodes"][i] for i in ranked[:k]],
        [float(sims[i]) for i in ranked[:k]]
    )


# =====================================================
# GPU EMBEDDING BACKEND
# =====================================================
def build_gpu_embedding_index(
    G,
    protected=True,
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    batch_size=64,
    device="auto"
):
    from sentence_transformers import SentenceTransformer

    resolved_device = _resolve_device(device)

    nodes = list(G.nodes())
    texts = [node_to_text(G, n, protected=protected) for n in nodes]

    model = SentenceTransformer(model_name, device=resolved_device)

    embeddings = model.encode(
        texts,
        batch_size=batch_size,
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=False
    )

    return {
        "backend": "gpu_embedding",
        "nodes": nodes,
        "texts": texts,
        "model": model,
        "embeddings": embeddings,
        "device": resolved_device,
        "model_name": model_name
    }


def retrieve_gpu_embedding(index, query_text, k=10):
    q_emb = index["model"].encode(
        [query_text],
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=False
    )[0]

    sims = np.dot(index["embeddings"], q_emb)
    ranked = np.argsort(-sims)

    return (
        [index["nodes"][i] for i in ranked[:k]],
        [float(sims[i]) for i in ranked[:k]]
    )


# =====================================================
# SHARED API
# =====================================================
def build_retrieval_index(
    G,
    protected=True,
    backend="tfidf",
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    batch_size=64,
    device="auto"
):
    if backend == "tfidf":
        return build_tfidf_index(G, protected=protected)

    if backend == "gpu_embedding":
        return build_gpu_embedding_index(
            G,
            protected=protected,
            model_name=model_name,
            batch_size=batch_size,
            device=device
        )

    raise ValueError(f"Unknown retrieval backend: {backend}")


def retrieve(index, query_text, k=10):
    backend = index.get("backend", "tfidf")

    if backend == "tfidf":
        return retrieve_tfidf(index, query_text, k=k)

    if backend == "gpu_embedding":
        return retrieve_gpu_embedding(index, query_text, k=k)

    raise ValueError(f"Unknown retrieval backend: {backend}")


def evaluate_retrieval_utility(
    G_base,
    G_protected,
    queries,
    k=10,
    backend="tfidf",
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    batch_size=64,
    device="auto"
):
    base_index = build_retrieval_index(
        G_base,
        protected=False,
        backend=backend,
        model_name=model_name,
        batch_size=batch_size,
        device=device
    )

    prot_index = build_retrieval_index(
        G_protected,
        protected=True,
        backend=backend,
        model_name=model_name,
        batch_size=batch_size,
        device=device
    )

    if backend == "gpu_embedding":
        print(
            f"[retrieval] backend=gpu_embedding | "
            f"device={base_index.get('device')} | "
            f"model={base_index.get('model_name')}"
        )

    recalls = []
    ndcgs = []

    for q in queries:
        if q not in G_base:
            continue

        q_text = node_to_text(G_base, q, protected=False)

        base_top, _ = retrieve(base_index, q_text, k=k)
        prot_top, _ = retrieve(prot_index, q_text, k=k)

        if not base_top:
            continue

        base_set = set(base_top)

        overlap = len(base_set & set(prot_top))
        recalls.append(overlap / len(base_top))

        dcg = 0.0
        for i, item in enumerate(prot_top):
            if item in base_set:
                dcg += 1.0 / np.log2(i + 2)

        ideal_len = min(len(base_top), k)
        ideal = sum(1.0 / np.log2(i + 2) for i in range(ideal_len))

        ndcgs.append(dcg / ideal if ideal > 0 else 0.0)

    return {
        "recall_at_k": float(np.mean(recalls)) if recalls else 0.0,
        "ndcg_at_k": float(np.mean(ndcgs)) if ndcgs else 0.0
    }
