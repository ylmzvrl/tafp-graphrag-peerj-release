from pathlib import Path
import sys
import json
import inspect
import subprocess
import pandas as pd

dataset = sys.argv[1]
seed = int(sys.argv[2])

OUTDIR = Path("outputs/v8_15seed_partial")
OUTDIR.mkdir(parents=True, exist_ok=True)

out_file = OUTDIR / f"{dataset}_seed_{seed}.csv"

if out_file.exists():
    print(f"SKIP {dataset} seed={seed}: already exists")
    raise SystemExit(0)

CONFIGS = {
    "SynthPII": "config_synthpii_gpu_embedding.json",
    "AGNews": "config_agnews_gpu_embedding.json",
    "IMDB": "config_imdb_gpu_embedding.json",
    "PubMed": "config_pubmed_gpu_embedding.json",
    "CNN_DM": "config_cnndm_gpu_embedding.json",
}

def call_generator(fn, seed):
    kwargs = {
        "out_dir": "data",
        "seed": seed,
        "num_docs": 500,
        "num_nodes": 800,
        "num_edges": 2400,
        "max_entities_per_doc": 10,
        "max_concepts_per_doc": 10,
    }

    sig = inspect.signature(fn)
    filtered = {k: v for k, v in kwargs.items() if k in sig.parameters}
    return fn(**filtered)

print("\n==============================")
print(f"Running {dataset} seed={seed}")
print("==============================\n")

if dataset == "SynthPII":
    from dataset_adapters.synthpii_adapter import generate_synthpii_graph
    call_generator(generate_synthpii_graph, seed)

elif dataset == "AGNews":
    from dataset_adapters.agnews_adapter import generate_agnews_graph
    call_generator(generate_agnews_graph, seed)

elif dataset == "IMDB":
    from dataset_adapters.imdb_adapter import generate_imdb_graph
    call_generator(generate_imdb_graph, seed)

elif dataset == "PubMed":
    from dataset_adapters.pubmed_adapter import generate_pubmed_graph
    call_generator(generate_pubmed_graph, seed)

elif dataset == "CNN_DM":
    import make_cnndm
    make_cnndm.main(seed=seed, num_docs=500)

else:
    raise ValueError(f"Unknown dataset: {dataset}")

base = json.loads(Path(CONFIGS[dataset]).read_text())
base["dataset_name"] = dataset
base["seed"] = seed
base["retrieval_backend"] = "gpu_embedding"
base["variants"] = [
    "baseline",
    "entity_only",
    "relation_only",
    "topology_only",
    "full",
    "random_entity_budget",
    "random_relation_budget",
    "random_edge_dropout",
    "random_full_budget",
]
base["embedding_device"] = "cuda"

cfg_path = Path(f"config_{dataset.lower()}_v8_seed_{seed}.json")
cfg_path.write_text(json.dumps(base, indent=2))

subprocess.run(
    [sys.executable, "run_all_v8.py", cfg_path.name],
    check=True
)

df = pd.read_csv("outputs/summary_results.csv")

expected = {
    "baseline",
    "entity_only",
    "relation_only",
    "topology_only",
    "full",
    "random_entity_budget",
    "random_relation_budget",
    "random_edge_dropout",
    "random_full_budget",
}

found = set(df["variant"])

if found != expected or len(df) != len(expected):
    raise RuntimeError(
        f"Variant validation failed. Found: {sorted(found)}"
    )

audit = df.set_index("variant")

checks = [
    (
        "entity budget",
        int(audit.loc["entity_only", "masked_nodes"]),
        int(audit.loc["random_entity_budget", "masked_nodes"]),
    ),
    (
        "relation budget",
        int(audit.loc["relation_only", "relation_rewired_edges"]),
        int(audit.loc["random_relation_budget", "relation_rewired_edges"]),
    ),
    (
        "full entity budget",
        int(audit.loc["full", "masked_nodes"]),
        int(audit.loc["random_full_budget", "masked_nodes"]),
    ),
    (
        "full relation budget",
        int(audit.loc["full", "relation_rewired_edges"]),
        int(audit.loc["random_full_budget", "relation_rewired_edges"]),
    ),
    (
        "full topology budget",
        int(audit.loc["full", "topology_rewired_edges"]),
        int(audit.loc["random_full_budget", "topology_rewired_edges"]),
    ),
    (
        "topology/dropout budget",
        int(audit.loc["topology_only", "topology_rewired_edges"]),
        int(audit.loc["random_edge_dropout", "dropped_edges"]),
    ),
]

for name, adaptive_value, baseline_value in checks:
    if adaptive_value != baseline_value:
        raise RuntimeError(
            f"{name} mismatch: {adaptive_value} != {baseline_value}"
        )

degree_preserving = expected - {"random_edge_dropout"}

for variant in degree_preserving:
    preserved = int(
        audit.loc[variant, "degree_preserved_exactly"]
    )
    if preserved != 1:
        raise RuntimeError(
            f"Degree preservation failed for {variant}"
        )

df["dataset_name"] = dataset
df["seed"] = seed
df.to_csv(out_file, index=False)

print(f"SAVED: {out_file}")
