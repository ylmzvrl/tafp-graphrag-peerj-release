import random

def apply_entity_protection(G, entity_risk, mask_rate=0.75, high=0.66, medium=0.33, seed=42):
    random.seed(seed)
    Gp = G.copy()

    for n, data in Gp.nodes(data=True):
        r = float(entity_risk.get(n, 0.0))

        if r >= high and random.random() < mask_rate:
            data["protected_label"] = f"ENT_HIGH_{abs(hash(n)) % 100000}"
            data["entity_protection"] = "high_mask"
            data["pii"] = 0.0
        elif r >= medium and random.random() < mask_rate:
            etype = data.get("entity_type", "ENTITY")
            data["protected_label"] = f"{etype}_MASKED"
            data["entity_protection"] = "medium_mask"
        else:
            data["protected_label"] = data.get("original_label", n)
            data["entity_protection"] = "none"

    return Gp

def apply_relation_protection(G, relation_risk, remove_rate=0.12, high=0.66, medium=0.33, seed=42):
    random.seed(seed)
    Gp = G.copy()

    edges = list(Gp.edges(data=True))
    to_remove = []

    for u, v, data in edges:
        key = tuple(sorted((u, v)))
        r = float(relation_risk.get(key, 0.0))

        if r >= high:
            data["protected_relation_type"] = "PRIVATE_RELATION"
            data["relation_protection"] = "mask"
            if random.random() < remove_rate:
                to_remove.append((u, v))
        elif r >= medium:
            data["protected_relation_type"] = "GENERAL_RELATION"
            data["relation_protection"] = "generalize"
        else:
            data["protected_relation_type"] = data.get("relation_type", "related_to")
            data["relation_protection"] = "none"

    Gp.remove_edges_from(to_remove)
    return Gp

def apply_topology_protection(G, topo_risk, rewire_rate=0.08, high=0.66, seed=42):
    random.seed(seed)
    Gp = G.copy()

    edges = list(Gp.edges())
    if not edges:
        return Gp

    high_nodes = {n for n, r in topo_risk.items() if float(r) >= high}
    candidate_edges = [(u, v) for u, v in edges if u in high_nodes or v in high_nodes]

    num_rewire = int(rewire_rate * len(candidate_edges))
    nodes = list(Gp.nodes())

    for u, v in random.sample(candidate_edges, min(num_rewire, len(candidate_edges))):
        if not Gp.has_edge(u, v):
            continue
        attrs = dict(Gp.edges[u, v])
        Gp.remove_edge(u, v)

        for _ in range(25):
            x, y = random.sample(nodes, 2)
            if x != y and not Gp.has_edge(x, y):
                attrs["topology_protection"] = "rewired"
                Gp.add_edge(x, y, **attrs)
                break

    return Gp

def apply_variant(G, risks, variant, config):
    entity_risk, relation_risk, topo_risk = risks

    if variant == "baseline":
        return G.copy()

    Gp = G.copy()

    if variant in ["entity_only", "full"]:
        Gp = apply_entity_protection(
            Gp,
            entity_risk,
            mask_rate=config.get("entity_mask_rate", 0.75),
            seed=config.get("seed", 42)
        )

    if variant in ["relation_only", "full"]:
        Gp = apply_relation_protection(
            Gp,
            relation_risk,
            remove_rate=config.get("relation_remove_rate", 0.12),
            seed=config.get("seed", 42)
        )

    if variant in ["topology_only", "full"]:
        Gp = apply_topology_protection(
            Gp,
            topo_risk,
            rewire_rate=config.get("topology_rewire_rate", 0.08),
            seed=config.get("seed", 42)
        )

    return Gp

# =====================================================
# V7 OVERRIDE: edge-sensitive protection for dataset adapters
# This override makes relation_only/full actually use CSV edge sensitive flags.
# =====================================================
import random as _v7_random
import hashlib as _v7_hashlib


def _v7_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


def _v7_truthy(x):
    if isinstance(x, bool):
        return x
    if isinstance(x, (int, float)):
        return x > 0
    if isinstance(x, str):
        return x.strip().lower() in {"1", "true", "yes", "y"}
    return False


def _v7_node_sensitive(data, config):
    pii = _v7_truthy(data.get("pii", 0))
    sens = _v7_float(data.get("semantic_sensitivity", 0.0))
    threshold = _v7_float(config.get("entity_sensitivity_threshold", 0.45), 0.45)
    return pii or sens >= threshold


def _v7_edge_sensitive(data):
    if _v7_truthy(data.get("sensitive", 0)):
        return True
    if _v7_float(data.get("relation_sensitivity", 0.0)) >= 0.45:
        return True
    return False


def _v7_mask_label(node, data, seed):
    sens = _v7_float(data.get("semantic_sensitivity", 0.0))
    pii = _v7_truthy(data.get("pii", 0))

    if pii or sens >= 0.70:
        level = "HIGH"
    elif sens >= 0.45:
        level = "MED"
    else:
        level = "LOW"

    h = _v7_hashlib.md5(f"{node}-{seed}".encode()).hexdigest()[:8]
    return f"ENT_{level}_{h}"


def _v7_apply_entity_protection(Gp, config):
    seed = int(config.get("seed", 42))

    for n, data in Gp.nodes(data=True):
        data["original_label"] = data.get("original_label", n)

        if _v7_node_sensitive(data, config):
            data["protected_label"] = _v7_mask_label(n, data, seed)
        else:
            data["protected_label"] = data.get("original_label", n)


def _v7_candidate_edges(Gp, mode):
    edges = []

    for u, v, data in Gp.edges(data=True):
        if mode == "sensitive":
            if _v7_edge_sensitive(data):
                edges.append((u, v))
        elif mode == "all":
            edges.append((u, v))

    return edges


def _v7_rewire_edges(Gp, candidate_edges, rate, seed, relation_private=False):
    rng = _v7_random.Random(seed)
    nodes = list(Gp.nodes())

    if not candidate_edges or len(nodes) < 2:
        return 0, 0

    n_target = int(len(candidate_edges) * rate)
    n_target = max(1, n_target) if rate > 0 else 0
    n_target = min(n_target, len(candidate_edges))

    selected = rng.sample(candidate_edges, n_target)

    removed = 0
    added = 0

    for u, v in selected:
        if not Gp.has_edge(u, v):
            continue

        attrs = dict(Gp.edges[u, v])

        Gp.remove_edge(u, v)
        removed += 1

        success = False

        for _ in range(100):
            a, b = rng.sample(nodes, 2)

            if a == b:
                continue

            if Gp.has_edge(a, b):
                continue

            new_attrs = dict(attrs)

            if relation_private:
                new_attrs["protected_relation_type"] = "PRIVATE_RELATION"
                new_attrs["relation_type"] = "PRIVATE_RELATION"
                new_attrs["sensitive"] = 0

            Gp.add_edge(a, b, **new_attrs)
            added += 1
            success = True
            break

        if not success:
            Gp.add_edge(u, v, **attrs)
            removed -= 1

    return removed, added


def _v7_apply_relation_protection(Gp, config):
    seed = int(config.get("seed", 42))
    rate = _v7_float(config.get("relation_remove_rate", 0.12), 0.12)

    # First sanitize relation labels for all sensitive edges.
    for u, v, data in Gp.edges(data=True):
        if _v7_edge_sensitive(data):
            data["protected_relation_type"] = "PRIVATE_RELATION"

    # Then structurally rewire a fraction of sensitive edges.
    candidates = _v7_candidate_edges(Gp, mode="sensitive")
    return _v7_rewire_edges(
        Gp,
        candidates,
        rate=rate,
        seed=seed + 101,
        relation_private=True
    )


def _v7_apply_topology_protection(Gp, config):
    seed = int(config.get("seed", 42))
    rate = _v7_float(config.get("topology_rewire_rate", 0.08), 0.08)

    candidates = _v7_candidate_edges(Gp, mode="all")
    return _v7_rewire_edges(
        Gp,
        candidates,
        rate=rate,
        seed=seed + 202,
        relation_private=False
    )


def apply_variant(G_base, risks, variant, config):
    """
    V7 override.
    Variants:
    - baseline: no protection
    - entity_only: mask sensitive entity labels
    - relation_only: privatize and rewire sensitive relation edges
    - topology_only: topology rewiring
    - full: entity + relation + topology
    """
    Gp = G_base.copy()

    if variant == "baseline":
        return Gp

    if variant == "entity_only":
        _v7_apply_entity_protection(Gp, config)
        return Gp

    if variant == "relation_only":
        _v7_apply_relation_protection(Gp, config)
        return Gp

    if variant == "topology_only":
        _v7_apply_topology_protection(Gp, config)
        return Gp

    if variant == "full":
        _v7_apply_entity_protection(Gp, config)
        _v7_apply_relation_protection(Gp, config)
        _v7_apply_topology_protection(Gp, config)
        return Gp

    raise ValueError(f"Unknown variant: {variant}")

# ============================================================
# V8 CORRECTED OVERRIDE
# - entity_mask_rate is respected
# - rewiring preserves every node degree exactly
# - existing V7 files remain unchanged
# ============================================================

import random as _v8_random
import hashlib as _v8_hashlib


def _v8_clamp_rate(value, default):
    try:
        value = float(value)
    except Exception:
        value = default
    return max(0.0, min(1.0, value))


def _v8_node_score(data):
    pii = 1.0 if _v7_truthy(data.get("pii", 0)) else 0.0
    sensitivity = _v7_float(data.get("semantic_sensitivity", 0.0))
    return 2.0 * pii + sensitivity


def _v8_apply_entity_protection(Gp, config):
    seed = int(config.get("seed", 42))
    rate = _v8_clamp_rate(config.get("entity_mask_rate", 0.75), 0.75)

    candidates = []

    for node, data in Gp.nodes(data=True):
        data["original_label"] = data.get("original_label", node)
        data["protected_label"] = data["original_label"]

        if _v7_node_sensitive(data, config):
            tie_break = int(
                _v8_hashlib.md5(
                    f"{node}-{seed}".encode()
                ).hexdigest()[:12],
                16
            )
            candidates.append(
                (node, _v8_node_score(data), tie_break)
            )

    target = int(round(len(candidates) * rate))

    if rate > 0 and candidates:
        target = max(1, target)

    target = min(target, len(candidates))

    # Highest-risk nodes are selected first.
    candidates.sort(key=lambda item: (-item[1], item[2]))
    selected = {node for node, _, _ in candidates[:target]}

    for node in selected:
        data = Gp.nodes[node]
        data["protected_label"] = _v7_mask_label(node, data, seed)

    audit = Gp.graph.setdefault("protection_audit", {})
    audit["sensitive_node_candidates"] = len(candidates)
    audit["masked_nodes"] = len(selected)
    audit["entity_mask_rate"] = rate

    return len(selected)


def _v8_private_relation_attrs(attrs):
    new_attrs = dict(attrs)
    new_attrs["protected_relation_type"] = "PRIVATE_RELATION"
    new_attrs["relation_type"] = "PRIVATE_RELATION"
    new_attrs["sensitive"] = 0
    new_attrs["relation_sensitivity"] = 0.0
    return new_attrs


def _v8_degree_preserving_rewire(
    Gp,
    candidate_mode,
    rate,
    seed,
    relation_private=False
):
    """
    Double-edge swaps:
        (u,v), (x,y) -> (u,y), (x,v)
    or
        (u,v), (x,y) -> (u,x), (v,y)

    Every successful swap preserves the degree of every node.
    """

    rng = _v8_random.Random(seed)

    available = []

    for u, v, data in Gp.edges(data=True):
        eligible = (
            candidate_mode == "all"
            or (
                candidate_mode == "sensitive"
                and _v7_edge_sensitive(data)
            )
        )

        if eligible:
            available.append((u, v, dict(data)))

    candidate_count = len(available)

    if candidate_count < 2 or rate <= 0:
        return {
            "candidate_edges": candidate_count,
            "target_rewired_edges": 0,
            "rewired_edges": 0,
            "successful_swaps": 0,
        }

    target_edges = int(round(candidate_count * rate))
    target_edges = max(2, target_edges)
    target_edges = min(target_edges, candidate_count)

    # Each double-edge swap changes two edges.
    if target_edges % 2 == 1:
        target_edges -= 1

    rewired_edges = 0
    successful_swaps = 0
    attempts = 0
    max_attempts = max(2000, target_edges * 300)

    while (
        rewired_edges < target_edges
        and len(available) >= 2
        and attempts < max_attempts
    ):
        attempts += 1

        i, j = rng.sample(range(len(available)), 2)
        edge1 = available[i]
        edge2 = available[j]

        u, v, attrs1 = edge1
        x, y, attrs2 = edge2

        if not Gp.has_edge(u, v) or not Gp.has_edge(x, y):
            for index in sorted([i, j], reverse=True):
                available.pop(index)
            continue

        # Four distinct endpoints avoid self-loops and trivial swaps.
        if len({u, v, x, y}) != 4:
            continue

        proposals = [
            ((u, y), (x, v)),
            ((u, x), (v, y)),
        ]
        rng.shuffle(proposals)

        chosen = None

        for new_edge1, new_edge2 in proposals:
            a, b = new_edge1
            c, d = new_edge2

            if a == b or c == d:
                continue

            if {a, b} == {c, d}:
                continue

            if Gp.has_edge(a, b) or Gp.has_edge(c, d):
                continue

            chosen = (new_edge1, new_edge2)
            break

        if chosen is None:
            continue

        new_edge1, new_edge2 = chosen

        Gp.remove_edge(u, v)
        Gp.remove_edge(x, y)

        if relation_private:
            attrs1 = _v8_private_relation_attrs(attrs1)
            attrs2 = _v8_private_relation_attrs(attrs2)

        Gp.add_edge(*new_edge1, **attrs1)
        Gp.add_edge(*new_edge2, **attrs2)

        for index in sorted([i, j], reverse=True):
            available.pop(index)

        rewired_edges += 2
        successful_swaps += 1

    return {
        "candidate_edges": candidate_count,
        "target_rewired_edges": target_edges,
        "rewired_edges": rewired_edges,
        "successful_swaps": successful_swaps,
    }


def _v8_apply_relation_protection(Gp, config):
    seed = int(config.get("seed", 42))
    rate = _v8_clamp_rate(
        config.get("relation_remove_rate", 0.12),
        0.12
    )

    sensitive_edges = 0

    # Relation labels are sanitized before structural swapping.
    for _, _, data in Gp.edges(data=True):
        if _v7_edge_sensitive(data):
            data["protected_relation_type"] = "PRIVATE_RELATION"
            sensitive_edges += 1

    result = _v8_degree_preserving_rewire(
        Gp,
        candidate_mode="sensitive",
        rate=rate,
        seed=seed + 101,
        relation_private=True,
    )

    audit = Gp.graph.setdefault("protection_audit", {})
    audit["sensitive_edges"] = sensitive_edges
    audit["relation_rewired_edges"] = result["rewired_edges"]
    audit["relation_target_edges"] = result["target_rewired_edges"]

    return result


def _v8_apply_topology_protection(Gp, config):
    seed = int(config.get("seed", 42))
    rate = _v8_clamp_rate(
        config.get("topology_rewire_rate", 0.08),
        0.08
    )

    result = _v8_degree_preserving_rewire(
        Gp,
        candidate_mode="all",
        rate=rate,
        seed=seed + 202,
        relation_private=False,
    )

    audit = Gp.graph.setdefault("protection_audit", {})
    audit["topology_rewired_edges"] = result["rewired_edges"]
    audit["topology_target_edges"] = result["target_rewired_edges"]

    return result


def apply_variant(G_base, risks, variant, config):
    """
    V8 corrected variants.

    Entity protection is sensitivity-aware pseudonymization.
    Relation and topology protection use exact degree-preserving
    double-edge swaps.
    """

    Gp = G_base.copy()
    Gp.graph["protection_audit"] = {}

    base_degree = dict(G_base.degree())

    if variant == "baseline":
        pass

    elif variant == "entity_only":
        _v8_apply_entity_protection(Gp, config)

    elif variant == "relation_only":
        _v8_apply_relation_protection(Gp, config)

    elif variant == "topology_only":
        _v8_apply_topology_protection(Gp, config)

    elif variant == "full":
        _v8_apply_entity_protection(Gp, config)
        _v8_apply_relation_protection(Gp, config)
        _v8_apply_topology_protection(Gp, config)

    else:
        raise ValueError(f"Unknown variant: {variant}")

    protected_degree = dict(Gp.degree())

    degree_changed_nodes = sum(
        base_degree[node] != protected_degree[node]
        for node in G_base.nodes()
    )

    audit = Gp.graph["protection_audit"]
    audit["degree_changed_nodes"] = degree_changed_nodes
    audit["degree_preserved_exactly"] = int(degree_changed_nodes == 0)

    return Gp
