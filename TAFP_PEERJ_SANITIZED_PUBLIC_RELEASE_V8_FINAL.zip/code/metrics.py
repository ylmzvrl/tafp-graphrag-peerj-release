def graph_edit_distance_proxy(G_base, G_protected):
    n_diff = abs(G_base.number_of_nodes() - G_protected.number_of_nodes())
    e_diff = abs(G_base.number_of_edges() - G_protected.number_of_edges())

    denom = max(1, G_base.number_of_nodes() + G_base.number_of_edges())
    return float((n_diff + e_diff) / denom)
