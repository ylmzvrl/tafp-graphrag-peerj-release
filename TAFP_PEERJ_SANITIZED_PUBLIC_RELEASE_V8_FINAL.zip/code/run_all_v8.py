import json
import sys
from pathlib import Path
import pandas as pd

from dataset_loader import build_graph_from_config
from risk import compute_all_risks
from protections_v8_baselines import apply_variant
from retrieval import sample_queries, evaluate_retrieval_utility
from attacks import (
    membership_inference_auc,
    link_inference_auc,
    topology_leakage_score,
    reconstruction_similarity
)
from metrics import graph_edit_distance_proxy


def run(config_path="config.json"):
    with open(config_path, "r") as f:
        config = json.load(f)

    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)

    G_base = build_graph_from_config(config)
    risks = compute_all_risks(G_base)

    queries = sample_queries(
        G_base,
        num_queries=config["num_queries"],
        seed=config["seed"]
    )

    retrieval_backend = config.get("retrieval_backend", "tfidf")
    embedding_model = config.get(
        "embedding_model",
        "sentence-transformers/all-MiniLM-L6-v2"
    )
    embedding_batch_size = config.get("embedding_batch_size", 64)
    embedding_device = config.get("embedding_device", "auto")

    print(f"\n[config] dataset_mode={config.get('dataset_mode', 'synthetic')}")
    print(f"[config] retrieval_backend={retrieval_backend}")

    rows = []

    for variant in config["variants"]:
        Gp = apply_variant(G_base, risks, variant, config)

        utility = evaluate_retrieval_utility(
            G_base,
            Gp,
            queries,
            k=config["retrieval_k"],
            backend=retrieval_backend,
            model_name=embedding_model,
            batch_size=embedding_batch_size,
            device=embedding_device
        )

        row = {
            "dataset_mode": config.get("dataset_mode", "synthetic"),
            "retrieval_backend": retrieval_backend,
            "variant": variant,
            "nodes": Gp.number_of_nodes(),
            "edges": Gp.number_of_edges(),
            "recall_at_k": utility["recall_at_k"],
            "ndcg_at_k": utility["ndcg_at_k"],
            "mia_auc": membership_inference_auc(
                G_base,
                Gp,
                num_samples=config["num_queries"],
                seed=config["seed"],
                backend=retrieval_backend,
                model_name=embedding_model,
                batch_size=embedding_batch_size,
                device=embedding_device
            ),
            "link_inference_auc": link_inference_auc(
                G_base,
                Gp,
                seed=config["seed"]
            ),
            "topology_leakage_score": topology_leakage_score(G_base, Gp),
            "reconstruction_similarity": reconstruction_similarity(G_base, Gp),
            "graph_edit_distance_proxy": graph_edit_distance_proxy(G_base, Gp)
        }

        audit = Gp.graph.get("protection_audit", {})

        row.update({
            "masked_nodes": audit.get("masked_nodes", 0),
            "relation_rewired_edges": audit.get(
                "relation_rewired_edges", 0
            ),
            "topology_rewired_edges": audit.get(
                "topology_rewired_edges", 0
            ),
            "dropped_edges": audit.get("dropped_edges", 0),
            "degree_changed_nodes": audit.get(
                "degree_changed_nodes", 0
            ),
            "degree_preserved_exactly": audit.get(
                "degree_preserved_exactly", 0
            ),
        })

        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_csv(output_dir / "summary_results.csv", index=False)

    print("\nDone. Results saved to outputs/summary_results.csv\n")
    print(df.to_string(index=False))


if __name__ == "__main__":
    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.json"
    run(config_path)
