import networkx as nx
import numpy as np

def normalize_dict(d):
    if not d:
        return {}
    vals = np.array(list(d.values()), dtype=float)
    mn, mx = float(vals.min()), float(vals.max())
    if mx - mn < 1e-12:
        return {k: 0.0 for k in d}
    return {k: float((v - mn) / (mx - mn)) for k, v in d.items()}

def compute_entity_risk(G):
    degree = normalize_dict(dict(G.degree()))
    pagerank = nx.pagerank(G) if G.number_of_nodes() > 0 else {}
    pagerank = normalize_dict(pagerank)

    risks = {}
    for n, data in G.nodes(data=True):
        pii = float(data.get("pii", 0.0))
        semantic = float(data.get("semantic_sensitivity", 0.0))
        centrality = 0.5 * degree.get(n, 0.0) + 0.5 * pagerank.get(n, 0.0)
        risks[n] = float(0.45 * pii + 0.25 * semantic + 0.30 * centrality)

    return risks

def compute_relation_risk(G):
    risks = {}
    edge_bet = nx.edge_betweenness_centrality(G) if G.number_of_edges() > 0 else {}
    edge_bet = {tuple(sorted(k)): v for k, v in edge_bet.items()}
    edge_bet = normalize_dict(edge_bet)

    for u, v, data in G.edges(data=True):
        key = tuple(sorted((u, v)))
        sensitive = float(data.get("sensitive", 0.0))
        weight = float(data.get("weight", 0.0))
        topological = edge_bet.get(key, 0.0)
        risks[key] = float(0.45 * sensitive + 0.20 * weight + 0.35 * topological)

    return risks

def compute_topology_risk(G):
    degree = normalize_dict(dict(G.degree()))
    bet = nx.betweenness_centrality(G, k=min(100, G.number_of_nodes()), seed=42) if G.number_of_nodes() > 0 else {}
    bet = normalize_dict(bet)

    clustering = nx.clustering(G) if G.number_of_nodes() > 0 else {}
    risks = {}

    for n in G.nodes():
        uniqueness = 1.0 - float(clustering.get(n, 0.0))
        risks[n] = float(0.40 * degree.get(n, 0.0) + 0.35 * bet.get(n, 0.0) + 0.25 * uniqueness)

    return risks

def compute_all_risks(G):
    return compute_entity_risk(G), compute_relation_risk(G), compute_topology_risk(G)
