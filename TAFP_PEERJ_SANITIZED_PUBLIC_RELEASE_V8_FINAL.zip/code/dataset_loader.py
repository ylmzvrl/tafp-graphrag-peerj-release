
import random
import pandas as pd
import networkx as nx

from graph_builder import build_synthetic_pii_kg


def _to_float(value, default=0.0):
    if pd.isna(value):
        return default

    if isinstance(value, str):
        value = value.strip().lower()

        if value in ["true", "yes", "y"]:
            return 1.0

        if value in ["false", "no", "n"]:
            return 0.0

    try:
        return float(value)
    except Exception:
        return default


def build_graph_from_csv(node_csv_path, edge_csv_path, seed=42):
    random.seed(seed)

    nodes_df = pd.read_csv(node_csv_path)
    edges_df = pd.read_csv(edge_csv_path)

    if "id" not in nodes_df.columns:
        raise ValueError("nodes.csv must contain column: id")

    if "source" not in edges_df.columns or "target" not in edges_df.columns:
        raise ValueError("edges.csv must contain columns: source, target")

    G = nx.Graph()

    # -----------------------------
    # Load nodes
    # -----------------------------
    for _, row in nodes_df.iterrows():
        node_id = str(row["id"])

        entity_type = (
            str(row["entity_type"])
            if "entity_type" in nodes_df.columns
            else "ENTITY"
        )

        pii = (
            _to_float(row["pii"], 0.0)
            if "pii" in nodes_df.columns
            else 0.0
        )

        semantic_sensitivity = (
            _to_float(row["semantic_sensitivity"], pii)
            if "semantic_sensitivity" in nodes_df.columns
            else pii
        )

        text = (
            str(row["text"])
            if "text" in nodes_df.columns
            else node_id
        )

        G.add_node(
            node_id,
            entity_type=entity_type,
            pii=pii,
            semantic_sensitivity=semantic_sensitivity,
            text=text,
            original_label=node_id,
            protected_label=node_id
        )

    # -----------------------------
    # Load edges
    # -----------------------------
    for _, row in edges_df.iterrows():
        source = str(row["source"])
        target = str(row["target"])

        if source not in G:
            G.add_node(
                source,
                entity_type="ENTITY",
                pii=0.0,
                semantic_sensitivity=0.0,
                text=source,
                original_label=source,
                protected_label=source
            )

        if target not in G:
            G.add_node(
                target,
                entity_type="ENTITY",
                pii=0.0,
                semantic_sensitivity=0.0,
                text=target,
                original_label=target,
                protected_label=target
            )

        relation_type = (
            str(row["relation_type"])
            if "relation_type" in edges_df.columns
            else "related_to"
        )

        sensitive = (
            _to_float(row["sensitive"], 0.0)
            if "sensitive" in edges_df.columns
            else 0.0
        )

        weight = (
            _to_float(row["weight"], random.random())
            if "weight" in edges_df.columns
            else random.random()
        )

        G.add_edge(
            source,
            target,
            relation_type=relation_type,
            protected_relation_type=relation_type,
            sensitive=sensitive,
            weight=weight
        )

    return G


def build_graph_from_config(config):
    mode = config.get("dataset_mode", "synthetic")

    if mode == "synthetic":
        return build_synthetic_pii_kg(
            num_entities=config["num_entities"],
            num_relations=config["num_relations"],
            seed=config["seed"]
        )

    if mode == "real_csv":
        return build_graph_from_csv(
            node_csv_path=config["node_csv_path"],
            edge_csv_path=config["edge_csv_path"],
            seed=config["seed"]
        )

    raise ValueError(f"Unknown dataset_mode: {mode}")
