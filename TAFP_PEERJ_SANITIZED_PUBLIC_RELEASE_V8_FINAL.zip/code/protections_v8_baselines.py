import random
import protections_v8 as core


def _rate(config, key, default):
    try:
        value = float(config.get(key, default))
    except Exception:
        value = default
    return max(0.0, min(1.0, value))


def _private_attrs(attrs):
    attrs = dict(attrs)
    attrs["protected_relation_type"] = "PRIVATE_RELATION"
    attrs["relation_type"] = "PRIVATE_RELATION"
    attrs["sensitive"] = 0
    attrs["relation_sensitivity"] = 0.0
    return attrs


def _even_target(count, rate):
    if count < 2 or rate <= 0:
        return 0

    target = int(round(count * rate))
    target = max(2, target)
    target = min(target, count)

    if target % 2:
        target -= 1

    return max(0, target)


def _random_entity_budget(G, config):
    seed = int(config.get("seed", 42))
    rng = random.Random(seed + 301)

    rate = _rate(config, "entity_mask_rate", 0.75)

    sensitive_count = sum(
        core._v7_node_sensitive(data, config)
        for _, data in G.nodes(data=True)
    )

    target = int(round(sensitive_count * rate))
    target = min(target, G.number_of_nodes())

    nodes = list(G.nodes())
    selected = rng.sample(nodes, target) if target else []

    for node, data in G.nodes(data=True):
        data["original_label"] = data.get("original_label", node)
        data["protected_label"] = data["original_label"]

    for node in selected:
        data = G.nodes[node]
        data["protected_label"] = core._v7_mask_label(
            node,
            data,
            seed
        )

    audit = G.graph.setdefault("protection_audit", {})
    audit["sensitive_node_candidates"] = sensitive_count
    audit["masked_nodes"] = len(selected)
    audit["entity_selection"] = "uniform_random_all_nodes"


def _swap_selected_edges(
    G,
    selected_edges,
    target_edges,
    seed,
    make_private=False
):
    rng = random.Random(seed)

    available = [
        (u, v, dict(G.edges[u, v]))
        for u, v in selected_edges
        if G.has_edge(u, v)
    ]

    target_edges = min(target_edges, len(available))

    if target_edges % 2:
        target_edges -= 1

    rewired = 0
    swaps = 0
    attempts = 0
    max_attempts = max(2000, target_edges * 300)

    while (
        rewired < target_edges
        and len(available) >= 2
        and attempts < max_attempts
    ):
        attempts += 1

        i, j = rng.sample(range(len(available)), 2)

        u, v, attrs1 = available[i]
        x, y, attrs2 = available[j]

        if not G.has_edge(u, v) or not G.has_edge(x, y):
            for index in sorted((i, j), reverse=True):
                available.pop(index)
            continue

        if len({u, v, x, y}) != 4:
            continue

        proposals = [
            ((u, y), (x, v)),
            ((u, x), (v, y)),
        ]
        rng.shuffle(proposals)

        chosen = None

        for edge1, edge2 in proposals:
            a, b = edge1
            c, d = edge2

            if a == b or c == d:
                continue

            if G.has_edge(a, b) or G.has_edge(c, d):
                continue

            chosen = edge1, edge2
            break

        if chosen is None:
            continue

        edge1, edge2 = chosen

        G.remove_edge(u, v)
        G.remove_edge(x, y)

        if make_private:
            attrs1 = _private_attrs(attrs1)
            attrs2 = _private_attrs(attrs2)

        G.add_edge(*edge1, **attrs1)
        G.add_edge(*edge2, **attrs2)

        for index in sorted((i, j), reverse=True):
            available.pop(index)

        rewired += 2
        swaps += 1

    return {
        "target": target_edges,
        "rewired": rewired,
        "swaps": swaps,
    }


def _random_relation_budget(G, config):
    seed = int(config.get("seed", 42))
    rng = random.Random(seed + 401)

    rate = _rate(config, "relation_remove_rate", 0.12)

    sensitive_count = sum(
        core._v7_edge_sensitive(data)
        for _, _, data in G.edges(data=True)
    )

    all_edges = list(G.edges())
    selected_count = min(sensitive_count, len(all_edges))

    selected = (
        rng.sample(all_edges, selected_count)
        if selected_count
        else []
    )

    for u, v in selected:
        G.edges[u, v]["protected_relation_type"] = (
            "PRIVATE_RELATION"
        )

    target = _even_target(selected_count, rate)

    result = _swap_selected_edges(
        G,
        selected,
        target,
        seed + 402,
        make_private=True
    )

    audit = G.graph.setdefault("protection_audit", {})
    audit["random_relation_selected_edges"] = selected_count
    audit["relation_target_edges"] = result["target"]
    audit["relation_rewired_edges"] = result["rewired"]
    audit["relation_selection"] = "uniform_random_all_edges"


def _random_edge_dropout(G, config):
    seed = int(config.get("seed", 42))
    rng = random.Random(seed + 501)

    rate = _rate(config, "topology_rewire_rate", 0.08)
    edges = list(G.edges())

    target = _even_target(len(edges), rate)
    selected = rng.sample(edges, target) if target else []

    G.remove_edges_from(selected)

    audit = G.graph.setdefault("protection_audit", {})
    audit["dropped_edges"] = len(selected)
    audit["dropout_target_edges"] = target


def apply_variant(G_base, risks, variant, config):
    original_variants = {
        "baseline",
        "entity_only",
        "relation_only",
        "topology_only",
        "full",
    }

    if variant in original_variants:
        return core.apply_variant(
            G_base,
            risks,
            variant,
            config
        )

    G = G_base.copy()
    G.graph["protection_audit"] = {}
    base_degree = dict(G_base.degree())

    if variant == "random_entity_budget":
        _random_entity_budget(G, config)

    elif variant == "random_relation_budget":
        _random_relation_budget(G, config)

    elif variant == "random_edge_dropout":
        _random_edge_dropout(G, config)

    elif variant == "random_full_budget":
        _random_entity_budget(G, config)
        _random_relation_budget(G, config)
        core._v8_apply_topology_protection(G, config)

    else:
        raise ValueError(f"Unknown variant: {variant}")

    changed = sum(
        base_degree[node] != G.degree(node)
        for node in G_base.nodes()
    )

    audit = G.graph["protection_audit"]
    audit["degree_changed_nodes"] = changed
    audit["degree_preserved_exactly"] = int(changed == 0)

    return G
