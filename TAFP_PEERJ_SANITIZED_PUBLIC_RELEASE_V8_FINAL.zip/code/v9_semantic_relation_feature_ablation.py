import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, f1_score
from sklearn.preprocessing import StandardScaler

import v9_semantic_relation_structure_smoke as smoke


OUTPUT = Path(
    "outputs/v9_semantic_relation_feature_ablation"
)

FEATURE_GROUPS = [
    "entity_types",
    "local_topology",
    "neighbor_relations",
    "all",
]


def select_features(features, group):
    if group == "all":
        return dict(features)

    if group == "entity_types":
        return {
            key: value
            for key, value in features.items()
            if key.startswith("type_pair=")
            or key == "same_entity_type"
        }

    if group == "neighbor_relations":
        return {
            key: value
            for key, value in features.items()
            if key.startswith("neighbor_relation_")
        }

    if group == "local_topology":
        return {
            key: value
            for key, value in features.items()
            if not key.startswith("type_pair=")
            and key != "same_entity_type"
            and not key.startswith("neighbor_relation_")
        }

    raise ValueError(group)


def evaluate(train_rows, test_rows, feature_group, seed):
    x_train_dict = [
        select_features(row["features"], feature_group)
        for row in train_rows
    ]

    x_test_dict = [
        select_features(row["features"], feature_group)
        for row in test_rows
    ]

    y_train = np.array([
        row["relation_type"]
        for row in train_rows
    ])

    y_test = np.array([
        row["relation_type"]
        for row in test_rows
    ])

    vectorizer = DictVectorizer(sparse=True)

    x_train = vectorizer.fit_transform(x_train_dict)
    x_test = vectorizer.transform(x_test_dict)

    scaler = StandardScaler(with_mean=False)
    x_train = scaler.fit_transform(x_train)
    x_test = scaler.transform(x_test)

    model = LogisticRegression(
        class_weight="balanced",
        solver="lbfgs",
        max_iter=20000,
        tol=1e-4,
        random_state=seed,
    )

    with warnings.catch_warnings():
        warnings.simplefilter("error", ConvergenceWarning)
        model.fit(x_train, y_train)

    if int(model.n_iter_.max()) >= model.max_iter:
        raise RuntimeError(
            f"Model did not converge: n_iter={model.n_iter_}"
        )

    predictions = model.predict(x_test)

    return {
        "n_features": int(x_train.shape[1]),
        "macro_f1": f1_score(
            y_test,
            predictions,
            average="macro",
            zero_division=0,
        ),
        "balanced_accuracy": balanced_accuracy_score(
            y_test,
            predictions,
        ),
    }


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    results = []

    for dataset in smoke.DATASETS:
        print("\nDATASET:", dataset)

        with open(
            smoke.CONFIGS[dataset],
            "r",
            encoding="utf-8",
        ) as handle:
            config = json.load(handle)

        base_graph = smoke.build_graph_from_config(config)
        _, split_df = smoke.load_unique_edges_and_split(dataset)

        print("Computing risks...")
        risks = smoke.compute_all_risks(base_graph)

        for seed in smoke.SEEDS:
            _, train_rows, test_rows = (
                smoke.prepare_variant_data(
                    dataset=dataset,
                    attack_seed=seed,
                    variant="baseline",
                    base_graph=base_graph,
                    original_config=config,
                    risks=risks,
                    split_df=split_df,
                )
            )

            for feature_group in FEATURE_GROUPS:
                metrics = evaluate(
                    train_rows,
                    test_rows,
                    feature_group,
                    seed,
                )

                row = {
                    "dataset_name": dataset,
                    "attack_seed": seed,
                    "variant": "baseline",
                    "feature_group": feature_group,
                    **metrics,
                }

                results.append(row)

                print(
                    dataset,
                    seed,
                    feature_group,
                    round(metrics["macro_f1"], 4),
                    round(metrics["balanced_accuracy"], 4),
                )

    df = pd.DataFrame(results)

    df.to_csv(
        OUTPUT / "baseline_feature_ablation.csv",
        index=False,
    )

    print("\nMEAN RESULTS")
    print(
        df.groupby(
            ["dataset_name", "feature_group"]
        )[
            ["macro_f1", "balanced_accuracy"]
        ]
        .mean()
        .round(4)
        .to_string()
    )


if __name__ == "__main__":
    main()
