import copy
import json
import random
from collections import Counter
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer

from dataset_loader import build_graph_from_config
from protections_v8_baselines import apply_variant
from risk import compute_all_risks


CONFIGS = {
    "SynthPII": "config_synthpii_gpu_embedding.json",
    "PubMed": "config_pubmed_gpu_embedding.json",
}

DATASETS = ["SynthPII", "PubMed"]
SEEDS = [1, 7, 21]

VARIANTS = [
    "baseline",
    "relation_only",
    "random_relation_budget",
    "topology_only",
    "random_edge_dropout",
    "full",
    "random_full_budget",
]

MANIFEST_DIR = Path(
    "outputs/v9_edge_protocol_v4/manifests"
)

OUTPUT_DIR = Path(
    "outputs/v9_semantic_relation_structure_smoke"
)

PUBMED_EXCLUDED_CLASS = "disease_treatment_context"


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)


def seeded_config(original_config, seed):
    config = copy.deepcopy(original_config)

    def update(value):
        if isinstance(value, dict):
            for key in value:
                if key in {
                    "seed",
                    "random_seed",
                    "attack_seed",
                    "protection_seed",
                }:
                    value[key] = seed
                else:
                    update(value[key])
        elif isinstance(value, list):
            for item in value:
                update(item)

    update(config)
    config["seed"] = seed
    config["random_seed"] = seed
    config["attack_seed"] = seed
    config["protection_seed"] = seed
    return config


def canonical_edge_key(u, v):
    a, b = sorted([str(u), str(v)])
    return f"{a}||{b}"


def load_unique_edges_and_split(dataset):
    frames = []

    for seed in SEEDS:
        path = (
            MANIFEST_DIR
            / f"{dataset}_seed_{seed}.csv"
        )

        df = pd.read_csv(path)
        df = df[df["edge_label"].astype(int) == 1].copy()

        df["edge_key"] = [
            canonical_edge_key(u, v)
            for u, v in zip(df["u"], df["v"])
        ]

        frames.append(
            df[
                [
                    "dataset_name",
                    "u",
                    "v",
                    "edge_key",
                    "target_group",
                    "original_relation_type",
                ]
            ]
        )

    combined = pd.concat(frames, ignore_index=True)

    consistency = combined.groupby("edge_key").agg(
        relation_count=(
            "original_relation_type",
            "nunique",
        ),
        group_count=("target_group", "nunique"),
    )

    conflicts = consistency[
        (consistency["relation_count"] != 1)
        | (consistency["group_count"] != 1)
    ]

    if len(conflicts):
        raise RuntimeError(
            f"{dataset}: inconsistent repeated edges: "
            f"{len(conflicts)}"
        )

    unique_edges = (
        combined
        .sort_values("edge_key")
        .drop_duplicates("edge_key")
        .reset_index(drop=True)
    )

    unique_edges["included_in_main_attack"] = 1

    if dataset == "PubMed":
        unique_edges.loc[
            unique_edges["original_relation_type"]
            == PUBMED_EXCLUDED_CLASS,
            "included_in_main_attack",
        ] = 0

    modeling_edges = unique_edges[
        unique_edges["included_in_main_attack"] == 1
    ].copy()

    train_df, test_df = train_test_split(
        modeling_edges,
        test_size=0.30,
        random_state=20260617,
        stratify=modeling_edges[
            "original_relation_type"
        ],
    )

    train_df = train_df.copy()
    test_df = test_df.copy()

    train_df["split"] = "train"
    test_df["split"] = "test"

    overlap = set(train_df["edge_key"]) & set(
        test_df["edge_key"]
    )

    if overlap:
        raise RuntimeError(
            f"{dataset}: train-test edge overlap detected"
        )

    split_df = pd.concat(
        [train_df, test_df],
        ignore_index=True,
    )

    return unique_edges, split_df


def exposed_relation_label(edge_data):
    return str(
        edge_data.get(
            "protected_relation_type",
            edge_data.get(
                "relation_type",
                "related_to",
            ),
        )
    )


def neighborhood_relation_counts(G, node, excluded_node):
    counts = Counter()

    for _, neighbor, edge_data in G.edges(
        node,
        data=True,
    ):
        # Hedef kenarın kendi etiketi hiçbir şekilde
        # saldırı özelliğine dahil edilmez.
        if str(neighbor) == str(excluded_node):
            continue

        relation = exposed_relation_label(edge_data)
        counts[relation] += 1

    return counts


def extract_structure_features(
    G,
    u,
    v,
    clustering,
):
    if u not in G or v not in G:
        raise RuntimeError(
            f"Missing endpoint in protected graph: {u}, {v}"
        )

    neighbors_u = set(G.neighbors(u))
    neighbors_v = set(G.neighbors(v))

    common = neighbors_u & neighbors_v
    union = neighbors_u | neighbors_v

    degree_u = int(G.degree(u))
    degree_v = int(G.degree(v))

    common_count = len(common)

    jaccard = (
        common_count / len(union)
        if union
        else 0.0
    )

    common_norm = (
        common_count
        / max(1, min(degree_u, degree_v))
    )

    resource_allocation = sum(
        1.0 / max(1, G.degree(node))
        for node in common
    )

    resource_allocation = min(
        1.0,
        float(resource_allocation),
    )

    if G.is_multigraph():
        raise RuntimeError(
            "Target-edge exclusion requires a simple graph"
        )

    target_edge_data = None

    if G.has_edge(u, v):
        target_edge_data = dict(
            G.get_edge_data(u, v)
        )
        G.remove_edge(u, v)

    try:
        try:
            path_length = nx.shortest_path_length(
                G,
                source=u,
                target=v,
            )
            disconnected = 0.0
            path_length = min(int(path_length), 6)
        except nx.NetworkXNoPath:
            disconnected = 1.0
            path_length = 7
    finally:
        if target_edge_data is not None:
            G.add_edge(
                u,
                v,
                **target_edge_data,
            )

    type_u = str(
        G.nodes[u].get("entity_type", "ENTITY")
    )
    type_v = str(
        G.nodes[v].get("entity_type", "ENTITY")
    )

    type_1, type_2 = sorted([type_u, type_v])

    degree_min, degree_max = sorted(
        [degree_u, degree_v]
    )

    clustering_u = float(clustering.get(u, 0.0))
    clustering_v = float(clustering.get(v, 0.0))

    clustering_min, clustering_max = sorted(
        [clustering_u, clustering_v]
    )

    features = {
        f"type_pair={type_1}||{type_2}": 1.0,
        "same_entity_type": float(type_u == type_v),
        "degree_min": float(degree_min),
        "degree_max": float(degree_max),
        "degree_sum": float(degree_u + degree_v),
        "degree_abs_difference": float(
            abs(degree_u - degree_v)
        ),
        "common_neighbors": float(common_count),
        "jaccard": float(jaccard),
        "common_neighbor_norm": float(common_norm),
        "resource_allocation": resource_allocation,
        "clustering_min": clustering_min,
        "clustering_max": clustering_max,
        "clustering_abs_difference": float(
            abs(clustering_u - clustering_v)
        ),
        "shortest_path_length": float(path_length),
        "disconnected": disconnected,
    }

    relations_u = neighborhood_relation_counts(
        G,
        u,
        v,
    )
    relations_v = neighborhood_relation_counts(
        G,
        v,
        u,
    )

    relation_names = sorted(
        set(relations_u) | set(relations_v)
    )

    total_u = max(1, sum(relations_u.values()))
    total_v = max(1, sum(relations_v.values()))

    for relation in relation_names:
        count_u = float(relations_u.get(relation, 0))
        count_v = float(relations_v.get(relation, 0))

        fraction_u = count_u / total_u
        fraction_v = count_v / total_v

        # Yön bağımsız komşuluk-relation özellikleri.
        features[
            f"neighbor_relation_sum={relation}"
        ] = count_u + count_v

        features[
            f"neighbor_relation_absdiff={relation}"
        ] = abs(count_u - count_v)

        features[
            f"neighbor_relation_fraction_sum={relation}"
        ] = fraction_u + fraction_v

        features[
            f"neighbor_relation_fraction_absdiff={relation}"
        ] = abs(fraction_u - fraction_v)

    return features


def build_feature_rows(
    protected_graph,
    split_df,
):
    clustering = nx.clustering(protected_graph)

    rows = []

    for record in split_df.itertuples(index=False):
        features = extract_structure_features(
            protected_graph,
            record.u,
            record.v,
            clustering,
        )

        rows.append({
            "edge_key": record.edge_key,
            "split": record.split,
            "target_group": record.target_group,
            "relation_type":
                record.original_relation_type,
            "features": features,
        })

    return rows


def prepare_variant_data(
    dataset,
    attack_seed,
    variant,
    base_graph,
    original_config,
    risks,
    split_df,
):
    seed_everything(attack_seed)

    config = seeded_config(
        original_config,
        attack_seed,
    )

    protected_graph = apply_variant(
        base_graph,
        risks,
        variant,
        config,
    )

    feature_rows = build_feature_rows(
        protected_graph,
        split_df,
    )

    train_rows = [
        row
        for row in feature_rows
        if row["split"] == "train"
    ]

    test_rows = [
        row
        for row in feature_rows
        if row["split"] == "test"
    ]

    train_keys = {
        row["edge_key"]
        for row in train_rows
    }

    test_keys = {
        row["edge_key"]
        for row in test_rows
    }

    overlap = train_keys & test_keys

    if overlap:
        raise RuntimeError(
            f"{dataset} seed={attack_seed} "
            f"variant={variant}: "
            "train-test overlap"
        )

    return (
        protected_graph,
        train_rows,
        test_rows,
    )


def evaluate_relation_attack(
    dataset,
    attack_seed,
    variant,
    train_rows,
    test_rows,
):
    x_train_dict = [
        row["features"]
        for row in train_rows
    ]
    x_test_dict = [
        row["features"]
        for row in test_rows
    ]

    y_train = np.array([
        row["relation_type"]
        for row in train_rows
    ])

    y_test = np.array([
        row["relation_type"]
        for row in test_rows
    ])

    vectorizer = DictVectorizer(sparse=True)

    x_train = vectorizer.fit_transform(
        x_train_dict
    )
    x_test = vectorizer.transform(
        x_test_dict
    )

    model = LogisticRegression(
        class_weight="balanced",
        solver="lbfgs",
        max_iter=5000,
        random_state=attack_seed,
    )

    model.fit(x_train, y_train)
    predictions = model.predict(x_test)

    majority_class = Counter(
        y_train
    ).most_common(1)[0][0]

    majority_predictions = np.full(
        len(y_test),
        majority_class,
        dtype=object,
    )

    summary_rows = []
    class_rows = []

    scopes = {
        "all": np.ones(
            len(test_rows),
            dtype=bool,
        ),
        "sensitive": np.array([
            row["target_group"] == "sensitive"
            for row in test_rows
        ]),
        "non_sensitive": np.array([
            row["target_group"] == "non_sensitive"
            for row in test_rows
        ]),
    }

    for scope, mask in scopes.items():
        if int(mask.sum()) == 0:
            continue

        y_true_scope = y_test[mask]
        y_pred_scope = predictions[mask]
        y_majority_scope = majority_predictions[mask]

        summary_rows.append({
            "dataset_name": dataset,
            "attack_seed": attack_seed,
            "variant": variant,
            "scope": scope,
            "n_train": len(train_rows),
            "n_test": int(mask.sum()),
            "n_features": int(x_train.shape[1]),
            "n_train_classes": int(
                len(set(y_train))
            ),
            "n_test_classes": int(
                len(set(y_true_scope))
            ),
            "majority_class": majority_class,
            "macro_f1": f1_score(
                y_true_scope,
                y_pred_scope,
                average="macro",
                zero_division=0,
            ),
            "micro_f1": f1_score(
                y_true_scope,
                y_pred_scope,
                average="micro",
                zero_division=0,
            ),
            "balanced_accuracy":
                balanced_accuracy_score(
                    y_true_scope,
                    y_pred_scope,
                ),
            "accuracy": accuracy_score(
                y_true_scope,
                y_pred_scope,
            ),
            "majority_macro_f1": f1_score(
                y_true_scope,
                y_majority_scope,
                average="macro",
                zero_division=0,
            ),
            "majority_balanced_accuracy":
                balanced_accuracy_score(
                    y_true_scope,
                    y_majority_scope,
                ),
        })

        labels = sorted(set(y_true_scope))

        recalls = recall_score(
            y_true_scope,
            y_pred_scope,
            labels=labels,
            average=None,
            zero_division=0,
        )

        for label, recall_value in zip(
            labels,
            recalls,
        ):
            support = int(
                np.sum(y_true_scope == label)
            )

            class_rows.append({
                "dataset_name": dataset,
                "attack_seed": attack_seed,
                "variant": variant,
                "scope": scope,
                "relation_type": label,
                "support": support,
                "recall": float(recall_value),
            })

    prediction_rows = []

    for row, prediction in zip(
        test_rows,
        predictions,
    ):
        prediction_rows.append({
            "dataset_name": dataset,
            "attack_seed": attack_seed,
            "variant": variant,
            "edge_key": row["edge_key"],
            "target_group": row["target_group"],
            "true_relation_type":
                row["relation_type"],
            "predicted_relation_type":
                prediction,
            "correct": int(
                prediction == row["relation_type"]
            ),
        })

    return (
        summary_rows,
        class_rows,
        prediction_rows,
    )


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    all_summary = []
    all_class_results = []
    all_predictions = []
    all_splits = []
    all_protection_audits = []

    for dataset in DATASETS:
        print("\n" + "=" * 70)
        print("DATASET:", dataset)

        with open(
            CONFIGS[dataset],
            "r",
            encoding="utf-8",
        ) as handle:
            original_config = json.load(handle)

        base_graph = build_graph_from_config(
            original_config
        )

        print(
            "Base graph:",
            base_graph.number_of_nodes(),
            "nodes,",
            base_graph.number_of_edges(),
            "edges",
        )

        unique_edges, split_df = (
            load_unique_edges_and_split(dataset)
        )

        print(
            "Unique positive edges:",
            len(unique_edges),
        )
        print(
            "Main attack edges:",
            len(split_df),
        )
        print(
            "Train:",
            int((split_df["split"] == "train").sum()),
            "Test:",
            int((split_df["split"] == "test").sum()),
        )

        split_df.to_csv(
            OUTPUT_DIR
            / f"{dataset}_fixed_relation_split.csv",
            index=False,
        )

        all_splits.append(split_df)

        print("Computing risks once...")
        risks = compute_all_risks(base_graph)
        print("Risks ready.")

        base_degrees = dict(base_graph.degree())

        for attack_seed in SEEDS:
            for variant in VARIANTS:
                print(
                    f"START: dataset={dataset} "
                    f"seed={attack_seed} "
                    f"variant={variant}"
                )

                (
                    protected_graph,
                    train_rows,
                    test_rows,
                ) = prepare_variant_data(
                    dataset=dataset,
                    attack_seed=attack_seed,
                    variant=variant,
                    base_graph=base_graph,
                    original_config=original_config,
                    risks=risks,
                    split_df=split_df,
                )

                (
                    summary_rows,
                    class_rows,
                    prediction_rows,
                ) = evaluate_relation_attack(
                    dataset=dataset,
                    attack_seed=attack_seed,
                    variant=variant,
                    train_rows=train_rows,
                    test_rows=test_rows,
                )

                all_summary.extend(summary_rows)
                all_class_results.extend(class_rows)
                all_predictions.extend(prediction_rows)

                protected_degrees = dict(
                    protected_graph.degree()
                )

                changed_degree_nodes = sum(
                    base_degrees.get(node, 0)
                    != protected_degrees.get(node, 0)
                    for node in base_graph.nodes()
                )

                audit_row = {
                    "dataset_name": dataset,
                    "attack_seed": attack_seed,
                    "variant": variant,
                    "base_nodes":
                        base_graph.number_of_nodes(),
                    "base_edges":
                        base_graph.number_of_edges(),
                    "protected_nodes":
                        protected_graph.number_of_nodes(),
                    "protected_edges":
                        protected_graph.number_of_edges(),
                    "changed_degree_nodes":
                        changed_degree_nodes,
                }

                for key, value in (
                    protected_graph.graph
                    .get("protection_audit", {})
                    .items()
                ):
                    if isinstance(
                        value,
                        (str, int, float, bool),
                    ):
                        audit_row[key] = value

                all_protection_audits.append(
                    audit_row
                )

                print(
                    f"PASS: dataset={dataset} "
                    f"seed={attack_seed} "
                    f"variant={variant}"
                )

    summary_df = pd.DataFrame(all_summary)
    class_df = pd.DataFrame(all_class_results)
    prediction_df = pd.DataFrame(all_predictions)
    split_all_df = pd.concat(
        all_splits,
        ignore_index=True,
    )
    protection_df = pd.DataFrame(
        all_protection_audits
    )

    duplicate_predictions = int(
        prediction_df.duplicated(
            [
                "dataset_name",
                "attack_seed",
                "variant",
                "edge_key",
            ]
        ).sum()
    )

    missing_metrics = int(
        summary_df[
            [
                "macro_f1",
                "micro_f1",
                "balanced_accuracy",
                "accuracy",
            ]
        ]
        .isna()
        .sum()
        .sum()
    )

    candidate_set_errors = 0

    for dataset, dataset_group in (
        prediction_df.groupby("dataset_name")
    ):
        reference = None

        for _, run_group in dataset_group.groupby(
            ["attack_seed", "variant"]
        ):
            keys = set(run_group["edge_key"])

            if reference is None:
                reference = keys
            elif keys != reference:
                candidate_set_errors += 1

    train_test_overlap = 0

    for dataset, group in split_all_df.groupby(
        "dataset_name"
    ):
        train_keys = set(
            group.loc[
                group["split"] == "train",
                "edge_key",
            ]
        )

        test_keys = set(
            group.loc[
                group["split"] == "test",
                "edge_key",
            ]
        )

        train_test_overlap += len(
            train_keys & test_keys
        )

    expected_runs = (
        len(DATASETS)
        * len(SEEDS)
        * len(VARIANTS)
    )

    actual_runs = int(
        prediction_df[
            [
                "dataset_name",
                "attack_seed",
                "variant",
            ]
        ]
        .drop_duplicates()
        .shape[0]
    )

    audit = {
        "expected_runs": expected_runs,
        "actual_runs": actual_runs,
        "duplicate_predictions":
            duplicate_predictions,
        "missing_summary_metrics":
            missing_metrics,
        "candidate_set_errors":
            candidate_set_errors,
        "train_test_edge_overlap":
            train_test_overlap,
        "summary_rows": len(summary_df),
        "class_rows": len(class_df),
        "prediction_rows": len(prediction_df),
    }

    audit["audit_pass"] = int(
        actual_runs == expected_runs
        and duplicate_predictions == 0
        and missing_metrics == 0
        and candidate_set_errors == 0
        and train_test_overlap == 0
    )

    summary_df.to_csv(
        OUTPUT_DIR / "attack_summary.csv",
        index=False,
    )

    class_df.to_csv(
        OUTPUT_DIR / "per_class_recall.csv",
        index=False,
    )

    prediction_df.to_csv(
        OUTPUT_DIR / "test_predictions.csv",
        index=False,
    )

    protection_df.to_csv(
        OUTPUT_DIR / "protection_audit.csv",
        index=False,
    )

    with open(
        OUTPUT_DIR / "result_audit.json",
        "w",
        encoding="utf-8",
    ) as handle:
        json.dump(audit, handle, indent=2)

    print("\nSEMANTIC RELATION ATTACK AUDIT")
    print(json.dumps(audit, indent=2))

    if audit["audit_pass"] != 1:
        raise RuntimeError(
            "Semantic relation smoke audit failed"
        )

    primary = summary_df[
        summary_df["scope"] == "all"
    ][
        [
            "dataset_name",
            "attack_seed",
            "variant",
            "macro_f1",
            "balanced_accuracy",
            "majority_macro_f1",
        ]
    ]

    print("\nPRIMARY STRUCTURE-ONLY RESULTS")
    print(primary.to_string(index=False))

    print("\nSTRUCTURE-ONLY SEMANTIC RELATION SMOKE: PASS")


if __name__ == "__main__":
    main()
